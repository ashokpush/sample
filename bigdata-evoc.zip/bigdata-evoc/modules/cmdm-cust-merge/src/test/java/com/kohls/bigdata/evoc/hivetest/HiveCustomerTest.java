package com.kohls.bigdata.evoc.hivetest;

/**
 * Created by jksingh on 30/12/16.
 */

import java.io.*;
import java.nio.file.Paths;
import java.util.*;

import com.klarna.hiverunner.HiveShell;
import com.klarna.hiverunner.StandaloneHiveRunner;
import com.klarna.hiverunner.annotations.HiveProperties;
import com.klarna.hiverunner.annotations.HiveSQL;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;


@RunWith(StandaloneHiveRunner.class)
public class HiveCustomerTest {

    private static String DELIMITER = "|";

    public static  Properties properties;

    public static InputStream inputStream = ClassLoader.getSystemResourceAsStream("common.properties");

    public static Map<String,String> commonProperties = new HashMap<String, String>();

    public List<Object[]> expectedOutput = new ArrayList<Object[]>();


    static {
        properties = new Properties();
        try {
            properties.load(inputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
        for(String key : properties.stringPropertyNames()){
            commonProperties.put(key,properties.getProperty(key));
        }
    }

    @HiveSQL(files = {"evoc-db.hql",
            "work-temp-cust.hql",
            "stage-cust.hql"
    },autoStart = false)
    public HiveShell shell;

    @HiveProperties
    public Map<String, String> hiveProperties = commonProperties;

    public void setCommonProperties(){
        for (Map.Entry<String, String> entry : commonProperties.entrySet())
            shell.setHiveVarValue(entry.getKey(),entry.getValue());
    }

    public List<Object[]> fetchData() {
        try {
            String[] outputFile = new String[3];
            List<Object[]> result = new ArrayList<Object[]>();
            File resourceDirectory = new File(ClassLoader.getSystemResource("test_data").toURI());
            File[] testResources = resourceDirectory.listFiles();
            for (File file : testResources) {
                if (file.getName().endsWith(".input")) {
                    String[] inputFile = file.getName().split("\\.");
                    shell.insertInto(inputFile[0], inputFile[1]).addRowsFromDelimited(file, DELIMITER, "\\n").commit();
                } else if (file.getName().endsWith(".output")) {
                    outputFile = file.getName().split("\\.");
                    String output = new BufferedReader(new FileReader(file)).readLine();
                    for(String s : output.split("\n")){
                        Object[] objects = s.split("\\"+DELIMITER);
                        expectedOutput.add(objects);
                    }
                }
            }
            shell.execute(Paths.get(properties.getProperty("TEST_SCRIPT")));
            result = shell.executeStatement("select * from "+outputFile[0]+"."+outputFile[1]);
            return result;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public List<Object[]> convertToString(List<Object[]> objects) {
        List<Object[]> stringObjects = new ArrayList<Object[]>();
        for (Object[] ob : objects) {
            Object String_Array[] = new String[ob.length];
            for (int i = 0; i < ob.length; i++) {
                try {
                    String_Array[i] = ob[i].toString();
                }catch (NullPointerException e){
                    String_Array[i] = "";
                }
            }
            stringObjects.add(String_Array);
        }
        return stringObjects;
    }


    @Test
    public void testCmdmEvoc() {
        setCommonProperties();
        shell.start();
        List<Object[]> match = fetchData();
        List<Object[]> matchString = convertToString(match);
        assertEquals(expectedOutput.size(), match.size());
        assertArrayEquals(matchString.toArray(),expectedOutput.toArray());
    }

}
