package com.kohls.bigdata.evoc.udf;

import org.apache.pig.pigunit.PigTest;
import org.junit.Test;

public class UpdateReferenceCodeDescriptionTest {

    @Test
    /**
     * Test hierarchical input with two reference code columns inside of the bag.
     * Verify that empty bags and empty reference values are processed correctly.
     */
    public void testTwoBags() throws Exception {
        String[] script = new String[] {
                "data = LOAD 'input' AS (group: TUPLE(acct_nbr: chararray,acct_typ_cde: chararray),gen_account_filtered:BAG {t:TUPLE(acct_nbr: chararray,acct_typ_cde: chararray," +
                        "acct_typ_cde_desc: chararray,acct_opn_tmst: chararray,acct_clo_dte: chararray,prim_lang_cde: chararray,prim_lang_cde_desc: chararray," +
                        "prmier_acct_stat_cde: chararray,prmier_acct_stat_cde_desc: chararray,prmier_acct_exprn_dte: chararray,kc_vip_ind: chararray," +
                        "acct_opn_sub_chnl_id: chararray,acct_assoc_id: chararray,cre_sys_cde: chararray,cre_sys_cde_desc: chararray,kc_extl_stat_cde: chararray," +
                        "kc_extl_stat_cde_desc: chararray,src_sys_cde: chararray,src_sys_cde_desc: chararray,last_upd_sys_cde: chararray,last_upd_sys_cde_desc: chararray," +
                        "last_upd_tmst: chararray,cre_tmst: chararray,acct_stat_cde: chararray,acct_stat_cde_desc: chararray,acct_prg_dte: chararray,sor_appl_id: chararray," +
                        "lng_acct_nbr: chararray,rol_dtl: BAG{innertuple: TUPLE(cust_rol_cde: chararray,cust_rol_cde_desc: chararray,prfl_id: chararray,cre_sys_cde: " +
                        "chararray,cre_sys_cde_desc: chararray,last_upd_sys_cde: chararray,last_upd_sys_cde_desc: chararray,cre_tmst: chararray,last_upd_tmst: chararray)}," +
                        "fil_lod_tmst: chararray,acct_frst_3_nbr: chararray)}," +
                        "acct_gold_current:BAG {t1:TUPLE(acct_nbr: chararray,acct_typ_cde: chararray,acct_typ_cde_desc: chararray," +
                        "acct_opn_tmst: chararray,acct_clo_dte: chararray,prim_lang_cde: chararray,prim_lang_cde_desc: chararray,prmier_acct_stat_cde: chararray," +
                        "prmier_acct_stat_cde_desc: chararray,prmier_acct_exprn_dte: datetime,kc_vip_ind: chararray,acct_opn_sub_chnl_id: int," +
                        "acct_assoc_id: chararray," +
                        "cre_sys_cde: chararray,cre_sys_cde_desc: chararray,last_upd_sys_cde: chararray,last_upd_sys_cde_desc: chararray,kc_extl_stat_cde: chararray," +
                        "kc_extl_stat_cde_desc: chararray,src_sys_cde: chararray,src_sys_cde_desc: chararray,last_upd_tmst: chararray,cre_tmst: chararray,acct_stat_cde: chararray," +
                        "acct_stat_cde_desc: chararray,acct_prg_dte: datetime,sor_appl_id: chararray,lng_acct_nbr: chararray,rol_dtl: BAG{innertuple: TUPLE(cust_rol_cde: chararray," +
                        "cust_rol_cde_desc: chararray,prfl_id: long,cre_sys_cde: chararray,cre_sys_cde_desc: chararray,cre_tmst: chararray,last_upd_sys_cde: chararray," +
                        "last_upd_sys_cde_desc: chararray,last_upd_tmst: chararray)},fil_lod_tmst: chararray,acct_frst_3_nbr: chararray)});",
                //"dump data",
                "define UpdateReferenceCodeDescription com.kohls.bigdata.evoc.udf.UpdateReferenceCodeDescription();",
                "descr = foreach data generate flatten(UpdateReferenceCodeDescription(*));",
                "STORE descr INTO 'output';"
        };

        PigTest test = new PigTest(script);

        String[] input = new String[] {
                "(0031097302,KC)\t{(0031097302,KC,Kohl'sAccount,2014-08-26T00:00:00.000-05:00,,EN,DESCRIPTION_NOT_UPDATED,9,,2017-12-31,N,1126,,FD,FirstData,,,FD," +
                        ",FD,FirstData,2016-12-28T17:24:47.000-06:00,2016-12-28T14:54:56.220-06:00,9,,,0070287506,3847649668947302,{(,,,,,,,,)},,003)}\t" +
                        "{(0031097302,KC,Kohl's Charge Account,2014-08-26T00:00:00.000-05:00,,EN,American English and Default,9,Default - Not MVC," +
                        ",N,1126,1112233,FD,First Data,FD,First Data,,,FD,First Data," +
                        "2016-12-28T17:24:47.000-06:00,2016-12-28T14:54:56.220-06:00,9,,,0070287506,3847649668947302,{(,,,,,,,,)},2016-12-28T14:54:56.220-06:00,003" +
                        "2017-07-19T04:02:35.555,003)}",
        };

        String[] output = new String[] {
                "(0031097302,KC,Kohl'sAccount,2014-08-26T00:00:00.000-05:00,,EN,American English and Default,9,,,N,1126,1112233,FD,FirstData,FD,,,,FD,FirstData,2016-12-28T17:24:47.000-06:00,2016-12-28T14:54:56.220-06:00,9,,,0070287506,3847649668947302,{(,,,,,,,,)},2016-12-28T14:54:56.220-06:00,0032017-07-19T04:02:35.555,003)"
        };

        test.assertOutput("data", input, "descr", output);
    }

}