package com.kohls.bigdata.evoc.udf;

import org.apache.pig.pigunit.PigTest;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

public class AddRefCodeDescColumnsTest {

    private java.nio.file.Path refExtractPath;

    @Before
    public void setup() throws Exception {
        InputStream sampleData = getClass().getResourceAsStream("/ref_val.orc");
        refExtractPath = Files.createTempFile(null, null);
        Files.copy(sampleData, refExtractPath, StandardCopyOption.REPLACE_EXISTING);
    }

    @Test
    /**
     * Test input with simple flat structure that has two reference code columns.
     * UDF is expected to replace two "*_reference_code" columns with proper "*_description" columns.
     */
    public void testSimpleColumns() throws Exception {
        String[] script = new String[] {
                "data = LOAD 'input' AS (account_type_code:CHARARRAY, account_type_reference_code:CHARARRAY, " +
                        "country_type_code, country_type_reference_code);",
                String.format(
                        "define add_ref_desc com.kohls.bigdata.evoc.udf.AddRefCodeDescColumns('%s', 'false');",
                        refExtractPath),
                "descr = foreach data generate flatten(add_ref_desc(*));",
                "STORE descr INTO 'output';"
        };

        PigTest test = new PigTest(script);

        String[] input = new String[] {
                "LOY\tACCT\tNG\tCNTRY",
                "LOY\tACCT\tUS\tCNTRY"
        };

        String[] output = new String[] {
                "(LOY,Loyalty,NG,NIGERIA)",
                "(LOY,Loyalty,US,UNITED STATES)"
        };

        test.assertOutput("data", input, "descr", output);
    }

    @Test
    /**
     * Test hierarchical input with two reference code columns inside of the bag.
     * Verify that empty bags and empty reference values are processed correctly.
     */
    public void testTwoBags() throws Exception {
        String[] script = new String[] {
                "data = LOAD 'input' AS (id:CHARARRAY, b1:BAG{t:TUPLE(prop1_code:CHARARRAY, prop1_reference_code:CHARARRAY, " +
                        "prop2_code:CHARARRAY, prop2_reference_code:CHARARRAY)});",
                //"dump data",
                String.format(
                        "define add_ref_desc com.kohls.bigdata.evoc.udf.AddRefCodeDescColumns('%s', 'false');",
                        refExtractPath),
                "descr = foreach data generate flatten(add_ref_desc(*));",
                "STORE descr INTO 'output';"
        };

        PigTest test = new PigTest(script);

        String[] input = new String[] {
                "1\t{(LOY,ACCT,NG,CNTRY),(LOY,ACCT,US,CNTRY)}",
                "2\t{(,ACCT,US,CNTRY)}",
                "3\t{}",
                "4\t",
        };

        String[] output = new String[] {
                "(1,{(LOY,Loyalty,NG,NIGERIA),(LOY,Loyalty,US,UNITED STATES)})",
                "(2,{(,,US,UNITED STATES)})",
                "(3,{})",
                "(4,)",
        };

        test.assertOutput("data", input, "descr", output);
    }

}
