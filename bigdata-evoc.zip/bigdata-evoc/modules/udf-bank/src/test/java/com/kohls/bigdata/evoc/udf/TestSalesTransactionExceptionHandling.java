package com.kohls.bigdata.evoc.udf;

import org.apache.pig.pigunit.PigTest;
import org.junit.Test;

public class TestSalesTransactionExceptionHandling {

     @Test
    public void TestGroup() throws Exception {
        String[] script = new String[] {
                "data = LOAD 'input' AS (trn_sls_dte: chararray,str_nbr: chararray,rgst_id: chararray,trn_nbr: chararray," +
                        "trn_strt_tm: chararray,sls_corr_seq_nbr: chararray,cust_id: chararray,cust_idd_ind:chararray," +
                        "ord_nbr: chararray,ord_dte: chararray,llty_acct_nbr: chararray,llty_prfl_id: chararray," +
                        "llty_prfl_ctg_typ_cde: chararray,llty_prfl_ctg_typ_cde_desc: chararray,e_src_sys_id: chararray," +
                        "e_prfl_id: chararray,e_prfl_ctg_typ_cde: chararray,e_prfl_ctg_typ_cde_desc: chararray,ei_str_id: chararray," +
                        "cr_crd_dtl: {(tndr_typ_cde: chararray,crd_nbr: chararray,cr_crd_cust_nm: chararray,crd_typ_cde: chararray,crd_typ_cde_desc: chararray," +
                        "prfl_id: chararray,prfl_ctg_typ_cde: chararray,prfl_ctg_typ_cde_desc: chararray,prmier_acct_stat_cde: chararray," +
                        "prmier_acct_stat_cde_desc: chararray)});",
                "define SalesTransactionExceptionHandling com.kohls.bigdata.evoc.udf.SalesTransactionExceptionHandling();",
                "descr = foreach data generate flatten(SalesTransactionExceptionHandling(*));",
                "STORE descr INTO 'output';" };

        String[] input = new String[] {
                "2014-01-01\t1172\t1\t4798\t07:51:11\t0\t1\t\t1923350129\t2015-01-01 15:37:17.679\t\t\t\t\t\t\t\t\t734\t{(04,12345,xyz,KC,KohlsCharge,1,KCC,Loyalty,M,Re Qualified),(04,1234,xyz,KC,KohlsCharge,,KCC,Loyalty,M,Re Qualified)}",
                "2014-01-01\t1172\t1\t4798\t07:51:11\t0\t1\t\t1923350129\t2015-01-01 15:37:17.679\t\t\t\t\t\t\t\t\t734\t{(04,12345,xyz,KC,KohlsCharge,,KCC,Loyalty,M,Re Qualified)}",
                "2014-01-01\t1172\t1\t4798\t07:51:11\t0\t1\t\t1923350129\t2015-01-01 15:37:17.679\t1234\t\t\t\t\t\t\t\t734\t{(04,,xyz,KC,KohlsCharge,,KCC,Loyalty,M,Re Qualified)}",
                "2014-01-01\t1172\t1\t4798\t07:51:11\t0\t1\t\t1923350129\t2015-01-01 15:37:17.679\t\t\t\t\t143\t\t\t\t734\t{(04,12345,xyz,KC,KohlsCharge,1,KCC,Loyalty,M,Re Qualified)}",
                "2014-01-01\t\t1\t4798\t07:51:11\t0\t1\t\t1923350129\t2015-01-01 15:37:17.679\t\t\t\t\t\t\t\t\t734\t{(04,12345,xyz,KC,KohlsCharge,1,KCC,Loyalty,M,Re Qualified)}",
                "2014-01-01\t1172\t1\t4798\t07:51:11\t0\t1\t\t1923350129\t2015-01-01 15:37:17.679\t\t\t\t\t\t\t\t\t734\t{(04,12345,xyz,KC,KohlsCharge,1,KCC,Loyalty,M,Re Qualified)}"

        };

        String[] output = new String[] {
                "(2014-01-01,1172,1,4798,07:51:11,0,1,,1923350129,2015-01-01 15:37:17.679,,,,,,,,,734,{(04,12345,xyz,KC,KohlsCharge,1,KCC,Loyalty,M,Re Qualified),(04,1234,xyz,KC,KohlsCharge,,KCC,Loyalty,M,Re Qualified)},Profile not found in DDH [cr_crd_dtl]prfl_id,Warning)",
         "(2014-01-01,1172,1,4798,07:51:11,0,1,,1923350129,2015-01-01 15:37:17.679,,,,,,,,,734,{(04,12345,xyz,KC,KohlsCharge,,KCC,Loyalty,M,Re Qualified)},Profile not found in DDH [cr_crd_dtl]prfl_id,Warning)",
         "(2014-01-01,1172,1,4798,07:51:11,0,1,,1923350129,2015-01-01 15:37:17.679,1234,,,,,,,,734,{(04,,xyz,KC,KohlsCharge,,KCC,Loyalty,M,Re Qualified)},Profile not found in DDH llty_prfl_id,Warning)",
         "(2014-01-01,1172,1,4798,07:51:11,0,1,,1923350129,2015-01-01 15:37:17.679,,,,,143,,,,734,{(04,12345,xyz,KC,KohlsCharge,1,KCC,Loyalty,M,Re Qualified)},Profile not found in DDH e_prfl_id,Warning)",
         "(2014-01-01,,1,4798,07:51:11,0,1,,1923350129,2015-01-01 15:37:17.679,,,,,,,,,734,{(04,12345,xyz,KC,KohlsCharge,1,KCC,Loyalty,M,Re Qualified)},Nulls values in a not null field str_nbr,Error)",
         "(2014-01-01,1172,1,4798,07:51:11,0,1,,1923350129,2015-01-01 15:37:17.679,,,,,,,,,734,{(04,12345,xyz,KC,KohlsCharge,1,KCC,Loyalty,M,Re Qualified)},noError,GoodRecord)",
        };

        PigTest test = new PigTest(script);

        test.assertOutput("data", input, "descr", output);
    }
}