package com.kohls.bigdata.evoc.udf;

import org.apache.pig.pigunit.PigTest;
import org.junit.Test;

public class TestProfileExceptionHandling {
    @Test
    public void TestGroup() throws Exception {
        String[] script = new String[] {
                "data = LOAD 'input' AS (profile_identifier:CHARARRAY,customer_identifier:CHARARRAY,profile_category_type_code:CHARARRAY,profile_category_type_code_description:CHARARRAY,"
                        + "source_system_identifier:CHARARRAY,source_system_code:CHARARRAY,"
                        + "source_system_code_description:CHARARRAY,create_system_code:CHARARRAY,create_system_code_description:CHARARRAY,last_update_system_code:CHARARRAY,last_update_system_code_description:CHARARRAY,"
                        + "create_timestamp:CHARARRAY,last_update_timestamp:CHARARRAY,preferred_profile_indicator:CHARARRAY,"
                        + "e_gst_lst_dtl:"
                        + "BAG{t:TUPLE(source_system_identifier:CHARARRAY,source_system_code:CHARARRAY,source_system_code_description:CHARARRAY,"
                        +"create_timestamp:CHARARRAY)},"
                        + "attr:"
                        + "BAG{t:TUPLE(customer_attribute_identifier:CHARARRAY, data_state_code:CHARARRAY, "
                        + "data_state_code_description:CHARARRAY, first_name:CHARARRAY,"
                        + "middle_name:CHARARRAY,last_name:CHARARRAY,"
                        + "name_prefix_text:CHARARRAY,name_suffix_text:CHARARRAY,birth_date:CHARARRAY," +
                        "user_name:CHARARRAY,customer_start_date:CHARARRAY,create_system_code:CHARARRAY," +
                        "create_system_code_description:CHARARRAY,last_update_system_code:CHARARRAY,last_update_system_code_description:CHARARRAY,create_timestamp:CHARARRAY,last_update_timestamp:CHARARRAY," +
                        "gender_code:CHARARRAY,gender_code_description:CHARARRAY,social_security_number:CHARARRAY," +
                        "deceased_indicator:CHARARRAY,name_check_score_number:CHARARRAY,name_check_1_code:CHARARRAY," +
                        "name_check_1_code_description:CHARARRAY,name_check_2_code:CHARARRAY,name_check_2_code_description:CHARARRAY," +
                        "name_check_3_code:CHARARRAY,name_check_3_code_description:CHARARRAY)},"
                        + "addr:BAG{t:TUPLE(customer_mailing_address_identifier:CHARARRAY, data_state_code:CHARARRAY,"
                        + "data_state_code_description:CHARARRAY, mailing_contact_type_code:CHARARRAY,"
                        + "mailing_contact_type_code_description:CHARARRAY,address_line_1_text:CHARARRAY,"
                        + "address_line_2_text:CHARARRAY,address_line_3_text:CHARARRAY,city_name:CHARARRAY," +
                        "state_province_code:CHARARRAY,state_province_code_description:CHARARRAY,postal_code:CHARARRAY," +
                        "postal_extension_code:CHARARRAY,county_code:CHARARRAY,country_code:CHARARRAY," +
                        "country_code_description:CHARARRAY,create_system_code:CHARARRAY,create_system_code_description:CHARARRAY,last_update_system_code:CHARARRAY,last_update_system_code_description:CHARARRAY," +
                        "create_timestamp:CHARARRAY,last_update_timestamp:CHARARRAY,deliverability_code:CHARARRAY," +
                        "deliverability_code_description:CHARARRAY,prison_address_indicator:CHARARRAY,primary_contact_indicator:CHARARRAY)}," +
                        "email:BAG{t:TUPLE(customer_email_identifier:CHARARRAY, data_state_code:CHARARRAY," +
                        "data_state_code_description:CHARARRAY, email_address:CHARARRAY," +
                        "email_contact_usage_code:CHARARRAY,email_contact_usage_code_description:CHARARRAY," +
                        "primary_contact_indicator:CHARARRAY,create_system_code:CHARARRAY,create_system_code_description:CHARARRAY,last_update_system_code:CHARARRAY,last_update_system_code_description:CHARARRAY," +
                        "create_timestamp:CHARARRAY,last_update_timestamp:CHARARRAY,email_format_valid_indicator:CHARARRAY," +
                        "email_usability_code:CHARARRAY,email_usability_code_description:CHARARRAY)}," +
                        "tel:BAG{t:TUPLE(customer_telephone_identifier:CHARARRAY, data_state_code:CHARARRAY," +
                        "data_state_code_description:CHARARRAY, telephone_number:CHARARRAY," +
                        "telephone_contact_usage_code:CHARARRAY,telephone_contact_usage_code_description:CHARARRAY," +
                        "telephone_number_contact_status_code:CHARARRAY,telephone_number_contact_status_code_description:CHARARRAY,create_system_code:CHARARRAY," +
                        "create_system_code_description:CHARARRAY,last_update_system_code:CHARARRAY,last_update_system_code_description:CHARARRAY,create_timestamp:CHARARRAY,last_update_timestamp:CHARARRAY," +
                        "telephone_number_valid_indicator:CHARARRAY,primary_contact_indicator:CHARARRAY)}," +
                        "crd:BAG{t:TUPLE(customer_card_identifier:CHARARRAY, card_number:CHARARRAY,card_type_code:CHARARRAY," +
                        "card_type_code_description:CHARARRAY,cardholder_name:CHARARRAY,card_expiration_date:CHARARRAY," +
                        "account_number:CHARARRAY,create_system_code:CHARARRAY,create_system_code_description:CHARARRAY,last_update_system_code:CHARARRAY,last_update_system_code_description:CHARARRAY," +
                        "create_timestamp:CHARARRAY,last_update_timestamp:CHARARRAY," +
                        "store_number:CHARARRAY,long_card_number:CHARARRAY)}," +
                        "lnk:BAG{t:TUPLE(linked_profile_identifier:CHARARRAY, profile_explicit_link_indicator:CHARARRAY,profile_link_reason_code:CHARARRAY," +
                        "profile_link_reason_code_description:CHARARRAY,profile_link_source_code:CHARARRAY,profile_link_source_code_description:CHARARRAY,  last_update_timestamp:CHARARRAY)}," +
                        "suppml_attr:BAG{t:TUPLE(profile_link_match_code:CHARARRAY,profile_link_match_code_description:CHARARRAY,address_link_match_code:CHARARRAY," +
                        "address_link_match_code_description:CHARARRAY,append_match_verify_code:CHARARRAY,append_match_verify_code_description:CHARARRAY," +
                        "  append_match_confidence_level_code:CHARARRAY,append_match_confidence_level_code_description:CHARARRAY," +
                        "create_system_code:CHARARRAY,create_system_code_description:CHARARRAY,last_update_system_code:CHARARRAY,last_update_system_code_description:CHARARRAY,create_timestamp:CHARARRAY,last_update_timestamp:CHARARRAY)}," +
                        "fil_lod_tmst:CHARARRAY,dlt_ind:CHARARRAY,batchid:LONG);",
                "define ProfileExceptionHandling com.kohls.bigdata.evoc.udf.ProfileExceptionHandling();",
                "descr = foreach data generate flatten(ProfileExceptionHandling(*));",
                "STORE descr INTO 'output';" };

        String[] input = new String[] {
                "2506\t2507\tESR\tEcommerce - Registered\t10009023742\tATG\tATG\tWB\tWeb Store (Batch)\tDUMMY\tDUMMY_DESCRIPTION\t2016-08-26T03:59:15.466-05:00\t" +
                        "2016-08-26T03:59:15.000-05:00\tN\t{(10006777821,ATG,ATG,2016-12-22T04:20:06.000-06:00)}\t{(2713,SRC,Original Data From Source,test,,test,,,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,,,,,,,,,)}\t" +
                        "{(2625,SRC,Original Data From Source,,,9477 Santa Monica Blvd,test,,Beverly Hills,CA,Calfornia,90210,,,US,United States,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,,)}\t" +
                        "{(2606,SRC,Original Data From Source,newuser1461064467403@bh.kohls.com,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,)}\t" +
                        "{(2645,SRC,Original Data From Source,1234567890,,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,)}\t" +
                        "{(123,592010952102,KC,kohls cahrge,pooman,1111-11-11,3004742321,FD,First Data,DUMMY,DUMMY_DESCRIPTION,2016-08-24T16:19:30.000-05:00,2016-08-24T16:19:30.000-05:00,1234,134663247288672102)}\t" +
                        "{(123,Y,ABC,ppppp,ABX,ppppp,2016-08-26T03:59:15.000-05:00)}" +
                        "\t{(ABC,abcd,ABC,abcd,BCD,bcde,KBC,kaunbanegacrpti,ATS,ats,DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:15.000-05:00,2016-08-26T03:59:15.000-05:00)}\t" +
                        "2016-11-28T02:08:01.712\t\t20161128020646",
                "2507\t2508\tESR\t\t10009023742\tATG\tATG\tWB\tWeb Store (Batch)\tDUMMY\tDUMMY_DESCRIPTION\t2016-08-2603:59:15.466-05:00\t" +
                        "2016-08-26T03:59:15.000-05:00\tN\t{(10006777821,ATG,ATG,2016-12-22T04:20:06.000-06:00)}\t{(2713,SRC,Original Data From Source,test,,test,,,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,,,,,,,,,)}\t" +
                        "{(2625,SRC,Original Data From Source,,,9477 Santa Monica Blvd,test,,Beverly Hills,CA,Calfornia,90210,,,US,United States,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,,)}\t" +
                        "{(2606,SRC,Original Data From Source,newuser1461064467403@bh.kohls.com,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,)}\t" +
                        "{(2645,SRC,Original Data From Source,1234567890,,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,)}\t" +
                        "{(123,592010952102,KC,kohls cahrge,pooman,1111-11-11,3004742321,FD,First Data,DUMMY,DUMMY_DESCRIPTION,2016-08-24T16:19:30.000-05:00,2016-08-24T16:19:30.000-05:00,1234,134663247288672102)}\t" +
                        "{(123,Y,ABC,ppppp,ABX,ppppp,2016-08-26T03:59:15.000-05:00)}" +
                        "\t{(ABC,abcd,ABC,abcd,BCD,bcde,KBC,kaunbanegacrpti,ATS,ats,DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:15.000-05:00,2016-08-26T03:59:15.000-05:00)}\t" +
                        "2016-11-28T02:08:01.712\t\t20161128020646",
                "2506\t2507\tESR\t\t10009023742\tATG\tATG\tWB\t\tDUMMY\tDUMMY_DESCRIPTION\t2016-08-26T03:59:15.466-05:00\t" +
                        "2016-08-26T03:59:15.000-05:00\tN\t{(10006777821,ATG,ATG,2016-12-22T04:20:06.000-06:00)}\t{(2713,SRC,Original Data From Source,test,,test,,,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,,,,,,,,,)}\t" +
                        "{(2625,SRC,Original Data From Source,,,9477 Santa Monica Blvd,test,,Beverly Hills,CA,Calfornia,90210,,,US,United States,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,,)}\t" +
                        "{(2606,SRC,Original Data From Source,newuser1461064467403@bh.kohls.com,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,)}\t" +
                        "{(2645,SRC,Original Data From Source,1234567890,,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,)}\t" +
                        "{(123,592010952102,KC,kohls cahrge,pooman,1111-11-11,3004742321,FD,First Data,DUMMY,DUMMY_DESCRIPTION,2016-08-24T16:19:30.000-05:00,2016-08-24T16:19:30.000-05:00,1234,134663247288672102)}\t" +
                        "{(123,Y,ABC,ppppp,ABX,ppppp,2016-08-26T03:59:15.000-05:00)}" +
                        "\t{(ABC,abcd,ABC,abcd,BCD,bcde,KBC,kaunbanegacrpti,ATS,ats,DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:15.000-05:00,2016-08-26T03:59:15.000-05:00)}\t" +
                        "2016-11-28T02:08:01.712\t\t20161128020646",
                "2506\t2507\tESR\tEcommerce - Registered\t10009023742\tATG\tATG\tWB\tWeb Store (Batch)\tDUMMY\tDUMMY_DESCRIPTION\t2016-08-26T03:59:15.466-05:00\t" +
                        "2016-08-26T03:59:15.000-05:00\tN\t{(10006777821,ATG,ATG,2016-12-22T04:20:06.000-06:00)}\t{(2713,SRC,Original Data From Source,test,,test,,,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,,,,,,,,,)}\t" +
                        "{(2625,SRC,,,,9477 Santa Monica Blvd,test,,Beverly Hills,CA,Calfornia,90210,,,US,United States,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,,)}\t" +
                        "{(2606,SRC,Original Data From Source,newuser1461064467403@bh.kohls.com,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,)}\t" +
                        "{(2645,SRC,Original Data From Source,1234567890,,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,)}\t" +
                        "{(123,592010952102,KC,kohls cahrge,pooman,1111-11-11,3004742321,FD,First Data,DUMMY,DUMMY_DESCRIPTION,2016-08-24T16:19:30.000-05:00,2016-08-24T16:19:30.000-05:00,1234,134663247288672102)}\t" +
                        "{(ABC,Y,ABC,ppppp,ABX,ppppp,2016-08-26T03:59:15.000-05:00)}" +
                        "\t{(ABC,abcd,ABC,abcd,BCD,bcde,KBC,kaunbanegacrpti,ATS,ats,DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:15.000-05:00,2016-08-26T03:59:15.000-05:00)}\t" +
                        "2016-11-28T02:08:01.712\t\t20161128020646",

        };



        String[] output = new String[] {
                "(2506,2507,ESR,Ecommerce - Registered,10009023742,ATG,ATG,WB,Web Store (Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:15.466-05:00," +
                        "2016-08-26T03:59:15.000-05:00,N,{(10006777821,ATG,ATG,2016-12-22T04:20:06.000-06:00)},{(2713,SRC,Original Data From Source,test,,test,,,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,,,,,,,,,)}," +
                        "{(2625,SRC,Original Data From Source,,,9477 Santa Monica Blvd,test,,Beverly Hills,CA,Calfornia,90210,,,US,United States,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,,)}" +
                        ",{(2606,SRC,Original Data From Source,newuser1461064467403@bh.kohls.com,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,)}," +
                        "{(2645,SRC,Original Data From Source,1234567890,,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,)}," +
                        "{(123,592010952102,KC,kohls cahrge,pooman,1111-11-11,3004742321,FD,First Data,DUMMY,DUMMY_DESCRIPTION,2016-08-24T16:19:30.000-05:00,2016-08-24T16:19:30.000-05:00,1234,134663247288672102)}" +
                        ",{(123,Y,ABC,ppppp,ABX,ppppp,2016-08-26T03:59:15.000-05:00)}," +
                        "{(ABC,abcd,ABC,abcd,BCD,bcde,KBC,kaunbanegacrpti,ATS,ats,DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:15.000-05:00,2016-08-26T03:59:15.000-05:00)}," +
                        "2016-11-28T02:08:01.712,,20161128020646,noError,GoodRecord)",
                "(2507,2508,ESR,,10009023742,ATG,ATG,WB,Web Store (Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-2603:59:15.466-05:00," +
                        "2016-08-26T03:59:15.000-05:00,N,{(10006777821,ATG,ATG,2016-12-22T04:20:06.000-06:00)},{(2713,SRC,Original Data From Source,test,,test,,,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,,,,,,,,,)}," +
                        "{(2625,SRC,Original Data From Source,,,9477 Santa Monica Blvd,test,,Beverly Hills,CA,Calfornia,90210,,,US,United States,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,,)}" +
                        ",{(2606,SRC,Original Data From Source,newuser1461064467403@bh.kohls.com,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,)}," +
                        "{(2645,SRC,Original Data From Source,1234567890,,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,)}," +
                        "{(123,592010952102,KC,kohls cahrge,pooman,1111-11-11,3004742321,FD,First Data,DUMMY,DUMMY_DESCRIPTION,2016-08-24T16:19:30.000-05:00,2016-08-24T16:19:30.000-05:00,1234,134663247288672102)}" +
                        ",{(123,Y,ABC,ppppp,ABX,ppppp,2016-08-26T03:59:15.000-05:00)}," +
                        "{(ABC,abcd,ABC,abcd,BCD,bcde,KBC,kaunbanegacrpti,ATS,ats,DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:15.000-05:00,2016-08-26T03:59:15.000-05:00)}," +
                        "2016-11-28T02:08:01.712,,20161128020646,Invalid timestamp format create_timestamp,Error)",
                "(2506,2507,ESR,,10009023742,ATG,ATG,WB,,DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:15.466-05:00," +
                        "2016-08-26T03:59:15.000-05:00,N,{(10006777821,ATG,ATG,2016-12-22T04:20:06.000-06:00)},{(2713,SRC,Original Data From Source,test,,test,,,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,,,,,,,,,)}," +
                        "{(2625,SRC,Original Data From Source,,,9477 Santa Monica Blvd,test,,Beverly Hills,CA,Calfornia,90210,,,US,United States,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,,)}" +
                        ",{(2606,SRC,Original Data From Source,newuser1461064467403@bh.kohls.com,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,)}," +
                        "{(2645,SRC,Original Data From Source,1234567890,,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,)}," +
                        "{(123,592010952102,KC,kohls cahrge,pooman,1111-11-11,3004742321,FD,First Data,DUMMY,DUMMY_DESCRIPTION,2016-08-24T16:19:30.000-05:00,2016-08-24T16:19:30.000-05:00,1234,134663247288672102)}" +
                        ",{(123,Y,ABC,ppppp,ABX,ppppp,2016-08-26T03:59:15.000-05:00)}," +
                        "{(ABC,abcd,ABC,abcd,BCD,bcde,KBC,kaunbanegacrpti,ATS,ats,DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:15.000-05:00,2016-08-26T03:59:15.000-05:00)}," +
                        "2016-11-28T02:08:01.712,,20161128020646,Reference value violation profile_category_type_code,Warning)",
                "(2506,2507,ESR,Ecommerce - Registered,10009023742,ATG,ATG,WB,Web Store (Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:15.466-05:00," +
                        "2016-08-26T03:59:15.000-05:00,N,{(10006777821,ATG,ATG,2016-12-22T04:20:06.000-06:00)},{(2713,SRC,Original Data From Source,test,,test,,,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,,,,,,,,,)}," +
                        "{(2625,SRC,,,,9477 Santa Monica Blvd,test,,Beverly Hills,CA,Calfornia,90210,,,US,United States,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,,)}" +
                        ",{(2606,SRC,Original Data From Source,newuser1461064467403@bh.kohls.com,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,,)}," +
                        "{(2645,SRC,Original Data From Source,1234567890,,,,,WB,Web Store(Batch),DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:43.712-05:00,2016-08-26T03:59:44.000-05:00,,)}," +
                        "{(123,592010952102,KC,kohls cahrge,pooman,1111-11-11,3004742321,FD,First Data,DUMMY,DUMMY_DESCRIPTION,2016-08-24T16:19:30.000-05:00,2016-08-24T16:19:30.000-05:00,1234,134663247288672102)}" +
                        ",{(ABC,Y,ABC,ppppp,ABX,ppppp,2016-08-26T03:59:15.000-05:00)}," +
                        "{(ABC,abcd,ABC,abcd,BCD,bcde,KBC,kaunbanegacrpti,ATS,ats,DUMMY,DUMMY_DESCRIPTION,2016-08-26T03:59:15.000-05:00,2016-08-26T03:59:15.000-05:00)}," +
                        "2016-11-28T02:08:01.712,,20161128020646,Numeric value violation [lnk]linked_profile_identifier,Error)"

        };

        PigTest test = new PigTest(script);

        test.assertOutput("data", input, "descr", output);
    }
}