package com.kohls.bigdata.evoc.udf;

import org.apache.pig.pigunit.PigTest;
import org.junit.Test;

public class TestSingleProfileIdDecider {

    @Test
    /**
     * Test hierarchical input with two reference code columns inside of the bag.
     * Verify that empty bags and empty reference values are processed correctly.
     */
    public void testTwoBags() throws Exception {
        String[] script = new String[] {
                "data = LOAD 'input' AS (group: TUPLE(acct_nbr: chararray,acct_typ_cde: chararray),gen_account_filtered:BAG {t:TUPLE(cust_id: long,rec_pref:int,prfl_ctg_typ_cde:chararray)});",
                //"dump data",
                "define SingleProfileIdDecider com.kohls.bigdata.evoc.udf.SingleProfileIdDecider();",
                "descr = foreach data generate flatten(SingleProfileIdDecider(*));",
                "STORE descr INTO 'output';"
        };

        PigTest test = new PigTest(script);

        String[] input = new String[] {
                "(31097302,KC)\t{(31097300,1,KCC),(31097300,1,KCC),(31097300,1,KCC),(31097300,2,3CC),(31097322,2,3CC)}",
                "(31097302,KC)\t{(31097300,1,KCC),(31097301,1,KCC),(31097302,1,KCC),(31097312,2,3CC),(31097322,2,3CC)}",
                "(31097302,KC)\t{(31097300,2,3CC),(31097300,2,3CC),(31097302,3,LOY),(31097312,3,LOY),(31097322,4,ESR)}",
                "(31097302,KC)\t{(31097300,2,3CC),(31097302,3,LOY),(31097312,4,ESR),(31097322,5,3CC),(31097300,1,KCC)}"
        };

        String[] output = new String[] {
                "((31097302,KC),{(31097300,1,KCC),(31097300,1,KCC),(31097300,1,KCC),(31097300,2,3CC),(31097322,2,3CC)},31097300,0)",
                "((31097302,KC),{(31097300,1,KCC),(31097301,1,KCC),(31097302,1,KCC),(31097312,2,3CC),(31097322,2,3CC)},31097300,1)",
                "((31097302,KC),{(31097300,2,3CC),(31097300,2,3CC),(31097302,3,LOY),(31097312,3,LOY),(31097322,4,ESR)},31097300,0)",
                "((31097302,KC),{(31097300,2,3CC),(31097302,3,LOY),(31097312,4,ESR),(31097322,5,3CC),(31097300,1,KCC)},31097300,0)"
        };

        test.assertOutput("data", input, "descr", output);
    }

}