package com.kohls.bigdata.evoc.udf;

import org.apache.pig.pigunit.PigTest;
import org.junit.Test;

public class TestCustStartDateTieBreaker {

    @Test
    /**
     * Test hierarchical input with two reference code columns inside of the bag.
     * Verify that empty bags and empty reference values are processed correctly.
     */
    public void testTwoBags() throws Exception {
        String[] script = new String[] {
                "data = LOAD 'input' AS (group: (trn_sls_dte: chararray,str_nbr: int,rgst_id: int,trn_nbr: int," +
                        "trn_strt_tm: chararray,sls_corr_seq_nbr: int),gen_gen_not_trip_count_tie_cust_id: " +
                        "{(str_nbr: int,rgst_id: int,trn_nbr: int,trn_strt_tm: chararray,sls_corr_seq_nbr: int," +
                        "cust_id: long,cust_idd_ind: chararray,ord_nbr: chararray,ord_dte: chararray,crd_nbr: chararray," +
                        "cr_crd_cust_nm: chararray,crd_typ_cde: chararray,crd_typ_cde_desc: chararray,prfl_id: long," +
                        "prfl_ctg_typ_cde: chararray,prfl_ctg_typ_cde_desc: chararray,prmier_acct_stat_cde: chararray," +
                        "prmier_acct_stat_cde_desc: chararray,llty_acct_nbr: chararray,llty_prfl_id: long," +
                        "llty_prfl_ctg_typ_cde: chararray,llty_prfl_ctg_typ_cde_desc: chararray,e_src_sys_id: chararray," +
                        "e_prfl_id: long,e_prfl_ctg_typ_cde: chararray,e_prfl_ctg_typ_cde_desc: chararray,ei_str_id: int," +
                        "fil_lod_tmst: chararray,btch_id: long,last_upd_tmst: chararray,trn_sls_dte: chararray,rec_pref: int,cust_strt_dte: chararray)});",
                //"dump data",
                "define CustStartDateTieBreaker com.kohls.bigdata.evoc.udf.CustStartDateTieBreaker();",
                "descr = foreach data generate flatten(CustStartDateTieBreaker(*));",
                "STORE descr INTO 'output';"
        };

        PigTest test = new PigTest(script);

        String[] input = new String[] {
                "(2017-06-13,123,432,500,10:21:23,1)\t{(123,432,500,10:21:23,1,1111,N,12258,2017-06-14,10,GHI,MC,MC,12300,3CC,Kohls Charge,,,,,,,,,,,998,2017-09-12T14:52:49.709,1505536726484,2017-09-15T23:38:47.158,2017-06-13,4,2016-08-30),(123,432,500,10:21:23,1,11111,Y,12258,2017-06-14,111,GHIJ,MC,MC,12301,3CC,Kohls Charge,,,,,,,,,,,998,2017-09-12T14:52:49.709,1505536726484,2017-09-15T23:38:47.158,2017-06-13,4,2017-08-29)}",
                "(2017-06-13,123,432,500,10:21:23,1)\t{(123,432,500,10:21:23,1,1111,N,12258,2017-06-14,10,GHI,MC,MC,12300,3CC,Kohls Charge,,,,,,,,,,,998,2017-09-12T14:52:49.709,1505536726484,2017-09-15T23:38:47.158,2017-06-13,3,),(123,432,500,10:21:23,1,11111,Y,12258,2017-06-14,111,GHIJ,MC,MC,12301,3CC,Kohls Charge,,,,,,,,,,,998,2017-09-12T14:52:49.709,1505536726484,2017-09-15T23:38:47.158,2017-06-13,3,)}",
                "(2017-06-13,123,432,500,10:21:23,1)\t{(123,432,500,10:21:23,1,1111,N,12258,2017-06-14,10,GHI,MC,MC,12300,3CC,Kohls Charge,,,,,,,,,,,998,2017-09-12T14:52:49.709,1505536726484,2017-09-15T23:38:47.158,2017-06-13,4,2016-08-30),(123,432,500,10:21:23,1,11111,Y,12258,2017-06-14,111,GHIJ,MC,MC,12301,3CC,Kohls Charge,,,,,,,,,,,998,2017-09-12T14:52:49.709,1505536726484,2017-09-15T23:38:47.158,2017-06-13,4,2016-08-30),(123,432,500,10:21:23,1,1000,N,12258,2017-06-14,10,GHI,MC,MC,12300,3CC,Kohls Charge,,,,,,,,,,,998,2017-09-12T14:52:49.709,1505536726484,2017-09-15T23:38:47.158,2017-06-13,6,2015-08-30)}",

        };

        String[] output = new String[] {
                "((2017-06-13,123,432,500,10:21:23,1),{(123,432,500,10:21:23,1,1111,N,12258,2017-06-14,10,GHI,MC,MC,12300,3CC,Kohls Charge,,,,,,,,,,,998,2017-09-12T14:52:49.709,1505536726484,2017-09-15T23:38:47.158,2017-06-13,4,2016-08-30),(123,432,500,10:21:23,1,11111,Y,12258,2017-06-14,111,GHIJ,MC,MC,12301,3CC,Kohls Charge,,,,,,,,,,,998,2017-09-12T14:52:49.709,1505536726484,2017-09-15T23:38:47.158,2017-06-13,4,2017-08-29)},1111,0)",
                "((2017-06-13,123,432,500,10:21:23,1),{(123,432,500,10:21:23,1,1111,N,12258,2017-06-14,10,GHI,MC,MC,12300,3CC,Kohls Charge,,,,,,,,,,,998,2017-09-12T14:52:49.709,1505536726484,2017-09-15T23:38:47.158,2017-06-13,3,),(123,432,500,10:21:23,1,11111,Y,12258,2017-06-14,111,GHIJ,MC,MC,12301,3CC,Kohls Charge,,,,,,,,,,,998,2017-09-12T14:52:49.709,1505536726484,2017-09-15T23:38:47.158,2017-06-13,3,)},1111,0)" ,
                "((2017-06-13,123,432,500,10:21:23,1),{(123,432,500,10:21:23,1,1111,N,12258,2017-06-14,10,GHI,MC,MC,12300,3CC,Kohls Charge,,,,,,,,,,,998,2017-09-12T14:52:49.709,1505536726484,2017-09-15T23:38:47.158,2017-06-13,4,2016-08-30),(123,432,500,10:21:23,1,11111,Y,12258,2017-06-14,111,GHIJ,MC,MC,12301,3CC,Kohls Charge,,,,,,,,,,,998,2017-09-12T14:52:49.709,1505536726484,2017-09-15T23:38:47.158,2017-06-13,4,2016-08-30),(123,432,500,10:21:23,1,1000,N,12258,2017-06-14,10,GHI,MC,MC,12300,3CC,Kohls Charge,,,,,,,,,,,998,2017-09-12T14:52:49.709,1505536726484,2017-09-15T23:38:47.158,2017-06-13,6,2015-08-30)},1111,0)"
 };

        test.assertOutput("data", input, "descr", output);
    }
}