package com.kohls.bigdata.evoc.udf;

import org.apache.pig.pigunit.PigTest;
import org.junit.Test;

public class TestTripCountTieBreaker {

    @Test
    /**
     * Test hierarchical input with two reference code columns inside of the bag.
     * Verify that empty bags and empty reference values are processed correctly.
     */
    public void testTwoBags() throws Exception {
        String[] script = new String[] {
                "data = LOAD 'input' AS (group: TUPLE(acct_nbr: chararray,acct_typ_cde: chararray),gen_account_filtered:BAG {t:TUPLE(cust_id: long,rec_pref:int,prfl_ctg_typ_cde:chararray,trip_count: int)});",
                //"dump data",
                "define TripCountTieBreaker com.kohls.bigdata.evoc.udf.TripCountTieBreaker();",
                "descr = foreach data generate flatten(TripCountTieBreaker(*));",
                "STORE descr INTO 'output';"
        };

        PigTest test = new PigTest(script);

        String[] input = new String[] {
                "(0031097302,KC)\t{(0031097300,1,KCC,9),(0031097301,1,KCC,10),(0031097302,1,KCC,8),(0031097312,1,KCC,7),(0031097322,2,3CC,12)}",
                "(0031097302,KC)\t{(0031097300,1,KCC,9),(0031097301,1,KCC,10),(0031097302,1,KCC,8),(0031097312,2,3CC,12),(0031097322,2,3CC,12)}",
                "(0031097302,KC)\t{(0031097300,1,KCC,10),(0031097301,1,KCC,10),(0031097302,1,KCC,8),(0031097312,2,3CC,12),(0031097322,2,3CC,12)}"
        };

        String[] output = new String[] {
                "((0031097302,KC),{(31097300,1,KCC,9),(31097301,1,KCC,10),(31097302,1,KCC,8),(31097312,1,KCC,7),(31097322,2,3CC,12)},31097301,0)",
                "((0031097302,KC),{(31097300,1,KCC,9),(31097301,1,KCC,10),(31097302,1,KCC,8),(31097312,2,3CC,12),(31097322,2,3CC,12)},31097301,0)",
                "((0031097302,KC),{(31097300,1,KCC,10),(31097301,1,KCC,10),(31097302,1,KCC,8),(31097312,2,3CC,12),(31097322,2,3CC,12)},31097300,1)"
        };

        test.assertOutput("data", input, "descr", output);
    }

}