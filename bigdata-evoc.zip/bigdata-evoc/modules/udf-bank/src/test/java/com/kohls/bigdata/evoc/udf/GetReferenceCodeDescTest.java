package com.kohls.bigdata.evoc.udf;

import com.google.common.collect.Lists;
import org.apache.hadoop.fs.Path;
import org.apache.pig.data.Tuple;
import org.apache.pig.data.TupleFactory;
import org.apache.pig.pigunit.PigTest;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

import static org.mockito.Mockito.*;

public class GetReferenceCodeDescTest {

    private java.nio.file.Path refExtractPath;

    @Before
    public void setup() throws Exception {
        InputStream sampleData = getClass().getResourceAsStream("/ref_val.orc");
        refExtractPath = Files.createTempFile(null, null);
        Files.copy(sampleData, refExtractPath, StandardCopyOption.REPLACE_EXISTING);
    }

    @Test
    public void testGetDesc() throws Exception {
        final ReferenceCodeFileReader reader = mock(ReferenceCodeFileReader.class);

        GetReferenceCodeDesc udf = new GetReferenceCodeDesc("fileloc") {
            @Override
            protected ReferenceCodeFileReader newReader(Path path) throws IOException {
                return reader;
            }
        };

        verifyNoMoreInteractions(reader);

        Tuple tuple1 = TupleFactory.getInstance().newTuple(Lists.newArrayList("code", "value"));
        udf.exec(tuple1);

        verify(reader).read();
        verify(reader).getDescription("code", "value");

        Tuple tuple2 = TupleFactory.getInstance().newTuple(Lists.newArrayList("code2", "value2"));
        udf.exec(tuple2);

        verify(reader).getDescription("code2", "value2");
        verifyNoMoreInteractions(reader);
    }

    @Test
    public void testWithPigUnit() throws Exception {
        String[] script = new String[] {
                "data = LOAD 'input' AS (ref_code:CHARARRAY, ref_value:CHARARRAY);",
                String.format(
                        "define ref_desc com.kohls.bigdata.evoc.udf.GetReferenceCodeDesc('%s', 'false');",
                        refExtractPath),
                "descr = foreach data generate ref_desc(ref_code, ref_value);",
                "STORE descr INTO 'output';"
        };

        PigTest test = new PigTest(script);

        String[] input = new String[] {
                "CNTRY\tNG",
                "CNTRY\tUS"
        };

        String[] output = new String[] {
            "(NIGERIA)",
            "(UNITED STATES)"
        };

        test.assertOutput("data", input, "descr", output);
    }

}
