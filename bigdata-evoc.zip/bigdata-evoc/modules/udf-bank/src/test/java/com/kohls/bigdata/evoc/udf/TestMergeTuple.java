package com.kohls.bigdata.evoc.udf;

import org.apache.pig.data.BagFactory;
import org.apache.pig.data.DataBag;
import org.apache.pig.data.Tuple;
import org.apache.pig.data.TupleFactory;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;

import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

/**
 * Created by tkmah7o on 6/8/17.
 */
public class TestMergeTuple {


    @Test
    public void testSimple () throws IOException {
        MergeTuple mergeTuple = new MergeTuple();
        Tuple firstTuple = TupleFactory.getInstance().newTuple();
        firstTuple.append("a");
        firstTuple.append(null);
        firstTuple.append("b");
        firstTuple.append(null);
        Tuple secondTuple = TupleFactory.getInstance().newTuple();
        secondTuple.append(null);
        secondTuple.append("c");
        secondTuple.append(null);
        secondTuple.append("d");
        DataBag dataBag = BagFactory.getInstance().newDefaultBag();
        dataBag.add(firstTuple);
        dataBag.add(secondTuple);
        Tuple input = TupleFactory.getInstance().newTuple();
        input.append(dataBag);
        Tuple outputTuple = mergeTuple.exec(input);
        System.out.println(outputTuple);
        Tuple expectedTuple = TupleFactory.getInstance().newTuple();
        expectedTuple.append("a");
        expectedTuple.append("c");
        expectedTuple.append("b");
        expectedTuple.append("d");
        //assertEquals(outputTuple,expectedTuple);
    }
}
