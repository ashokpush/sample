package com.kohls.bigdata.evoc.udf;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

import static org.junit.Assert.assertEquals;

public class ReferenceCodeFileReaderTest {

    private java.nio.file.Path sampleFile;

    @Before
    public void setup() throws Exception {
        InputStream sampleData = getClass().getResourceAsStream("/ref_val.orc");
        sampleFile = Files.createTempFile(null, null);
        Files.copy(sampleData, sampleFile, StandardCopyOption.REPLACE_EXISTING);
    }

    @Test
    public void testRead() throws IOException {
        ReferenceCodeFileReader reader = new ReferenceCodeFileReader(new Path(sampleFile.toString()),
                new Configuration());
        reader.read();
        assertEquals("NIGERIA", reader.getDescription("CNTRY", "NG"));
    }

}
