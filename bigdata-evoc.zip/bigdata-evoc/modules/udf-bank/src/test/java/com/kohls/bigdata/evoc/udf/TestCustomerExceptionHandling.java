package com.kohls.bigdata.evoc.udf;

import org.apache.pig.data.DataType;
import org.apache.pig.data.Tuple;
import org.apache.pig.data.TupleFactory;
import org.apache.pig.impl.logicalLayer.schema.Schema;
import org.junit.Test;
import java.io.IOException;
import java.util.Arrays;
import static org.junit.Assert.assertEquals;

public class TestCustomerExceptionHandling {
    @Test
    public void TestGroup() throws IOException {
        CustomerExceptionHandling udf = new CustomerExceptionHandling();
        Schema schema=new Schema(Arrays.asList(
                new Schema.FieldSchema("cust_id", DataType.CHARARRAY),
                new Schema.FieldSchema("assoc_id", DataType.CHARARRAY),
                new Schema.FieldSchema("last_upd_tmst", DataType.CHARARRAY),
                new Schema.FieldSchema("fil_lod_tmst", DataType.CHARARRAY),
                new Schema.FieldSchema("dlt_ind", DataType.CHARARRAY),
                new Schema.FieldSchema("btch_id", DataType.BIGINTEGER)));
        udf.setInputSchema(schema);
        String []custIdTestVal={"12","13","14","15"};
        String []lstUpdtTmstVal={"2016-08-24T23:24:34.392-05:00","2016-08-2423:24:34.392-05:00","2016-08-24T23:24:34.392-05:00",""};
        String []filUpldTmstVal={"2016-08-24T23:24:34.392","2016-08-24T23:24:34.392","2016-08-2423:24:34.392","2016-08-24T23:24:34.392"};
        String []match={"(12,,2016-08-24T23:24:34.392-05:00,2016-08-24T23:24:34.392,,12,noError,GoodRecord)",
                "(13,,2016-08-2423:24:34.392-05:00,2016-08-24T23:24:34.392,,12,Invalid timestamp format last_upd_tmst,Error)",
                "(14,,2016-08-24T23:24:34.392-05:00,2016-08-2423:24:34.392,,12,noError,GoodRecord)",
                "(15,,,2016-08-24T23:24:34.392,,12,noError,GoodRecord)"};
        for(int i=0;i<4;i++) {
            Tuple input = TupleFactory.getInstance().newTuple();
            input.append(custIdTestVal[i]);
            input.append("");
            input.append(lstUpdtTmstVal[i]);
            input.append(filUpldTmstVal[i]);
            input.append("");
            input.append(12);
            Tuple output = udf.exec(input);
            String mtch =match[i];
            System.out.println(output.toString());
            assertEquals(mtch, output.toString());
        }
    }
}