package com.kohls.bigdata.evoc.udf;

import org.apache.pig.pigunit.PigTest;
import org.junit.Test;

public class TestAccountExceptionHandling {
        @Test
        public void TestGroup() throws Exception {
                String[] script = new String[] {
                        "data = LOAD 'input' AS (account_number:CHARARRAY,account_type_code:CHARARRAY,account_type_code_description:CHARARRAY,"
                                + "account_open_timestamp:CHARARRAY,account_close_date:CHARARRAY,primary_language_code:CHARARRAY,"
                                + "primary_language_code_description:CHARARRAY,premier_account_status_code:CHARARRAY,premier_account_status_code_description:CHARARRAY,"
                                + "premier_account_expiration_date:CHARARRAY,kohls_charge_very_important_person_indicator:CHARARRAY,account_open_subchannel_identifier:CHARARRAY,"
                                + "account_associate_identifier:CHARARRAY,create_system_code:CHARARRAY,create_system_code_description:CHARARRAY,last_update_system_code:CHARARRAY,last_update_system_code_description:CHARARRAY,"
                                + "kohls_charge_external_status_code:CHARARRAY,kohls_charge_external_status_code_description:CHARARRAY,source_system_code:CHARARRAY,"
                                + "source_system_code_description:CHARARRAY,"
                                + "last_update_timestamp:CHARARRAY,create_timestamp:CHARARRAY,"
                                + "account_status_code:CHARARRAY,account_status_code_description:CHARARRAY,account_purge_date:CHARARRAY,"
                                + "sor_application_id:CHARARRAY,long_account_number:CHARARRAY,rol_dtl:"
                                + "BAG{t:TUPLE(customer_role_code:CHARARRAY, customer_role_description:CHARARRAY, "
                                + "profile_identifier:CHARARRAY, create_system_code:CHARARRAY,"
                                + "create_system_description:CHARARRAY,"
                                + "last_update_system_code:CHARARRAY,last_update_system_code_description:CHARARRAY,create_time:CHARARRAY,last_update_timestamp:CHARARRAY)},"
                                + "fil_lod_tmst:CHARARRAY,del_ind:CHARARRAY,batchid:LONG);",
                        "define AccountExceptionHandling com.kohls.bigdata.evoc.udf.AccountExceptionHandling();",
                        "descr = foreach data generate flatten(AccountExceptionHandling(*));",
                        "STORE descr INTO 'output';" };

                String[] input = new String[] {
                        "4173157701\tKC\tKohl's Charge Account\t2012-02-02T00:00:00.000-06:00" +
                                "\t2016-11-11\tSP\tLatin American Spanish\tN\tNon MVC\t2011-12-31\tY\t1234567\t123\tFD\tFirst "
                                + "Data\tDUMMY_CODE\tDUMMY_DESCRIPTION\tB\tBankrupt\tKC\tMYDESCRIPTION\t2016-08-23T13:31:23.000-05:00\t20"
                                + "16-08-23T02:02:12.667-05:00\t\t\t\t6393054151102001\t134660964"
                                + "4137701\t{(SEC,Secondary,123,FD,First Data,"
                                + "DUMMY_CODE,DUMMY_DESCRIPTION,2016-08-23T02:02:12.718-05:00,2016-08-23T02:02:49.000-05:00)}\t2016-11-24T07:"
                                + "33:04.804\t\t20161124073151",
                        "4173157701\tKC\t\t2012-02-02T00:00:00.000-06:00" +
                                "\t2016-11-11\tSP\tLatin American Spanish\tN\tNon MVC\t2011-12-31\tY\t1234567\t123\tFD\tFirst "
                                + "Data\tDUMMY_CODE\tDUMMY_DESCRIPTION\tB\tBankrupt\tKC\tMYDESCRIPTION\t2016-08-23T13:31:23.000-05:00\t20"
                                + "16-08-23T02:02:12.667-05:00\t\t\t\t6393054151102001\t134660964"
                                + "4137701\t{(SEC,Secondary,123,FD,First Data,"
                                + "DUMMY_CODE,DUMMY_DESCRIPTION,2016-08-23T02:02:12.718-05:00,2016-08-23T02:02:49.000-05:00)}\t2016-11-24T07:"
                                + "33:04.804\t\t20161124073151",
                        "4173157701\tKC\t\t2012-02-02T00:00:00.000-06:00" +
                                "\t2016-11-11\tSP\t\tN\tNon MVC\t2011-12-31\tY\t1234567\t123\tFD\tFirst "
                                + "Data\tDUMMY_CODE\tDUMMY_DESCRIPTION\tB\tBankrupt\tKC\tMYDESCRIPTION\t2016-08-23T13:31:23.000-05:00\t20"
                                + "16-08-23T02:02:12.667-05:00\t\t\t\t6393054151102001\t134660964"
                                + "4137701\t{(SEC,Secondary,123,FD,First Data,"
                                + "DUMMY_CODE,DUMMY_DESCRIPTION,2016-08-23T02:02:12.718-05:00,2016-08-23T02:02:49.000-05:00)}\t2016-11-24T07:"
                                + "33:04.804\t\t20161124073151",
                        "4173157701\tKC\t\t2012-02-02T00:00:00.000-06:00" +
                                "\t2016-1-11\tSP\tLatin American Spanish\tN\tNon MVC\t2011-12-31\tY\t1234567\t123\tFD\tFirst "
                                + "Data\tDUMMY_CODE\tDUMMY_DESCRIPTION\tB\tBankrupt\tKC\tMYDESCRIPTION\t2016-08-23T13:31:23.000-05:00\t20"
                                + "16-08-23T02:02:12.667-05:00\t\t\t\t6393054151102001\t134660964"
                                + "4137701\t{(SEC,Secondary,123,FD,First Data,"
                                + "DUMMY_CODE,DUMMY_DESCRIPTION,2016-08-23T02:02:12.718-05:00,2016-08-23T02:02:49.000-05:00)}\t2016-11-24T07:"
                                + "33:04.804\t\t20161124073151",
                        "4173157701\tKC\tKohl's Charge Account\t2012-02-02T00:00:00.000-06:00" +
                                "\t2016-11-11\tSP\tLatin American Spanish\tN\tNon MVC\t2011-12-31\tY\t1234567\t123\tFD\tFirst "
                                + "Data\tDUMMY_CODE\tDUMMY_DESCRIPTION\tB\tBankrupt\tKC\tMYDESCRIPTION\t2016-08-23T13:31:23.000-05:00\t20"
                                + "16-08-23T02:02:12.667-05:00\t\t\t\t6393054151102001\t134660964"
                                + "4137701\t{(SEC,Secondary,ABC,FD,First Data,"
                                + "DUMMY_CODE,DUMMY_DESCRIPTION,2016-08-23T02:02:12.718-05:00,2016-08-23T02:02:49.000-05:00)}\t2016-11-24T07:"
                                + "33:04.804\t\t20161124073151",
                        "4173157701\tKC\tKohl's Charge Account\t2012-02-02T00:00:00.000-06:00" +
                                "\t2016-11-11\tSP\tLatin American Spanish\tN\tNon MVC\t2011-12-31\tY\t1234567\t123\tFD\tFirst "
                                + "Data\tDUMMY_CODE\t\tB\tBankrupt\tKC\tMYDESCRIPTION\t2016-08-23T13:31:23.000-05:00\t20"
                                + "16-08-23T02:02:12.667-05:00\t\t\t\t6393054151102001\t134660964"
                                + "4137701\t{(SEC,Secondary,123,FD,First Data,"
                                + "DUMMY_CODE,DUMMY_DESCRIPTION,2016-08-23T02:02:12.718-05:00,2016-08-23T02:02:49.000-05:00)}\t2016-11-24T07:"
                                + "33:04.804\t\t20161124073151",};

                String[] output = new String[] {
                        "(4173157701,KC,Kohl's Charge Account,2012-02-02T00:00:00.000-06:00,2016-11-11,SP," +
                                "Latin American Spanish,N,Non MVC,2011-12-31,Y,1234567,123,FD,First Data,DUMMY_CODE,DUMMY_DESCRIPTION," +
                                "B,Bankrupt,KC,MYDESCRIPTION,2016-08-23T13:31:23.000-05:00,2016-08-23T02:02:12.667-05:00,,,,6393054151102001," +
                                "1346609644137701,{(SEC,Secondary,123,FD,First Data,DUMMY_CODE,DUMMY_DESCRIPTION,2016-08-23T02:02:12.718-05:00,2016-08-23T02:02:49.000-05:00)}," +
                                "2016-11-24T07:33:04.804,,20161124073151,noError,GoodRecord)",
                        "(4173157701,KC,,2012-02-02T00:00:00.000-06:00,2016-11-11,SP,Latin American Spanish,N,Non MVC," +
                                "2011-12-31,Y,1234567,123,FD,First Data,DUMMY_CODE,DUMMY_DESCRIPTION,B,Bankrupt,KC," +
                                "MYDESCRIPTION,2016-08-23T13:31:23.000-05:00,2016-08-23T02:02:12.667-05:00,,,,6393054151102001," +
                                "1346609644137701,{(SEC,Secondary,123,FD,First Data,DUMMY_CODE,DUMMY_DESCRIPTION,2016-08-23T02:02:12.718-05:00,2016-08-23T02:02:49.000-05:00)}," +
                                "2016-11-24T07:33:04.804,,20161124073151,Reference value violation account_type_code,Warning)",
                        "(4173157701,KC,,2012-02-02T00:00:00.000-06:00,2016-11-11,SP,,N,Non MVC," +
                                "2011-12-31,Y,1234567,123,FD,First Data,DUMMY_CODE,DUMMY_DESCRIPTION,B,Bankrupt,KC,MYDESCRIPTION,2016-08-23T13:31:23.000-05:00,2016-08-23T02:02:12.667-05:00,"
                                + ",,,6393054151102001,1346609644137701,{(SEC,Secondary,123,FD,First Data," +
                                "DUMMY_CODE,DUMMY_DESCRIPTION,2016-08-23T02:02:12.718-05:00,2016-08-23T02:02:49.000-05:00)}" +
                                ",2016-11-24T07:33:04.804,,20161124073151,Reference value violation account_type_code,Warning)",
                        "(4173157701,KC,,2012-02-02T00:00:00.000-06:00,2016-1-11,SP,Latin American Spanish,N,Non MVC," +
                                "2011-12-31,Y,1234567,123,FD,First Data,DUMMY_CODE,DUMMY_DESCRIPTION,B,Bankrupt,KC,MYDESCRIPTION,2016-08-23T13:31:23.000-05:00,2016-08-23T02:02:12.667-05:00,"
                                + ",,,6393054151102001,1346609644137701,{(SEC,Secondary,123,FD,First Data," +
                                "DUMMY_CODE,DUMMY_DESCRIPTION,2016-08-23T02:02:12.718-05:00,2016-08-23T02:02:49.000-05:00)}" +
                                ",2016-11-24T07:33:04.804,,20161124073151,Invalid Date format account_close_date,Error)",
                        "(4173157701,KC,Kohl's Charge Account,2012-02-02T00:00:00.000-06:00,2016-11-11,SP,Latin American Spanish,N,Non MVC," +
                                "2011-12-31,Y,1234567,123,FD,First Data,DUMMY_CODE,DUMMY_DESCRIPTION,B,Bankrupt,KC,MYDESCRIPTION,2016-08-23T13:31:23.000-05:00,2016-08-23T02:02:12.667-05:00,"
                                + ",,,6393054151102001,1346609644137701,{(SEC,Secondary,ABC,FD,First Data," +
                                "DUMMY_CODE,DUMMY_DESCRIPTION,2016-08-23T02:02:12.718-05:00,2016-08-23T02:02:49.000-05:00)}" +
                                ",2016-11-24T07:33:04.804,,20161124073151,Numeric value violation [rol_dtl]profile_identifier,Error)",
                        "(4173157701,KC,Kohl's Charge Account,2012-02-02T00:00:00.000-06:00,2016-11-11,SP,Latin American Spanish," +
                                "N,Non MVC,2011-12-31,Y,1234567,123,FD,First Data,DUMMY_CODE,,B,Bankrupt,KC,MYDESCRIPTION," +
                                "2016-08-23T13:31:23.000-05:00,2016-08-23T02:02:12.667-05:00,,,," +
                                "6393054151102001,1346609644137701,{(SEC,Secondary,123,FD,First Data," +
                                "DUMMY_CODE,DUMMY_DESCRIPTION,2016-08-23T02:02:12.718-05:00,2016-08-23T02:02:49.000-05:00)}," +
                                "2016-11-24T07:33:04.804,,20161124073151,Reference value violation last_update_system_code,Warning)"
                };

                PigTest test = new PigTest(script);

                test.assertOutput("data", input, "descr", output);
        }
}