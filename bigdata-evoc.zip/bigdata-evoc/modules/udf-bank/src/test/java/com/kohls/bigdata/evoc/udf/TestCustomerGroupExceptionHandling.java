package com.kohls.bigdata.evoc.udf;
import org.apache.pig.data.DataType;
import org.apache.pig.data.Tuple;
import org.apache.pig.data.TupleFactory;
import org.apache.pig.impl.logicalLayer.schema.Schema;
import org.junit.Test;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import static org.junit.Assert.assertEquals;
public class TestCustomerGroupExceptionHandling {
    @Test
    public void TestGroup() throws IOException {
        CustomerGroupExceptionHandling udf = new CustomerGroupExceptionHandling();
        Schema schema=new Schema(Arrays.asList(new Schema.FieldSchema("cust_gp_assn_id", DataType.INTEGER),
                new Schema.FieldSchema("cust_id", DataType.CHARARRAY),
                new Schema.FieldSchema("gp_typ_cde", DataType.CHARARRAY),
                new Schema.FieldSchema("gp_typ_cde_desc", DataType.CHARARRAY),
                new Schema.FieldSchema("gp_id", DataType.CHARARRAY),
                new Schema.FieldSchema("cre_sys_cde", DataType.CHARARRAY),
                new Schema.FieldSchema("cre_sys_cde_desc", DataType.CHARARRAY),
                new Schema.FieldSchema("last_upd_sys_cde", DataType.CHARARRAY),
                new Schema.FieldSchema("last_upd_sys_cde_desc", DataType.CHARARRAY),
                new Schema.FieldSchema("cre_tmst", DataType.CHARARRAY),
                new Schema.FieldSchema("last_upd_tmst", DataType.CHARARRAY),
                new Schema.FieldSchema("fil_lod_tmst", DataType.CHARARRAY),
                new Schema.FieldSchema("dlt_ind", DataType.CHARARRAY),
                new Schema.FieldSchema("btch_id", DataType.BIGINTEGER)));
        udf.setInputSchema(schema);
        String []cusGpAssnIdTstCseVl={"12","13","14","15","16"};
        String []cusIdTstCseVl={"12","13","14","15","16"};
        String []gpCdeTstVal={"EHH","EHH","EHH","EHH","EHH"};
        String []gpCdeDescTstVal={"Enterprise Household","Enterprise Household","","Enterprise Household",""};
        String []sysCdeTstVal={"ACX","ACX","ACX","","ACX"};
        String []sysCdeDescTstVal={"Acxiom","Acxiom","Acxiom","Acxiom","Acxiom"};
        String []lstUpdCdeTstVal={"DUMMY","DUMMY","DUMMY","DUMMY","DUMMY"};
        String []lstUpdCdeDescTstVal={"DUMMY_DESCRIPTION","DUMMY_DESCRIPTION","DUMMY_DESCRIPTION","DUMMY_DESCRIPTION","DUMMY_DESCRIPTION"};
        String []crtFiletimStmpTstVal={"2016-08-24T23:24:34.392-05:00","2016-08-2423:24:34.392-05:00","2016-08-T23:24:34.392-05:00","2016-08-24T23:24:34.392-05:00","2016-08-24T23:24:34.392-05:00"};
        String []lstUpttimStmpTstVal={"2016-08-24T23:24:34.392-05:00","2016-08-24T23:24:34.392-05:00","2016-08-24T23:24:34.392-05:00","2016-08-24T23:24:34.392-05:00","2016-08-24T23:24:34.392-05:00"};
        String []fileLdtimStmpTstVal={"2016-08-24T23:24:34.392","2016-08-24T23:24:34.392","2016-08-24T23:24:34.392","2016-08-24T23:24:34.392","2016-08-24T23:24:34.392"};
        String []dltIndxTstVal={"Y","N","N","","Z"};
        String []match={"(12,12,EHH,Enterprise Household,12,ACX,Acxiom,DUMMY,DUMMY_DESCRIPTION,2016-08-24T23:24:34.392-05:00,2016-08-24T23:24:34.392-05:00,2016-08-24T23:24:34.392,,12,noError,GoodRecord)",
                "(13,13,EHH,Enterprise Household,13,ACX,Acxiom,DUMMY,DUMMY_DESCRIPTION,2016-08-2423:24:34.392-05:00,2016-08-24T23:24:34.392-05:00,2016-08-24T23:24:34.392,,13,Invalid timestamp format cre_tmst,Error)",
                "(14,14,EHH,,14,ACX,Acxiom,DUMMY,DUMMY_DESCRIPTION,2016-08-T23:24:34.392-05:00,2016-08-24T23:24:34.392-05:00,2016-08-24T23:24:34.392,,14,Invalid timestamp format cre_tmst,Error)",
                "(15,15,EHH,Enterprise Household,15,,Acxiom,DUMMY,DUMMY_DESCRIPTION,2016-08-24T23:24:34.392-05:00,2016-08-24T23:24:34.392-05:00,2016-08-24T23:24:34.392,,15,Empty values in a not null field cre_sys_cde,Error)",
                "(16,16,EHH,,16,ACX,Acxiom,DUMMY,DUMMY_DESCRIPTION,2016-08-24T23:24:34.392-05:00,2016-08-24T23:24:34.392-05:00,2016-08-24T23:24:34.392,,16,Reference value violation gp_typ_cde,Warning)"};
        for(int i=0;i<5;i++) {
            Tuple input = TupleFactory.getInstance().newTuple();
            input.append(cusGpAssnIdTstCseVl[i]);
            input.append(cusIdTstCseVl[i]);
            input.append(gpCdeTstVal[i]);
            input.append(gpCdeDescTstVal[i]);
            input.append(cusIdTstCseVl[i]);
            input.append(sysCdeTstVal[i]);
            input.append(sysCdeDescTstVal[i]);
            input.append(lstUpdCdeTstVal[i]);
            input.append(lstUpdCdeDescTstVal[i]);
            input.append(crtFiletimStmpTstVal[i]);
            input.append(lstUpttimStmpTstVal[i]);
            input.append(fileLdtimStmpTstVal[i]);
            input.append("");
            input.append(cusIdTstCseVl[i]);
            Tuple output = udf.exec(input);
            String mtch =match[i];
            System.out.println(output.toString());
            assertEquals(mtch, output.toString());
        }
    }
}