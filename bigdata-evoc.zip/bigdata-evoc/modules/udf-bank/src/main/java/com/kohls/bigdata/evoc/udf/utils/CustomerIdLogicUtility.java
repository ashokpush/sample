package com.kohls.bigdata.evoc.udf.utils;

import org.apache.pig.backend.executionengine.ExecException;
import org.apache.pig.data.Tuple;
import org.apache.pig.data.TupleFactory;
import org.joda.time.IllegalFieldValueException;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;

import java.util.LinkedHashMap;
import java.util.List;

/**
 * Created by tkmahxg on 5/22/17.
 * This class is a utility class for SalesTransactionExceptionHandling
 */
public class CustomerIdLogicUtility {

    public static Tuple getCustIdAndTag(List<Tuple> tp){
        TupleFactory tupleFactory = TupleFactory.getInstance();
        Tuple custIdAndTagTuple = tupleFactory.newTuple();
        int maxCount = -1;
        long cust_id = -1;
        int rec_pref = 100;
        int tag = 0;
        int flag = -1;
        for(Tuple t :tp){

            try {
                int current_count = (Integer)t.get(0);
                int current_rec_pref = (Integer)t.get(2);
                Long current_cust_id_obj = (Long)t.get(1);
                if(current_rec_pref < rec_pref && current_cust_id_obj != null){
                    maxCount = current_count;
                    cust_id = current_cust_id_obj.longValue();
                    rec_pref = (Integer) t.get(2);
                    tag=0;
                }
                else if(current_rec_pref == rec_pref && current_count>maxCount && current_cust_id_obj!=null){
                    maxCount = current_count;
                    cust_id = (current_cust_id_obj==null?-1:current_cust_id_obj.longValue());
                    rec_pref = (Integer) t.get(2);
                    tag=0;
                }
                else if(current_count == maxCount && current_rec_pref == rec_pref && current_cust_id_obj!=null && current_cust_id_obj!=cust_id){
                    tag = 1;
                }
            } catch (ExecException e) {
                e.printStackTrace();
            }

        }
        Long cust_id_obj = (cust_id == -1 ?null:cust_id);
        custIdAndTagTuple.append(cust_id_obj);
        custIdAndTagTuple.append(tag);
        return custIdAndTagTuple;
    }

    public static Tuple getCustIdAndTagForSingleProfileId(List<Tuple> tp){
        TupleFactory tupleFactory = TupleFactory.getInstance();
        Tuple custIdAndTagTuple = tupleFactory.newTuple();
        int maxCount = -1;
        long cust_id = -1;
        int rec_pref = 100;
        int tag = 0;
        for(Tuple t :tp){
            try {
                Long current_cust_id_obj = (Long)t.get(0);
                int current_rec_pref = (Integer) t.get(1);
                if(current_cust_id_obj != null) {
                    long current_cust_id = current_cust_id_obj.longValue();
                    if (current_rec_pref < rec_pref) {
                        rec_pref = current_rec_pref;
                        cust_id = current_cust_id;
                        tag = 0;
                    } else if (current_rec_pref == rec_pref && current_cust_id != cust_id) {
                        tag = 1;
                    }
                }
                else{
                    if(current_rec_pref < rec_pref)
                        cust_id = -1;
                }
            } catch (ExecException e) {
                e.printStackTrace();
            }
        }
        Long cust_id_obj = (cust_id == -1 ?null:cust_id);
        custIdAndTagTuple.append(cust_id_obj);
        custIdAndTagTuple.append(tag);
        return custIdAndTagTuple;
    }

    public static Tuple getCustIdAndTagCustStrtDte(List<Tuple> tp){
        TupleFactory tupleFactory = TupleFactory.getInstance();
        Tuple custIdAndTagTuple = tupleFactory.newTuple();
        String cust_strt_dte = null;
        long cust_id = -1;
        int rec_pref = 100;
        int tag = 0;
        for(Tuple t :tp){
            try {
                String current_cust_strt_dte = (String)t.get(0);
                Long current_cust_id_obj = (Long)t.get(1);
                int current_rec_pref = (Integer) t.get(2);

                if(current_cust_strt_dte != null && !current_cust_strt_dte.trim().equals("")) {
                    if(cust_strt_dte == null && current_rec_pref < rec_pref){
                        cust_strt_dte = current_cust_strt_dte;
                        rec_pref = current_rec_pref;
                        cust_id = (current_cust_id_obj == null ? -1 : current_cust_id_obj.longValue());
                    }
                    else if (cust_strt_dte != null && current_cust_id_obj!=null) {
                        if(current_rec_pref < rec_pref ) {
                            cust_strt_dte = current_cust_strt_dte;
                            rec_pref = current_rec_pref;
                            cust_id = (current_cust_id_obj == null ? -1 : current_cust_id_obj.longValue());
                        }
                        else if(current_rec_pref == rec_pref){
                            if (current_cust_strt_dte.compareToIgnoreCase(cust_strt_dte) < 0) {
                                cust_strt_dte = current_cust_strt_dte;
                                rec_pref = current_rec_pref;
                                cust_id = (current_cust_id_obj == null ? -1 : current_cust_id_obj.longValue());
                            }
                        }
                    }
                }
                else{
                    if(cust_strt_dte == null || current_cust_strt_dte.trim().equals("")){
                        if(current_rec_pref < rec_pref) {
                            cust_strt_dte = null;
                            rec_pref = current_rec_pref;
                            cust_id = (current_cust_id_obj == null ? -1 : current_cust_id_obj.longValue());
                        }
                    }
                }
            } catch (ExecException e) {
                e.printStackTrace();
            }
        }
        Long cust_id_obj = (cust_id == -1 ?null:cust_id);
        custIdAndTagTuple.append(cust_id_obj);
        custIdAndTagTuple.append(tag);
        return custIdAndTagTuple;
    }
}