package com.kohls.bigdata.evoc.udf;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.io.IOUtils;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;


import java.io.*;
import java.net.URISyntaxException;
import java.net.URL;


public class HdfsGenerateMd5 extends Configured implements Tool {

    static {
        URL.setURLStreamHandlerFactory(new FsUrlStreamHandlerFactory());
    }

    @Override
    public int run(String args[]) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(new File(args[0]))));
        String path =args[1];
        FileSystem fs =FileSystem.newInstance(new Configuration());
        String line=null;
        int i=0;
        InputStream in = null;
        while((line=br.readLine())!=null){
            String [] controlFile=line.split("\t");
            try {
                String url="hdfs://"+path+controlFile[0];
                in = new URL(url).openStream();
                long size=fs.getFileStatus(new Path(url)).getLen();
                String md5 = DigestUtils.md5Hex(in);
                if(!md5.equals(controlFile[1])){
                    System.err.println("Checksum validation failed for "+controlFile[0]+" file");
                    System.exit(1);
                }
                else if (size!=Long.parseLong(controlFile[2])){
                    System.err.println("File Size validation failed for "+controlFile[0]+" file");
                    System.exit(1);
                }
            }catch (IOException e){
                System.err.println("File Not Found "+controlFile[0]);
                System.exit(1);
            }
            catch (Exception e){
                e.printStackTrace();
            }
            finally {
                if(in!=null)
                IOUtils.closeStream(in);
            }
        }
        return 0;
    }

    public static void main(String[] args) throws IOException, URISyntaxException {
        try {
            int exitcode = ToolRunner.run(new HdfsGenerateMd5(), args);
            System.exit(exitcode);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}



