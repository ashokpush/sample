package com.kohls.bigdata.evoc.udf;

import com.twitter.elephantbird.pig.piggybank.JsonStringToMap;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.BagFactory;
import org.apache.pig.data.DataBag;
import org.apache.pig.data.Tuple;
import org.apache.pig.data.TupleFactory;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by exa00015 on 14/11/16.
 */
public class JsonExtracter extends EvalFunc<DataBag> {

    private static final String LEVEL_2 = "NA+NA";
    private static final String LEVEL_3 = "gender_age";
    private static final String LEVEL_4 = "ageAppropriate";
    private static final String OUTER = "affinityMap";
    private static final String INNER = "merged";
    private static final String PRICE = "price";
    private static final String BRAND = "brandName";
    private static final String SUBPRODUCTTYPE = "subProductType";
    private static final String OCCASSION = "formalityOrOccasion";
    private static final String COLOR = "color";
    private static final String SIZE = "size";

    private JsonStringToMap mapper = new JsonStringToMap();

    private class Price {
        public DataBag columnBag;
    }

    private class Brand {
        private DataBag columnBag;
    }

    private class SubProductType {
        private DataBag columnBag;
    }

    private class Occassion {
        private DataBag columnBag;
    }

    private class Color {
        private DataBag columnBag;
    }

    private class Size {
        private DataBag columnBag;
    }

    @Override
    public DataBag exec(Tuple input) throws IOException {
        try{
            if (input != null && input.size() >= 1) {
                DataBag outputBag = BagFactory.getInstance().newDefaultBag();
                Tuple affinitytuple = TupleFactory.getInstance().newTuple();
                Tuple mergedtuple = TupleFactory.getInstance().newTuple();
                Map<String, String> jsonMap = new HashMap<>();
                Map<String, String> affinity = new HashMap<>();
                Map<String, String> merged = new HashMap<>();
                jsonMap = mapper.exec(input);
                String affinityMap = jsonMap.get(OUTER);
                affinitytuple.append(affinityMap);
                affinity = mapper.exec(affinitytuple);
                String mergedMap = affinity.get(INNER);
                mergedtuple.append(mergedMap);
                merged = mapper.exec(mergedtuple);
                int level = 1;
                for (Map.Entry<String, String> entry1 : merged.entrySet()) {
                    checkAlphaNumeric(entry1.getKey());//test aplhanumeric
                    Tuple highLevel = TupleFactory.getInstance().newTuple();
                    Tuple jsontuple = TupleFactory.getInstance().newTuple();
                    for(String str:entry1.getKey().split("\\:")){
                        highLevel.append(str);
                    }
                    Tuple initial = TupleFactory.getInstance().newTuple();
                    initial.append(1);
                    for(String str:entry1.getKey().split("\\:")){
                        initial.append(str);
                    }
                    for(int i =3;i<16;i++){
                        initial.append(null);
                    }
                    outputBag.add(initial);
                    jsontuple.append(entry1.getValue());
                    for (Map.Entry<String, String> entry2 : mapper.exec(jsontuple).entrySet()) {
                        checkAlphaNumeric(entry1.getKey());//test aplhanumeric
                        Tuple record = TupleFactory.getInstance().newTuple();
                        Iterator<Object> upperIterator = highLevel.iterator();
                        while (upperIterator.hasNext()) {
                            record.append(upperIterator.next());
                        }
                        checkAlphaNumeric(entry2.getKey());
                        for(String str:entry2.getKey().split("\\:")){
                            record.append(str);
                        }
                        Tuple jsontuple2 = TupleFactory.getInstance().newTuple();
                        jsontuple2.append(entry2.getValue());
                        for (Map.Entry<String, String> entry3 : mapper.exec(jsontuple2).entrySet()) {
                            if(entry3.getKey().equalsIgnoreCase(LEVEL_2))
                                level=2;
                            else if(entry3.getKey().equalsIgnoreCase(LEVEL_3))
                                level = 3;
                            else if(entry3.getKey().equalsIgnoreCase(LEVEL_4))
                                level = 4;
                            else
                                level = 5;
                            Tuple jsontuple3 = TupleFactory.getInstance().newTuple();
                            jsontuple3.append(entry3.getValue());
                            for (Map.Entry<String, String> entry4 : mapper.exec(jsontuple3).entrySet()) {
                                checkAlphaNumeric(entry4.getKey());//test aplhanumeric
                                Tuple endrecord = TupleFactory.getInstance().newTuple();
                                endrecord.append(level);
                                Iterator<Object> iterator = record.iterator();
                                while (iterator.hasNext()) {
                                    endrecord.append(iterator.next());
                                }
                                if(level == 2 || level == 3){
                                    for(String str:entry4.getKey().split("\\:|\\+")){
                                        endrecord.append(str);
                                    }
                                }else if(level == 5){
                                    int count=1;
                                    for(String str:entry4.getKey().split("\\:")){
                                        endrecord.append(str);
                                        count++;
                                        if(count==2){
                                            endrecord.append(null);
                                        }
                                    }
                                }else{
                                    endrecord.append(null);
                                    for(String str:entry4.getKey().split("\\:")){
                                        endrecord.append(str);
                                    }
                                }
                                Tuple jsontuple4 = TupleFactory.getInstance().newTuple();
                                jsontuple4.append(entry4.getValue());
                                int bag_count = 0 ;
                                Price price = new Price();
                                Brand brand = new Brand();
                                Occassion occassion = new Occassion();
                                SubProductType subproductType = new SubProductType();
                                Color color = new Color();
                                Size size = new Size();
                                for (Map.Entry<String, String> entry5 : mapper.exec(jsontuple4).entrySet()) {
                                    switch (entry5.getKey()){
                                        case PRICE:
                                            price.columnBag = extractJsonArray(entry5.getValue());
                                            break;
                                        case BRAND:
                                            brand.columnBag = extractJsonArray(entry5.getValue());
                                            break;
                                        case SUBPRODUCTTYPE:
                                            subproductType.columnBag = extractJsonArray(entry5.getValue());
                                            break;
                                        case OCCASSION:
                                            occassion.columnBag = extractJsonArray(entry5.getValue());
                                            break;
                                        case COLOR:
                                            color.columnBag = extractJsonArray(entry5.getValue());
                                            break;
                                        case SIZE:
                                            size.columnBag = extractJsonArray(entry5.getValue());
                                            break;
                                        default:
                                            throw new Exception();
                                    }
                                }
                                endrecord.append(price.columnBag);
                                endrecord.append(brand.columnBag);
                                endrecord.append(subproductType.columnBag);
                                endrecord.append(occassion.columnBag);
                                endrecord.append(color.columnBag);
                                endrecord.append(size.columnBag);
                                //System.out.println(endrecord);
                                outputBag.add(endrecord);
                            }
                        }
                    }
                }
                //System.out.println(outputBag);
                return outputBag;
            } else {
                return null;
            }
        }catch (Exception e){
            return null;
        }

    }

    public DataBag extractJsonArray(String endString) {
        try {
            JSONArray jsonarray = new JSONArray(endString);
            DataBag innerBag = BagFactory.getInstance().newDefaultBag();
            for (int n = 0; n < jsonarray.length(); n++) {
                Tuple endTuple = TupleFactory.getInstance().newTuple();
                JSONObject obj = jsonarray.getJSONObject(n);
                Iterator<String> itr = obj.keys();
                while (itr.hasNext()) {
                    String key = itr.next();
                    endTuple.append(key);
                    endTuple.append(Float.parseFloat(obj.get(key).toString()));
                }
                innerBag.add(endTuple);
            }
            return innerBag;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
    public void checkAlphaNumeric(String test){
        String[] splitString = test.split("\\:|\\+");
        try {
            if (splitString.length == 2) {
                Float.parseFloat(splitString[1]);
            }
            else if (splitString.length == 3)
                Float.parseFloat(splitString[2]);
        }catch (NumberFormatException e){
            throw e;
        }
    }

}



