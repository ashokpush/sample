package com.kohls.bigdata.evoc.udf;

/**
 * Created by tkmah7o on 6/8/17.
 */

import org.apache.pig.EvalFunc;
import org.apache.pig.data.DataBag;
import org.apache.pig.data.Tuple;
import org.apache.pig.data.TupleFactory;

import java.io.IOException;
import java.util.Iterator;

import static com.kohls.bigdata.evoc.udf.utils.Utils.isTupleNullOrEmpty;


public class MergeTuple extends EvalFunc<Tuple> {

    private static final int FIELD_INDEX_INPUT_BAG = 0;

    @Override
    public Tuple exec(Tuple input) throws IOException {
        if (isTupleNullOrEmpty(input)) {
            return null;
        }

        DataBag dataBag = (DataBag) input.get(FIELD_INDEX_INPUT_BAG);
        Tuple mergedTuple = TupleFactory.getInstance().newTuple((int)getMaxSize(dataBag));
        Iterator<Tuple> iterator = dataBag.iterator();
        if(isSingleTuple(dataBag)){
            return iterator.next();
        }
        for(Tuple tuple : dataBag){
            int count = 0;
            for(Object element : tuple){
                if(mergedTuple.get(count) == null) {
                    mergedTuple.set(count, element);
                }
                count++;
            }
        }
        return mergedTuple;
    }

    boolean isSingleTuple(DataBag dataBag){
        if(dataBag.size() == 1){
            return true;
        }else
            return false;
    }

    long getMaxSize(DataBag dataBag){
        long size = 0;
        for (Tuple tuple : dataBag){
            if(size < tuple.size())
                size = tuple.size();
        }
        return size;
    }
}
