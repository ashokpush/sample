package com.kohls.bigdata.evoc.udf;

import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;
import org.apache.pig.data.TupleFactory;

import java.io.IOException;

import static com.kohls.bigdata.evoc.udf.utils.Utils.isTupleNullOrEmpty;

public class SubTuple extends EvalFunc<Tuple> {

    private static final int EXPECTED_NUMBER_OF_INPUT_FIELDS = 2;

    private static final int FIELD_INDEX_INPUT_TUPLE = 0;

    private static final int FIELD_INDEX_START_INDEX = 1;

    @Override
    public Tuple exec(Tuple input) throws IOException {
        if (isTupleNullOrEmpty(input) && (input.size() != EXPECTED_NUMBER_OF_INPUT_FIELDS)) {
            return null;
        }
        Tuple inputTuple = (Tuple) input.get(FIELD_INDEX_INPUT_TUPLE);
        int startIndex = (int) input.get(FIELD_INDEX_START_INDEX);
        if (isTupleNullOrEmpty(inputTuple) || startIndex < 0 || inputTuple.size() <= startIndex) {
            return null;
        } else {
            Tuple outputTuple = TupleFactory.getInstance().newTuple();
            int inputTupleSize = inputTuple.size();
            for (int i = startIndex; i < inputTupleSize; i++) {
                outputTuple.append(inputTuple.get(i));
            }
            return outputTuple;
        }
    }
}