package com.kohls.bigdata.evoc.udf.utils;

import org.apache.pig.data.DataBag;
import org.apache.pig.data.Tuple;

public class Utils {

  public static boolean isTupleNullOrEmpty(Tuple tuple) {
    return (tuple == null) || (tuple.size() == 0);
  }

  public static boolean isBagNullOrEmpty(DataBag bag) {
    return (bag == null) || (bag.size() == 0);
  }

}
