package com.kohls.bigdata.evoc.udf;

import org.apache.pig.EvalFunc;
import org.apache.pig.backend.executionengine.ExecException;
import org.apache.pig.data.DataBag;
import org.apache.pig.data.DataType;
import org.apache.pig.data.Tuple;
import org.apache.pig.impl.logicalLayer.FrontendException;
import org.apache.pig.impl.logicalLayer.schema.Schema;

import java.io.IOException;

import static com.kohls.bigdata.evoc.udf.ExceptionHandling.*;


public class ProfileExceptionHandling extends EvalFunc<Tuple> {
    public Tuple exec(Tuple input) throws IOException {
        return errorTuple(getInputSchema(), input);
    }

    public Tuple errorTuple(Schema inputSchema, Tuple input) throws ExecException, FrontendException {
        Tuple outTuple = generateTuple(inputSchema,input);
        String msg=errorMessage(inputSchema,input);
        String []str=msg.split(":");
        outTuple.append(str[1]);
        outTuple.append(str[0]);
        return outTuple;
    }
    @Override
    public Schema outputSchema(Schema input) {
        Schema schema = new Schema();
        for (Schema.FieldSchema fieldSchema : input.getFields()) {
            schema.add(createOutputFieldSchema(fieldSchema));
        }
        schema.add(new Schema.FieldSchema("errormessage", DataType.CHARARRAY));
        schema.add(new Schema.FieldSchema("status", DataType.CHARARRAY));
        try {
            return new Schema(new Schema.FieldSchema(getSchemaName(this.getClass().getName().toLowerCase(), input),
                    schema, DataType.TUPLE));
        } catch (FrontendException e) {
            throw new RuntimeException("Can't generate output schema", e);
        }
    }
    private Schema.FieldSchema createOutputFieldSchema(Schema.FieldSchema inputFieldSchema) {
        if (inputFieldSchema.type == DataType.BAG || inputFieldSchema.type == DataType.TUPLE) {
            Schema outTupleSchema = new Schema();
            for (Schema.FieldSchema bagField : inputFieldSchema.schema.getFields()) {
                outTupleSchema.add(createOutputFieldSchema(bagField));
            }
            try {
                return new Schema.FieldSchema(inputFieldSchema.alias, outTupleSchema, inputFieldSchema.type);
            } catch (FrontendException e) {
                throw new RuntimeException("Can't convert input field schema to output schema. Input schema: "
                        + inputFieldSchema);
            }
        }else {
            return inputFieldSchema;
        }
    }
    private String errorMessage(Schema inputSchema, Tuple input) throws ExecException, FrontendException {
        String str=null;
        try {
            checkNumericViolation(input.get(0),inputSchema.getField(0).alias);
            checkNumericViolation(input.get(1),inputSchema.getField(1).alias);
            checkTimeStampFormat(input.get(11),inputSchema.getField(11).alias);
            checkTimeStampFormat(input.get(12),inputSchema.getField(12).alias);
            checkRefCodeNullabililty(input.get(0), input.get(2), inputSchema.getField(2).alias);
            checkRefCodeNullabililty(input.get(0), input.get(5), inputSchema.getField(5).alias);
            checkRefCodeNullabililty(input.get(0), input.get(7), inputSchema.getField(7).alias);
            checkRefCodeNullabililty(input.get(0), input.get(9), inputSchema.getField(9).alias);

            //e_gst_list array
            DataBag db=(DataBag)input.get(14);
            if(db!=null) {
                for (Tuple tp : db) {
                    checkRefCodeNullabililty(tp.get(0),tp.get(1),"["+inputSchema.getField(14).alias+"]"+inputSchema.getField(14).schema.getField(0).schema.getField(1).alias);
                    checkTimeStampFormat(tp.get(3),"["+inputSchema.getField(14).alias+"]"+inputSchema.getField(14).schema.getField(0).schema.getField(3).alias);
                    try{
                        checkRefCodeDescNullabililty(tp.get(1), tp.get(2), "["+inputSchema.getField(14).alias+"]"+inputSchema.getField(14).schema.getField(0).schema.getField(1).alias);
                    }catch (Exception e){
                        if(str == null)
                            str=e.getMessage();
                    }
                }
            }

            //attr array
            db=(DataBag)input.get(15);
            if(db!=null) {
                for (Tuple tp : db) {
                    checkNumericViolation(tp.get(0),"["+inputSchema.getField(15).alias+"]"+inputSchema.getField(15).schema.getField(0).schema.getField(0).alias);
                    checkTokenizedDate(tp.get(8),"["+inputSchema.getField(15).alias+"]"+inputSchema.getField(15).schema.getField(0).schema.getField(8).alias);
                    checkDateFormat(tp.get(10),"["+inputSchema.getField(15).alias+"]"+inputSchema.getField(15).schema.getField(0).schema.getField(10).alias);
                    checkTimeStampFormat(tp.get(15),"["+inputSchema.getField(15).alias+"]"+inputSchema.getField(15).schema.getField(0).schema.getField(15).alias);
                    checkTimeStampFormat(tp.get(16),"["+inputSchema.getField(15).alias+"]"+inputSchema.getField(15).schema.getField(0).schema.getField(16).alias);
                    checkRefCodeNullabililty(tp.get(0),tp.get(1),"["+inputSchema.getField(15).alias+"]"+inputSchema.getField(15).schema.getField(0).schema.getField(1).alias);
                    checkRefCodeNullabililty(tp.get(0),tp.get(11),"["+inputSchema.getField(15).alias+"]"+inputSchema.getField(15).schema.getField(0).schema.getField(11).alias);
                    checkRefCodeNullabililty(tp.get(0),tp.get(13),"["+inputSchema.getField(15).alias+"]"+inputSchema.getField(15).schema.getField(0).schema.getField(13).alias);
                    try{
                        checkRefCodeDescNullabililty(tp.get(1), tp.get(2), "["+inputSchema.getField(15).alias+"]"+inputSchema.getField(15).schema.getField(0).schema.getField(1).alias);
                        checkRefCodeDescNullabililty(tp.get(11), tp.get(12), "["+inputSchema.getField(15).alias+"]"+inputSchema.getField(15).schema.getField(0).schema.getField(11).alias);
                        checkRefCodeDescNullabililty(tp.get(13), tp.get(14), "["+inputSchema.getField(15).alias+"]"+inputSchema.getField(15).schema.getField(0).schema.getField(13).alias);
                        checkRefCodeDescNullabililty(tp.get(17), tp.get(18), "["+inputSchema.getField(15).alias+"]"+inputSchema.getField(15).schema.getField(0).schema.getField(17).alias);
                        checkRefCodeDescNullabililty(tp.get(22), tp.get(23),"["+inputSchema.getField(15).alias+"]"+ inputSchema.getField(15).schema.getField(0).schema.getField(22).alias);
                        checkRefCodeDescNullabililty(tp.get(24), tp.get(25),"["+inputSchema.getField(15).alias+"]"+ inputSchema.getField(15).schema.getField(0).schema.getField(24).alias);
                        checkRefCodeDescNullabililty(tp.get(26), tp.get(27), "["+inputSchema.getField(15).alias+"]"+inputSchema.getField(15).schema.getField(0).schema.getField(26).alias);
                    }catch (Exception e){
                        if(str == null)
                            str=e.getMessage();
                    }
                }
            }

            //addr array
            db=(DataBag)input.get(16);
            if(db != null){
                for (Tuple tp : db) {
                    checkNumericViolation(tp.get(0),"["+inputSchema.getField(16).alias+"]"+inputSchema.getField(16).schema.getField(0).schema.getField(0).alias);
                    checkTimeStampFormat(tp.get(20),"["+inputSchema.getField(16).alias+"]"+inputSchema.getField(16).schema.getField(0).schema.getField(20).alias);
                    checkTimeStampFormat(tp.get(21),"["+inputSchema.getField(16).alias+"]"+inputSchema.getField(16).schema.getField(0).schema.getField(21).alias);
                    checkRefCodeNullabililty(tp.get(0),tp.get(1),"["+inputSchema.getField(16).alias+"]"+inputSchema.getField(16).schema.getField(0).schema.getField(1).alias);
                    checkRefCodeNullabililty(tp.get(0),tp.get(16),"["+inputSchema.getField(16).alias+"]"+inputSchema.getField(16).schema.getField(0).schema.getField(16).alias);
                    checkRefCodeNullabililty(tp.get(0),tp.get(18),"["+inputSchema.getField(16).alias+"]"+inputSchema.getField(16).schema.getField(0).schema.getField(18).alias);
                    try{
                        checkRefCodeDescNullabililty(tp.get(1), tp.get(2),"["+inputSchema.getField(16).alias+"]"+ inputSchema.getField(16).schema.getField(0).schema.getField(1).alias);
                        checkRefCodeDescNullabililty(tp.get(3), tp.get(4),"["+inputSchema.getField(16).alias+"]"+ inputSchema.getField(16).schema.getField(0).schema.getField(3).alias);
                        checkRefCodeDescNullabililty(tp.get(9), tp.get(10),"["+inputSchema.getField(16).alias+"]"+ inputSchema.getField(16).schema.getField(0).schema.getField(9).alias);
                        checkRefCodeDescNullabililty(tp.get(14), tp.get(15),"["+inputSchema.getField(16).alias+"]"+ inputSchema.getField(16).schema.getField(0).schema.getField(14).alias);
                        checkRefCodeDescNullabililty(tp.get(16), tp.get(17),"["+inputSchema.getField(16).alias+"]"+ inputSchema.getField(16).schema.getField(0).schema.getField(16).alias);
                        checkRefCodeDescNullabililty(tp.get(18), tp.get(19),"["+inputSchema.getField(16).alias+"]"+ inputSchema.getField(16).schema.getField(0).schema.getField(18).alias);
                        checkRefCodeDescNullabililty(tp.get(22), tp.get(23),"["+inputSchema.getField(16).alias+"]"+ inputSchema.getField(16).schema.getField(0).schema.getField(22).alias);
                    }catch (Exception e){
                        if(str == null)
                            str=e.getMessage();
                    }
                }
            }

            //email array
            db=(DataBag)input.get(17);
            if(db != null){
                for (Tuple tp : db) {
                    checkNumericViolation(tp.get(0),"["+inputSchema.getField(17).alias+"]"+inputSchema.getField(17).schema.getField(0).schema.getField(0).alias);
                    checkTimeStampFormat(tp.get(11),"["+inputSchema.getField(17).alias+"]"+inputSchema.getField(17).schema.getField(0).schema.getField(11).alias);
                    checkTimeStampFormat(tp.get(12),"["+inputSchema.getField(17).alias+"]"+inputSchema.getField(17).schema.getField(0).schema.getField(12).alias);
                    checkRefCodeNullabililty(tp.get(0),tp.get(1),"["+inputSchema.getField(17).alias+"]"+inputSchema.getField(17).schema.getField(0).schema.getField(1).alias);
                    checkRefCodeNullabililty(tp.get(0),tp.get(7),"["+inputSchema.getField(17).alias+"]"+inputSchema.getField(17).schema.getField(0).schema.getField(7).alias);
                    checkRefCodeNullabililty(tp.get(0),tp.get(9),"["+inputSchema.getField(17).alias+"]"+inputSchema.getField(17).schema.getField(0).schema.getField(9).alias);
                    try{
                        checkRefCodeDescNullabililty(tp.get(1), tp.get(2),"["+inputSchema.getField(17).alias+"]"+ inputSchema.getField(17).schema.getField(0).schema.getField(1).alias);
                        checkRefCodeDescNullabililty(tp.get(4), tp.get(5),"["+inputSchema.getField(17).alias+"]"+ inputSchema.getField(17).schema.getField(0).schema.getField(4).alias);
                        checkRefCodeDescNullabililty(tp.get(7), tp.get(8),"["+inputSchema.getField(17).alias+"]"+ inputSchema.getField(17).schema.getField(0).schema.getField(7).alias);
                        checkRefCodeDescNullabililty(tp.get(14), tp.get(15),"["+inputSchema.getField(17).alias+"]"+ inputSchema.getField(17).schema.getField(0).schema.getField(14).alias);
                        checkRefCodeDescNullabililty(tp.get(9), tp.get(10),"["+inputSchema.getField(17).alias+"]"+ inputSchema.getField(17).schema.getField(0).schema.getField(9).alias);
                    }catch(Exception e){
                        if(str == null)
                            str=e.getMessage();
                    }
                }
            }

            //tel array
            db=(DataBag)input.get(18);
            if(db != null){
                for (Tuple tp : db) {
                    checkNumericViolation(tp.get(0),"["+inputSchema.getField(18).alias+"]"+inputSchema.getField(18).schema.getField(0).schema.getField(0).alias);
                    checkTimeStampFormat(tp.get(12),"["+inputSchema.getField(18).alias+"]"+inputSchema.getField(18).schema.getField(0).schema.getField(12).alias);
                    checkTimeStampFormat(tp.get(13),"["+inputSchema.getField(18).alias+"]"+inputSchema.getField(18).schema.getField(0).schema.getField(13).alias);
                    checkRefCodeNullabililty(tp.get(0),tp.get(1),"["+inputSchema.getField(18).alias+"]"+inputSchema.getField(18).schema.getField(0).schema.getField(1).alias);
                    checkRefCodeNullabililty(tp.get(0),tp.get(8),"["+inputSchema.getField(18).alias+"]"+inputSchema.getField(18).schema.getField(0).schema.getField(8).alias);
                    checkRefCodeNullabililty(tp.get(0),tp.get(10),"["+inputSchema.getField(18).alias+"]"+inputSchema.getField(18).schema.getField(0).schema.getField(10).alias);
                    try{
                        checkRefCodeDescNullabililty(tp.get(1), tp.get(2),"["+inputSchema.getField(18).alias+"]"+ inputSchema.getField(18).schema.getField(0).schema.getField(1).alias);
                        checkRefCodeDescNullabililty(tp.get(4), tp.get(5),"["+inputSchema.getField(18).alias+"]"+ inputSchema.getField(18).schema.getField(0).schema.getField(4).alias);
                        checkRefCodeDescNullabililty(tp.get(6), tp.get(7),"["+inputSchema.getField(18).alias+"]"+ inputSchema.getField(18).schema.getField(0).schema.getField(6).alias);
                        checkRefCodeDescNullabililty(tp.get(8), tp.get(9),"["+inputSchema.getField(18).alias+"]"+ inputSchema.getField(18).schema.getField(0).schema.getField(8).alias);
                        checkRefCodeDescNullabililty(tp.get(10), tp.get(11),"["+inputSchema.getField(18).alias+"]"+ inputSchema.getField(18).schema.getField(0).schema.getField(10).alias);
                    }catch(Exception e)
                    {
                        if(str == null)
                            str=e.getMessage();
                    }
                }
            }

            //card array
            db=(DataBag)input.get(19);
            if(db != null){
                for (Tuple tp : db) {
                    checkNumericViolation(tp.get(0),"["+inputSchema.getField(19).alias+"]"+inputSchema.getField(19).schema.getField(0).schema.getField(0).alias);
                    checkTokenizedDate(tp.get(5),"["+inputSchema.getField(19).alias+"]"+inputSchema.getField(19).schema.getField(0).schema.getField(5).alias);
                    checkTimeStampFormat(tp.get(11),"["+inputSchema.getField(19).alias+"]"+inputSchema.getField(19).schema.getField(0).schema.getField(11).alias);
                    checkTimeStampFormat(tp.get(12),"["+inputSchema.getField(19).alias+"]"+inputSchema.getField(19).schema.getField(0).schema.getField(12).alias);
                    checkRefCodeNullabililty(tp.get(0),tp.get(2),"["+inputSchema.getField(19).alias+"]"+inputSchema.getField(19).schema.getField(0).schema.getField(2).alias);
                    checkRefCodeNullabililty(tp.get(0),tp.get(7),"["+inputSchema.getField(19).alias+"]"+inputSchema.getField(19).schema.getField(0).schema.getField(7).alias);
                    checkRefCodeNullabililty(tp.get(0),tp.get(9),"["+inputSchema.getField(19).alias+"]"+inputSchema.getField(19).schema.getField(0).schema.getField(9).alias);
                    try{
                        nullObject(tp.get(0));
                        checkNullability(tp.get(1),"["+inputSchema.getField(19).alias+"]"+inputSchema.getField(19).schema.getField(0).schema.getField(1).alias);
                    }catch (Exception e){
                        if(!e.getMessage().equals("Object is null")){
                            throw e;
                        }
                    }
                    try{
                        checkRefCodeDescNullabililty(tp.get(2), tp.get(3),"["+inputSchema.getField(19).alias+"]"+ inputSchema.getField(19).schema.getField(0).schema.getField(2).alias);
                        checkRefCodeDescNullabililty(tp.get(7), tp.get(8),"["+inputSchema.getField(19).alias+"]" +inputSchema.getField(19).schema.getField(0).schema.getField(7).alias);
                        checkRefCodeDescNullabililty(tp.get(9), tp.get(10),"["+inputSchema.getField(19).alias+"]" +inputSchema.getField(19).schema.getField(0).schema.getField(9).alias);
                    }catch (Exception e){
                        if(str == null)
                            str=e.getMessage();
                    }
                }
            }

            //lnk array
            db=(DataBag)input.get(20);
            if(db != null){
                for (Tuple tp : db) {
                    checkNumericViolation(tp.get(0),"["+inputSchema.getField(20).alias+"]"+inputSchema.getField(20).schema.getField(0).schema.getField(0).alias);
                    checkTimeStampFormat(tp.get(6),"["+inputSchema.getField(20).alias+"]"+inputSchema.getField(20).schema.getField(0).schema.getField(6).alias);
                    checkRefCodeNullabililty(tp.get(0),tp.get(4),"["+inputSchema.getField(20).alias+"]"+inputSchema.getField(20).schema.getField(0).schema.getField(4).alias);
                    try{
                        checkRefCodeDescNullabililty(tp.get(2), tp.get(3),"["+inputSchema.getField(20).alias+"]"+ inputSchema.getField(20).schema.getField(0).schema.getField(2).alias);
                        checkRefCodeDescNullabililty(tp.get(4), tp.get(5),"["+inputSchema.getField(20).alias+"]"+ inputSchema.getField(20).schema.getField(0).schema.getField(4).alias);
                    }catch(Exception e){
                        if(str == null)
                            str=e.getMessage();
                    }
                }
            }

            //suppml_attr attr
            db=(DataBag)input.get(21);
            if(db != null){
                for (Tuple tp : db) {
                    checkTimeStampFormat(tp.get(12), "[" + inputSchema.getField(21).alias + "]" + inputSchema.getField(21).schema.getField(0).schema.getField(12).alias);
                    checkTimeStampFormat(tp.get(13), "[" + inputSchema.getField(21).alias + "]" + inputSchema.getField(21).schema.getField(0).schema.getField(13).alias);
                    checkRefCodeNullabililty(tp.get(0),tp.get(8),"["+inputSchema.getField(21).alias+"]"+inputSchema.getField(21).schema.getField(0).schema.getField(8).alias);
                    checkRefCodeNullabililty(tp.get(0),tp.get(10),"["+inputSchema.getField(21).alias+"]"+inputSchema.getField(21).schema.getField(0).schema.getField(10).alias);
                    checkRefCodeNullabililty(tp.get(0),tp.get(11),"["+inputSchema.getField(21).alias+"]"+inputSchema.getField(21).schema.getField(0).schema.getField(11).alias);
                    try {
                        checkRefCodeDescNullabililty(tp.get(0), tp.get(1), "[" + inputSchema.getField(21).alias + "]" + inputSchema.getField(21).schema.getField(0).schema.getField(0).alias);
                        checkRefCodeDescNullabililty(tp.get(2), tp.get(3), "[" + inputSchema.getField(21).alias + "]" + inputSchema.getField(21).schema.getField(0).schema.getField(2).alias);
                        checkRefCodeDescNullabililty(tp.get(4), tp.get(5), "[" + inputSchema.getField(21).alias + "]" + inputSchema.getField(21).schema.getField(0).schema.getField(4).alias);
                        checkRefCodeDescNullabililty(tp.get(6), tp.get(7), "[" + inputSchema.getField(21).alias + "]" + inputSchema.getField(21).schema.getField(0).schema.getField(6).alias);
                        checkRefCodeDescNullabililty(tp.get(8), tp.get(9), "[" + inputSchema.getField(21).alias + "]" + inputSchema.getField(21).schema.getField(0).schema.getField(8).alias);
                        checkRefCodeDescNullabililty(tp.get(10), tp.get(11), "[" + inputSchema.getField(21).alias + "]" + inputSchema.getField(21).schema.getField(0).schema.getField(10).alias);
                    } catch (Exception e) {
                        if (str == null)
                            str = e.getMessage();
                    }
                }
            }
            checkRefCodeDescNullabililty(input.get(2),input.get(3),inputSchema.getField(2).alias);
            checkRefCodeDescNullabililty(input.get(5),input.get(6),inputSchema.getField(5).alias);
            checkRefCodeDescNullabililty(input.get(7),input.get(8),inputSchema.getField(7).alias);
            checkRefCodeDescNullabililty(input.get(9),input.get(10),inputSchema.getField(9).alias);
            if(str != null)
                throw new Exception(str);
        }
        catch (Exception e) {
            return e.getMessage();
        }
        return "GoodRecord:noError";
    }
}