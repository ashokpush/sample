package com.kohls.bigdata.evoc.udf;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.ql.exec.vector.BytesColumnVector;
import org.apache.hadoop.hive.ql.exec.vector.VectorizedRowBatch;
import org.apache.hadoop.hive.ql.io.orc.OrcFile;
import org.apache.hadoop.hive.ql.io.orc.Reader;
import org.apache.hadoop.hive.ql.io.orc.RecordReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Reference code extract reader.
 *
 * <p/>
 * Read ORC file with Reference Code Values into a hashmap and provide
 * {@link #getDescription} method to get description corresponding to
 * a given reference code and reference code value.
 */
public class ReferenceCodeFileReader {

    private static final Logger LOG = LoggerFactory.getLogger(ReferenceCodeFileReader.class);

    // Expected column indexes in the file.
    // Unfortunately field names in our ORC files are in the form "col_0, col_1, ..." and
    // can not be used to determine indexes.
    private static final int CODE_COL_IDX = 0;
    private static final int DESCR_COL_IDX = 3;
    private static final int VALUE_COL_IDX = 2;

    private final Path path;
    private final Configuration config;

    // reference code -> (code value -> description)
    private Map<String, Map<String, String>> referenceCodeMap;

    /**
     * Create a reader that will read the extract from the given path.
     */
    public ReferenceCodeFileReader(Path path, Configuration config) {
        this.path = path;
        this.config = config;
    }

    /**
     * Read the extract content and put it into an in-memory hashmap
     */
    public void read() throws IOException {
        FileSystem fs =path.getFileSystem(config);
        FileStatus[] fs1=fs.listStatus(path);
        Path[] pa1= FileUtil.stat2Paths(fs1);
        Reader reader = OrcFile.createReader(pa1[0], OrcFile.readerOptions(config));
        RecordReader rows = reader.rows();

        BytesColumnVector codeCol = null;
        BytesColumnVector descrCol = null;
        BytesColumnVector valueCol = null;

        VectorizedRowBatch batch = null;

        referenceCodeMap = new HashMap<String, Map<String, String>>();

        while (rows.hasNext()) {
            batch = rows.nextBatch(batch);

            if (codeCol == null) {
                codeCol = (BytesColumnVector) batch.cols[CODE_COL_IDX];
                descrCol = (BytesColumnVector) batch.cols[DESCR_COL_IDX];
                valueCol = (BytesColumnVector) batch.cols[VALUE_COL_IDX];
            }

            for(int r = 0; r < batch.size; ++r) {
                String code = codeCol.getWritableObject(r).toString();
                String descr = descrCol.getWritableObject(r).toString();
                String value = valueCol.getWritableObject(r).toString();

                Map<String, String> codeEntry = referenceCodeMap.get(code);
                if (codeEntry == null) {
                    codeEntry = new HashMap<String, String>();
                    referenceCodeMap.put(code, codeEntry);
                }
                codeEntry.put(value, descr);
            }
        }
        rows.close();
    }

    /**
     * Get description corresponding to the given reference code and value
     *
     * @param code
     *          Reference code
     * @param value
     *          Reference code value
     * @return
     *          Description corresponding to the given code and value or null if no description is found
     */
    public String getDescription(String code, String value) {
        Map<String, String> codeEntry = referenceCodeMap.get(code);
        return codeEntry == null ? null : codeEntry.get(value);
    }
    public String getUpdtDescription(String code, String value) {
        Map<String, String> codeEntry = referenceCodeMap.get(code);
        if (codeEntry == null || !codeEntry.containsKey(value))
            return "DESCRIPTION_NOT_UPDATED";
        return codeEntry.get(value);
    }

}
