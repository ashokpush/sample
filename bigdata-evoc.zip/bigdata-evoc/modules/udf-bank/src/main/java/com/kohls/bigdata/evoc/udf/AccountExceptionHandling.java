package com.kohls.bigdata.evoc.udf;

import org.apache.pig.EvalFunc;
import org.apache.pig.backend.executionengine.ExecException;
import org.apache.pig.data.*;
import org.apache.pig.impl.logicalLayer.FrontendException;
import org.apache.pig.impl.logicalLayer.schema.Schema;

import java.io.IOException;

import static com.kohls.bigdata.evoc.udf.ExceptionHandling.*;


public class AccountExceptionHandling extends EvalFunc<Tuple> {
    public Tuple exec(Tuple input) throws IOException {
        return errorTuple(getInputSchema(), input);
    }

    public Tuple errorTuple(Schema inputSchema, Tuple input) throws ExecException, FrontendException {
        Tuple outTuple = generateTuple(inputSchema,input);
        String msg=errorMessage(inputSchema,input);
        String []str=msg.split(":");
        outTuple.append(str[1]);
        outTuple.append(str[0]);
        return outTuple;
    }
    @Override
    public Schema outputSchema(Schema input) {
        Schema schema = new Schema();
        for (Schema.FieldSchema fieldSchema : input.getFields()) {
            schema.add(createOutputFieldSchema(fieldSchema));
        }
        schema.add(new Schema.FieldSchema("errormessage", DataType.CHARARRAY));
        schema.add(new Schema.FieldSchema("status", DataType.CHARARRAY));
        try {
            return new Schema(new Schema.FieldSchema(getSchemaName(this.getClass().getName().toLowerCase(), input),
                    schema, DataType.TUPLE));
        } catch (FrontendException e) {
            throw new RuntimeException("Can't generate output schema", e);
        }
    }
    private Schema.FieldSchema createOutputFieldSchema(Schema.FieldSchema inputFieldSchema) {
        if (inputFieldSchema.type == DataType.BAG || inputFieldSchema.type == DataType.TUPLE) {
            Schema outTupleSchema = new Schema();
            for (Schema.FieldSchema bagField : inputFieldSchema.schema.getFields()) {
                outTupleSchema.add(createOutputFieldSchema(bagField));
            }
            try {
                return new Schema.FieldSchema(inputFieldSchema.alias, outTupleSchema, inputFieldSchema.type);
            } catch (FrontendException e) {
                throw new RuntimeException("Can't convert input field schema to output schema. Input schema: "
                        + inputFieldSchema);
            }
        }else {
            return inputFieldSchema;
        }
    }
    private String errorMessage(Schema inputSchema, Tuple input) throws ExecException, FrontendException {
        String str=null;
        try {

            checkTokenizedDate(input.get(4),inputSchema.getField(4).alias);
            checkDateFormat(input.get(9),inputSchema.getField(9).alias);
            checkTimeStampFormat(input.get(21),inputSchema.getField(21).alias);
            checkTimeStampFormat(input.get(22),inputSchema.getField(22).alias);
            checkDateFormat(input.get(25),inputSchema.getField(25).alias);
            checkRefCodeNullabililty(input.get(0), input.get(1), inputSchema.getField(1).alias);
            checkRefCodeNullabililty(input.get(0), input.get(13), inputSchema.getField(13).alias);
            checkRefCodeNullabililty(input.get(0), input.get(15), inputSchema.getField(15).alias);
            DataBag db=(DataBag)input.get(28);
            if(db!=null) {
                int fieldNum = 0;
                for (Tuple tp : db) {
                    checkNumericViolation(tp.get(2), "["+inputSchema.getField(28).alias+"]"+inputSchema.getField(28).schema.getField(0).schema.getField(2).alias);
                    checkTimeStampFormat(tp.get(7), "["+inputSchema.getField(28).alias+"]"+inputSchema.getField(28).schema.getField(0).schema.getField(7).alias);
                    checkTimeStampFormat(tp.get(8), "["+inputSchema.getField(28).alias+"]"+inputSchema.getField(28).schema.getField(0).schema.getField(8).alias);
                    checkRefCodeNullabililty(input.get(2),tp.get(3),"["+inputSchema.getField(28).alias+"]"+inputSchema.getField(28).schema.getField(0).schema.getField(3).alias);
                    checkRefCodeNullabililty(input.get(2),tp.get(5),"["+inputSchema.getField(28).alias+"]"+inputSchema.getField(28).schema.getField(0).schema.getField(5).alias);
                    try {
                        checkRefCodeDescNullabililty(tp.get(3), tp.get(4), "["+inputSchema.getField(28).alias+"]"+inputSchema.getField(28).schema.getField(0).schema.getField(3).alias);
                        checkRefCodeDescNullabililty(tp.get(0), tp.get(1), "["+inputSchema.getField(28).alias+"]"+inputSchema.getField(28).schema.getField(0).schema.getField(0).alias);
                        checkRefCodeDescNullabililty(tp.get(5), tp.get(6), "["+inputSchema.getField(28).alias+"]"+inputSchema.getField(28).schema.getField(0).schema.getField(5).alias);
                    }
                    catch (Exception e){
                        if(str == null)
                            str=e.getMessage();
                    }
                    fieldNum++;
                }
            }
            checkRefCodeDescNullabililty(input.get(1),input.get(2), inputSchema.getField(1).alias);
            checkRefCodeDescNullabililty(input.get(5),input.get(6), inputSchema.getField(5).alias);
            checkRefCodeDescNullabililty(input.get(7),input.get(8), inputSchema.getField(7).alias);
            checkRefCodeDescNullabililty(input.get(13),input.get(14),inputSchema.getField(13).alias);
            checkRefCodeDescNullabililty(input.get(15),input.get(16),inputSchema.getField(15).alias);
            checkRefCodeDescNullabililty(input.get(17),input.get(18),inputSchema.getField(17).alias);
            checkRefCodeDescNullabililty(input.get(19),input.get(20),inputSchema.getField(19).alias);
            checkRefCodeDescNullabililty(input.get(23), input.get(24), inputSchema.getField(23).alias);

            if(str != null)
                throw new Exception(str);
        }
        catch (Exception e) {
            return e.getMessage();
        }
        return "GoodRecord:noError";
    }
}