package com.kohls.bigdata.evoc.udf;

import org.apache.hadoop.fs.Path;
import org.apache.pig.EvalFunc;
import org.apache.pig.impl.util.UDFContext;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;

/**
 * Abstract UDF class that provides reference code descriptions to descendants
 *
 * <p/>
 * UDF requests reference values extract to be put into Map/Reduce distributed cache
 * and then reads the extract with {@link ReferenceCodeFileReader} when
 * {@link #exec} is called for the first time.
 *
 * <p/>
 * {@link ReferenceCodeFileReader} uses in-memory hashmap to find descriptions
 */
abstract class AbstractReferenceCodeFunc<T> extends EvalFunc<T> {

    private final String referenceCodeExtractPath;
    private final boolean useDistributedCache;

    private ReferenceCodeFileReader reader;

    /**
     * Create UDF instance.
     *
     * @param referenceCodeExtractPath
     *          location of reference values extract in HDFS
     * @param useDistributedCache
     *          whether to get extract from M/R distributed
     *          cache or directly from the given location;
     *          should be false in case mini-cluster based
     *          tests are used to execute Pig scripts with this UDF
     */
    AbstractReferenceCodeFunc(String referenceCodeExtractPath, String useDistributedCache) {
        this.referenceCodeExtractPath = referenceCodeExtractPath;
        this.useDistributedCache = "true".equals(useDistributedCache);
    }

    private void initReader() throws IOException {
        if (useDistributedCache) {
            Path localPath = new Path("file://" + Paths.get("./ref_val.orc").toAbsolutePath().toString());
            reader = newReader(localPath);
        } else {
            reader = newReader(new Path(referenceCodeExtractPath));
        }
        reader.read();
    }

    /**
     * Get description corresponding to the given reference code and value
     *
     * @param code
     *          Reference code
     * @param value
     *          Reference code value
     * @return
     *          Description corresponding to the given code and value or null if no description is found
     */
    protected String getDescription(String code, String value) throws IOException {
        if (reader == null) {
            initReader();
        }
        return reader.getDescription(code, value);
    }

    protected String getUpdtDescription(String code, String value) throws IOException {
        if (reader == null) {
            initReader();
        }
        return reader.getUpdtDescription(code, value);
    }

    protected ReferenceCodeFileReader newReader(Path path) throws IOException {
        return new ReferenceCodeFileReader(path, UDFContext.getUDFContext().getJobConf());
    }

    @Override
    public List<String> getCacheFiles() {
        if (useDistributedCache) {
            return Collections.singletonList(referenceCodeExtractPath + "#ref_val.orc");
        } else {
            return super.getCacheFiles();
        }
    }

}
