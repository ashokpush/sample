package com.kohls.bigdata.evoc.udf;

import org.apache.pig.data.Tuple;

import java.io.IOException;

/**
 * Get reference code description UDF
 *
 * <p/>
 * UDF requests reference values extract to be put into HDFS distributed cache
 * and then reads the extract with {@link ReferenceCodeFileReader} when
 * {@link #exec} is called for the first time.
 *
 * <p/>
 * {@link ReferenceCodeFileReader} uses in-memory hashmap to find descriptions
 *
 * <p/>
 * UDF accepts 2 parameters: reference code and code value. It returns corresponding
 * description or null if description is not found for the given combination
 * of reference code and code value.
 */
public class GetReferenceCodeDesc extends AbstractReferenceCodeFunc<String> {

    /**
     * Create UDF instance.
     *
     * @param referenceCodeExtractPath
     *          location of reference values extract in HDFS
     * @param useDistributedCache
     *          whether to get extract from M/R distributed
     *          cache or directly from the given location;
     *          should be false in case mini-cluster based
     *          tests are used to execute Pig scripts with this UDF
     */
    public GetReferenceCodeDesc(String referenceCodeExtractPath, String useDistributedCache) {
        super(referenceCodeExtractPath, useDistributedCache);
    }

    /**
     * Create UDF instance.
     *
     * @param referenceCodeExtractPath
     *          location of reference values extract in HDFS
     */
    public GetReferenceCodeDesc(String referenceCodeExtractPath) {
        super(referenceCodeExtractPath, "true");
    }

    @Override
    public String exec(Tuple tuple) throws IOException {
        if (tuple.size() != 2) {
            throw new IOException("Two parameters are expected");
        }

        Object arg0 = tuple.get(0);
        Object arg1 = tuple.get(1);

        if (arg0 == null || arg1 == null) {
            return null;
        }

        if (!(arg0 instanceof String) || !(arg1 instanceof String)) {
            throw new IOException("Expected two String parameters, got " + arg0.getClass() + ", " + arg1.getClass());
        }

        return getDescription((String) arg0, (String) arg1);
    }

}
