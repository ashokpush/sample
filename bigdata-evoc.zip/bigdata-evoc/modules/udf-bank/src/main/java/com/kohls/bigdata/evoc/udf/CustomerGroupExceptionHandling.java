package com.kohls.bigdata.evoc.udf;

import org.apache.pig.EvalFunc;
import org.apache.pig.backend.executionengine.ExecException;
import org.apache.pig.data.*;
import org.apache.pig.impl.logicalLayer.FrontendException;
import org.apache.pig.impl.logicalLayer.schema.Schema;

import java.io.IOException;

import static com.kohls.bigdata.evoc.udf.ExceptionHandling.*;

/*
UDF to handle exception handling scenarion in CustomerGroup Extract
This UDF will take entire record as input and add errorMessage and status at the end of each record
 */
public class CustomerGroupExceptionHandling extends EvalFunc<Tuple> {
    public Tuple exec(Tuple input) throws IOException {
        return errorTuple( getInputSchema(),input);
    }
    public Tuple errorTuple( Schema inputSchema, Tuple input) throws ExecException, FrontendException {
        TupleFactory tupleFactory = TupleFactory.getInstance();
        Tuple outTuple = tupleFactory.newTuple();
        int fieldNum = 0;
        for (Object f : input) {
            byte type = input.getType(fieldNum);
            if (type == DataType.BAG) {
                DataBag bag = (DataBag) f;
                DataBag outBag = BagFactory.getInstance().newDefaultBag();
                Schema.FieldSchema bagField = inputSchema.getField(fieldNum);
                Schema bagTupleSchema = bagField.schema.getField(0).schema;
                for (Tuple bagTuple : bag) {
                    outBag.add(errorTuple(bagTupleSchema, bagTuple));
                }
                outTuple.append(outBag);
            } else if (type == DataType.TUPLE) {
                outTuple.append(errorTuple(inputSchema.getField(fieldNum).schema, (Tuple) f));
            } else {
                outTuple.append(f);
            }
            fieldNum++;
        }
        String msg=errorMessage(inputSchema,input);
        String []str=msg.split(":");
        outTuple.append(str[1]);
        outTuple.append(str[0]);
        return outTuple;
    }
    @Override
    public Schema outputSchema(Schema input) {
        Schema schema = new Schema();
        for (Schema.FieldSchema fieldSchema : input.getFields()) {
            schema.add(createOutputFieldSchema(fieldSchema));
        }
        schema.add(new Schema.FieldSchema("error_identification_process",DataType.CHARARRAY));
        schema.add(new Schema.FieldSchema("status",DataType.CHARARRAY));
        try {
            return new Schema(new Schema.FieldSchema(getSchemaName(this.getClass().getName().toLowerCase(), input),
                    schema, DataType.TUPLE));
        } catch (FrontendException e) {
            throw new RuntimeException("Can't generate output schema", e);
        }
    }
    private Schema.FieldSchema createOutputFieldSchema(Schema.FieldSchema inputFieldSchema) {
        if (inputFieldSchema.type == DataType.BAG || inputFieldSchema.type == DataType.TUPLE) {
            Schema outTupleSchema = new Schema();
            for (Schema.FieldSchema bagField : inputFieldSchema.schema.getFields()) {
                outTupleSchema.add(createOutputFieldSchema(bagField));
            }
            try {
                return new Schema.FieldSchema(inputFieldSchema.alias, outTupleSchema, inputFieldSchema.type);
            } catch (FrontendException e) {
                throw new RuntimeException("Can't convert input field schema to output schema. Input schema: "
                        + inputFieldSchema);
            }
        }else {
            return inputFieldSchema;
        }
    }
    private String errorMessage(Schema inputSchema,Tuple input) throws ExecException, FrontendException {
        try {
            checkNumericViolation(input.get(0), inputSchema.getField(0).alias);
            checkNumericViolation(input.get(1), inputSchema.getField(1).alias);
            checkNumericViolation(input.get(4), inputSchema.getField(4).alias);
            checkTimeStampFormat(input.get(9), inputSchema.getField(9).alias);
            checkTimeStampFormat(input.get(10), inputSchema.getField(10).alias);
            checkRefCodeNullabililty(input.get(0),input.get(2),inputSchema.getField(2).alias);
            checkRefCodeNullabililty(input.get(0),input.get(5),inputSchema.getField(5).alias);
            checkRefCodeNullabililty(input.get(0),input.get(7),inputSchema.getField(5).alias);
            checkRefCodeDescNullabililty(input.get(2),input.get(3), inputSchema.getField(2).alias);
            checkRefCodeDescNullabililty(input.get(5),input.get(6), inputSchema.getField(5).alias);
            checkRefCodeDescNullabililty(input.get(7),input.get(8), inputSchema.getField(7).alias);
        }
        catch (Exception e) {
            return e.getMessage();
        }
        return "GoodRecord:noError";
    }
}