package com.kohls.bigdata.evoc.udf;

import org.apache.pig.EvalFunc;
import org.apache.pig.data.DataBag;
import org.apache.pig.data.Tuple;
import org.apache.pig.data.TupleFactory;

import java.io.IOException;
import java.util.Iterator;

import static com.kohls.bigdata.evoc.udf.utils.Utils.isBagNullOrEmpty;
import static com.kohls.bigdata.evoc.udf.utils.Utils.isTupleNullOrEmpty;

public class GetTupleAt extends EvalFunc<Tuple> {

  private static final int EXPECTED_NUMBER_OF_INPUT_FIELDS = 4;

  private static final int FIELD_INDEX_INPUT_BAG = 0;

  private static final int FIELD_INDEX_INDEX = 1;

  private static final int FIELD_INDEX_DEFAULT_VALUE = 2;

  private static final int FIELD_COUNT = 3;

  @Override
  public Tuple exec(Tuple input) throws IOException {
    if (isTupleNullOrEmpty(input)
        && (input.size() != EXPECTED_NUMBER_OF_INPUT_FIELDS)) {
      return null;
    }

    DataBag bag = (DataBag) input.get(FIELD_INDEX_INPUT_BAG);
    int index = (int) input.get(FIELD_INDEX_INDEX);
    int fieldCount = (int) input.get(FIELD_COUNT);
    Object defaultValue = input.get(FIELD_INDEX_DEFAULT_VALUE);

    if (isBagNullOrEmpty(bag) || index < 0 || bag.size() <= index) {
      Tuple tupleAtIndex = TupleFactory.getInstance().newTuple();
      for (int i = 0; i < fieldCount; i++) {
        tupleAtIndex.append(defaultValue);
      }
      return tupleAtIndex;
    } else {
      Iterator<Tuple> iterator = bag.iterator();
      Tuple tupleAtIndex = null;
      while (index >= 0) {
        tupleAtIndex = iterator.next();
        index--;
      }
      return tupleAtIndex;
    }
  }
}