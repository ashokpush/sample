package com.kohls.bigdata.evoc.udf;

import org.apache.pig.EvalFunc;
import org.apache.pig.backend.executionengine.ExecException;
import org.apache.pig.data.*;
import org.apache.pig.impl.logicalLayer.FrontendException;
import org.apache.pig.impl.logicalLayer.schema.Schema;

import java.io.IOException;

public class UpdateReferenceCodeDescription extends EvalFunc<Tuple> {

    @Override
    public Tuple exec(Tuple input) throws IOException {
        DataBag stg_tpl_bag = (DataBag)input.get(1);
        Tuple stg_tpl = null;
        for (Tuple bagtuple : stg_tpl_bag) {
            stg_tpl = bagtuple;
        }
        Schema stg_tpl_schema = getInputSchema().getField(1).schema.getField(0).schema;
        DataBag curnt_tpl_bag = (DataBag)input.get(2);
        Tuple curnt_tpl = null;
        for (Tuple bagtuple : curnt_tpl_bag) {
            curnt_tpl = bagtuple;
        }
        return processTuple(stg_tpl,stg_tpl_schema,curnt_tpl);
    }

    private Tuple processTuple(Tuple stg_tpl,Schema stg_tpl_schema,Tuple curnt_tpl) throws IOException {
        TupleFactory tupleFactory = TupleFactory.getInstance();
        Tuple outTuple = tupleFactory.newTuple();

        int fieldNum = 0;
        for (Object f : stg_tpl) {
            Object f2 = curnt_tpl.get(fieldNum);
            byte type = stg_tpl.getType(fieldNum);
            if (type == DataType.BAG) {
                DataBag bag = (DataBag) f;
                DataBag bag2 = (DataBag) f2;
                DataBag outBag = BagFactory.getInstance().newDefaultBag();
                Schema.FieldSchema bagField = stg_tpl_schema.getField(fieldNum);
                Schema bagTupleSchema = bagField.schema.getField(0).schema;
                int bag2count = 0;
                Tuple [] bag2TupleArray = new Tuple[(int)bag.size()];
                for (Tuple bag2Tuple : bag2) {
                    bag2TupleArray[bag2count] = bag2Tuple;
                    bag2count++;
                }
                bag2count = 0;
                for (Tuple bagTuple : bag) {
                    outBag.add(processTuple(bagTuple,bagTupleSchema,bag2TupleArray[bag2count]));
                    bag2count++;
                }
                outTuple.append(outBag);
            } else if (type == DataType.TUPLE) {
                outTuple.append(processTuple((Tuple)f,stg_tpl_schema.getField(fieldNum).schema,(Tuple)f2));
            } else {
                String alias = stg_tpl_schema.getField(fieldNum).alias;
                if (alias.endsWith("_cde_desc")) {
                    if (f == null)
                        outTuple.append(null);
                    else {
                        String ref_desc = f.toString();
                        if(ref_desc.equals("DESCRIPTION_NOT_UPDATED"))
                          outTuple.append(f2);
                        else
                            outTuple.append(ref_desc);
                    }
                } else {
                    outTuple.append(f2);
                }
            }
            fieldNum++;
        }
        return outTuple;
    }

    private String getFieldValue(Tuple tuple, Schema schema, String fieldName) throws ExecException {
        int fieldNum = 0;
        for (Schema.FieldSchema fieldSchema : schema.getFields()) {
            if (fieldSchema.alias.equals(fieldName)) {
                Object val = tuple.get(fieldNum);
                return val != null ? val.toString() : null;
            }
            fieldNum++;
        }
        return null;
    }

    @Override
    public Schema outputSchema(Schema input) {
        Schema out =null;
        try {
            out = input.getField(2).schema.getField(0).schema;
            Schema b =out;
        } catch (FrontendException e) {
            e.printStackTrace();
        }
        Schema schema = new Schema();
        for (Schema.FieldSchema fieldSchema : out.getFields()) {
            schema.add(createOutputFieldSchema(fieldSchema));
        }
        try {
            return new Schema(new Schema.FieldSchema(getSchemaName(this.getClass().getName().toLowerCase(), input),
                    schema, DataType.TUPLE));
        } catch (FrontendException e) {
            throw new RuntimeException("Can't generate output schema", e);
        }
    }

    private Schema.FieldSchema createOutputFieldSchema(Schema.FieldSchema inputFieldSchema) {
        if (inputFieldSchema.type == DataType.BAG || inputFieldSchema.type == DataType.TUPLE) {
            Schema outTupleSchema = new Schema();
            for (Schema.FieldSchema bagField : inputFieldSchema.schema.getFields()) {
                outTupleSchema.add(createOutputFieldSchema(bagField));
            }
            try {
                return new Schema.FieldSchema(inputFieldSchema.alias, outTupleSchema, inputFieldSchema.type);
            } catch (FrontendException e) {
                throw new RuntimeException("Can't convert input field schema to output schema. Input schema: "
                        + inputFieldSchema);
            }
        } else {
            return inputFieldSchema;
        }
    }

}
