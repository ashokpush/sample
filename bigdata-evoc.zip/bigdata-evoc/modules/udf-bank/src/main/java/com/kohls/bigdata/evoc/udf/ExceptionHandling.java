package com.kohls.bigdata.evoc.udf;

import org.apache.pig.backend.executionengine.ExecException;
import org.apache.pig.data.*;
import org.apache.pig.impl.logicalLayer.FrontendException;
import org.apache.pig.impl.logicalLayer.schema.Schema;
import org.joda.time.IllegalFieldValueException;
import org.joda.time.Interval;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;

public class ExceptionHandling {
    //Function to check for Numeric Value violation
    public static void checkNullableInteger(Object obj,String colname) throws Exception {
        if (obj == null || ((String)obj).trim().equalsIgnoreCase("null")){
            throw new Exception("Error:Nulls values in a not null field "+colname);
        }
        String recStr = ((String) obj).trim();
        if(recStr.equals("")){
            throw new Exception("Error:Empty values in a not null field "+colname);
        }
        try{
            if(obj instanceof String) {
                Long.parseLong(recStr);
            }
        }
        catch (NumberFormatException e){
            throw new Exception("Error:Numeric value violation " +colname);
        }
    }
    //Function to validate timestamp format
    public static void checkTimeStampFormat(Object o1,String colname) throws Exception {
        try{
            nullObject(o1);
        }
        catch (Exception e){
            return;
        }
        String recStrTmstp=(String)o1;
        try{
            DateTimeFormatter daterecfrmt = ISODateTimeFormat.dateTime();
            daterecfrmt.parseDateTime(recStrTmstp);
        }catch(IllegalFieldValueException e){
            throw new Exception("Error:Invalid timestamp format " +colname );
        }catch (IllegalArgumentException e){
            throw new Exception("Error:Invalid timestamp format " +colname );
        }
    }
    //Fucntion to check for NOT Null Error
    public static void checkNullability(Object obj,String colname) throws Exception {
        if(obj==null)
            throw new Exception("Error:Nulls values in a not null field "+colname);
        if(obj instanceof String) {
            String obj1=(String)obj;
            if (obj1.trim().equalsIgnoreCase("null"))
                throw new Exception("Error:Nulls values in a not null field "+ colname);
            if(obj1.trim().equals(""))
                throw new Exception("Error:Empty values in a not null field "+colname);
        }
    }
    public static void nullObject(Object o1) throws Exception {
        if(o1 == null || ((String) o1).trim().equals("") || ((String)o1).trim().equalsIgnoreCase("null")){
            throw new Exception("Object is null");
        }
    }
    public static void checkNumericViolation(Object obj,String colname) throws Exception {
        try {
            nullObject(obj);
        } catch (Exception e) {
            return;
        }
        try{
            if(obj instanceof String) {
                String recStr = (String) obj;
                Long.parseLong(recStr);
            }
        }
        catch (NumberFormatException e){
            throw new Exception("Error:Numeric value violation " +colname);
        }
    }
    //Currently No Use
    //Fucntion to Validate fileLoadTimestamp
    public static void checkFileLoadTimeStampFormat(Object o1,String colname) throws Exception {
        try{
            nullObject(o1);
        }
        catch (Exception e){
            return;
        }
        String recStrTmstp=(String)o1;
        try{
            DateTimeFormatter daterecfrmt = ISODateTimeFormat.dateHourMinuteSecondMillis();
            daterecfrmt.parseDateTime(recStrTmstp);
        }catch(IllegalFieldValueException e){
            throw new Exception("Error:Invalid timestamp format " +colname );
        }catch (IllegalArgumentException e){
            throw new Exception("Error:Invalid timestamp format " +colname );
        }
    }
    //Fucntion to check reference value violation
    public static void checkRefCodeDescNullabililty(Object refCde,Object refCdeDesc,String colname) throws Exception {
        try{
            nullObject(refCde);
        }
        catch (Exception e){
            return;
        }
        String refCdeDesc1=(String)refCdeDesc;
        if(refCdeDesc==null || refCdeDesc1.equalsIgnoreCase("null") || refCdeDesc1.equals(""))
            throw new Exception("Warning:Reference value violation "+colname);
    }
    //Currently No Use
    public static void checkDelInd(Object obj,String colname) throws Exception {
        String dlInd=((String)obj).trim();
        if (obj == null || dlInd.equals("") || dlInd.equalsIgnoreCase("null") || dlInd.equalsIgnoreCase("y") || dlInd.equalsIgnoreCase("n"))
            return;
        throw new Exception("Error:delete Indicator "+colname);
    }
    //Function to check Valid Date
    public static void checkDateFormat(Object obj,String colname) throws Exception {
        try{
            nullObject(obj);
        }
        catch (Exception e){
            return;
        }
        String dateRec=(String)obj;
        try{
            DateTimeFormatter daterecfrmt = DateTimeFormat.forPattern("yyyy-MM-dd");
            daterecfrmt.parseDateTime(dateRec);
        }catch(IllegalFieldValueException e){
            throw new Exception("Error:Invalid Date format " +colname );
        }catch (IllegalArgumentException e){
            throw new Exception("Error:Invalid Date format " +colname );
        }
    }
    //Function to check Valid Tokenized Date
    public static void checkTokenizedDate(Object obj,String colname) throws Exception {
        try{
            nullObject(obj);
        }
        catch (Exception e){
            return;
        }
        String tokDateRec=(String)obj;
        String []str=tokDateRec.split("-");
        if(str.length!=3)
            throw new Exception("Error:Invalid Date format " +colname );
        if(str[0].length() != 4 || str[1].length() != 2 || str[2].length() != 2) {
            throw new Exception("Error:Invalid Date format " +colname );
        }
        try {
            Integer.parseInt(str[0]);
            Integer.parseInt(str[1]);
            Integer.parseInt(str[2]);
        }catch (NumberFormatException e){
            throw new Exception("Error:Invalid Date format " +colname );
        }

    }

    public static void checkRefCodeNullabililty(Object identifier,Object refCde,String colname) throws Exception {
        try{
            nullObject(identifier);
        }
        catch (Exception e){
            return;
        }
        if(refCde==null)
            throw new Exception("Error:Nulls values in a not null field "+colname);
        if(refCde instanceof String) {
            String refCde1=(String)refCde;
            if (refCde1.trim().equalsIgnoreCase("null"))
                throw new Exception("Error:Nulls values in a not null field "+ colname);
            if(refCde1.trim().equals(""))
                throw new Exception("Error:Empty values in a not null field "+colname);
        }
    }

    public static Tuple generateTuple(Schema inputSchema, Tuple input) throws ExecException, FrontendException {
        TupleFactory tupleFactory = TupleFactory.getInstance();
        Tuple outTuple = tupleFactory.newTuple();
        int fieldNum = 0;
        for (Object f : input) {
            byte type = input.getType(fieldNum);
            if (type == DataType.BAG) {
                DataBag bag = (DataBag) f;
                DataBag outBag = BagFactory.getInstance().newDefaultBag();
                Schema.FieldSchema bagField = inputSchema.getField(fieldNum);
                Schema bagTupleSchema = bagField.schema.getField(0).schema;
                for (Tuple bagTuple : bag) {
                    outBag.add(generateTuple(bagTupleSchema, bagTuple));
                }
                outTuple.append(outBag);
            } else if (type == DataType.TUPLE) {
                outTuple.append(generateTuple(inputSchema.getField(fieldNum).schema, (Tuple) f));
            } else {
                outTuple.append(f);
            }
            fieldNum++;
        }
        return outTuple;
    }

}
