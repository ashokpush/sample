package com.kohls.bigdata.evoc.udf;

import org.apache.pig.EvalFunc;
import org.apache.pig.backend.executionengine.ExecException;
import org.apache.pig.data.*;
import org.apache.pig.impl.logicalLayer.FrontendException;
import org.apache.pig.impl.logicalLayer.schema.Schema;

import static com.kohls.bigdata.evoc.udf.ExceptionHandling.generateTuple;
import static com.kohls.bigdata.evoc.udf.utils.SalesTransactionUtility.*;

import java.io.IOException;

/*
UDF to handle exception handling scenarion in CustomerGroup Extract
This UDF will take entire record as input and add errorMessage and status at the end of each record
 */
public class SalesTransactionExceptionHandling extends EvalFunc<Tuple> {
    public Tuple exec(Tuple input) throws IOException {
        return errorTuple( getInputSchema(),input);
    }
    public Tuple errorTuple( Schema inputSchema, Tuple input) throws ExecException, FrontendException {
        Tuple outTuple = generateTuple(inputSchema,input);
        String msg=errorMessage(inputSchema,input);
        String []str=msg.split(":");
        outTuple.append(str[1]);
        outTuple.append(str[0]);
        return outTuple;
    }
    @Override
    public Schema outputSchema(Schema input) {
        Schema schema = new Schema();
        for (Schema.FieldSchema fieldSchema : input.getFields()) {
            schema.add(createOutputFieldSchema(fieldSchema));
        }
        schema.add(new Schema.FieldSchema("error_identification_process",DataType.CHARARRAY));
        schema.add(new Schema.FieldSchema("status",DataType.CHARARRAY));
        try {
            return new Schema(new Schema.FieldSchema(getSchemaName(this.getClass().getName().toLowerCase(), input),
                    schema, DataType.TUPLE));
        } catch (FrontendException e) {
            throw new RuntimeException("Can't generate output schema", e);
        }
    }
    private Schema.FieldSchema createOutputFieldSchema(Schema.FieldSchema inputFieldSchema) {
        if (inputFieldSchema.type == DataType.BAG || inputFieldSchema.type == DataType.TUPLE) {
            Schema outTupleSchema = new Schema();
            for (Schema.FieldSchema bagField : inputFieldSchema.schema.getFields()) {
                outTupleSchema.add(createOutputFieldSchema(bagField));
            }
            try {
                return new Schema.FieldSchema(inputFieldSchema.alias, outTupleSchema, inputFieldSchema.type);
            } catch (FrontendException e) {
                throw new RuntimeException("Can't convert input field schema to output schema. Input schema: "
                        + inputFieldSchema);
            }
        }else {
            return inputFieldSchema;
        }
    }
    private String errorMessage(Schema inputSchema,Tuple input) throws ExecException, FrontendException {
        try {
            int count = 0;
            String msg = null;
            boolean isAnyCrdNbrNotNull = false;
            notNull(input.get(0),inputSchema.getField(0).alias);
            checkValidDate(input.get(0),inputSchema.getField(0).alias);
            notNull(input.get(1),inputSchema.getField(1).alias);
            checkNumericViolation(input.get(1),inputSchema.getField(1).alias);
            notNull(input.get(2),inputSchema.getField(2).alias);
            checkNumericViolation(input.get(2),inputSchema.getField(2).alias);
            notNull(input.get(3),inputSchema.getField(3).alias);
            checkNumericViolation(input.get(3),inputSchema.getField(3).alias);
            notNull(input.get(4),inputSchema.getField(4).alias);
            checkTimeStampFormat(input.get(4),inputSchema.getField(4).alias);
            notNull(input.get(5),inputSchema.getField(5).alias);
            checkNumericViolation(input.get(5),inputSchema.getField(5).alias);
            DataBag db=(DataBag)input.get(19);
            if(db!=null) {
                for (Tuple tp : db) {
                    try {
                        notNull(tp.get(1), inputSchema.getField(19).schema.getField(0).schema.getField(1).alias);
                        isAnyCrdNbrNotNull = true;
                        break;
                    } catch (Exception e) {
                        count++;
                    }
                }
            }
            try{
                notNull(input.get(10),inputSchema.getField(10).alias);
            }catch (Exception e){
                count++;
            }
            try{
                notNull(input.get(14),inputSchema.getField(14).alias);
            }catch (Exception e){
                count++;
            }
            if(count >= 3 && !isAnyCrdNbrNotNull){
                throw new Exception("Reject:record is to be rejected");
            }
            // for credit_card_detail/Profile_id
            if(db!=null) {
                for (Tuple tp : db) {
                    try {
                        checkCardinalityForCrdDtl(tp.get(0),tp.get(1),  tp.get(5),"["+inputSchema.getField(19).alias+"]"
                                +inputSchema.getField(19).schema.getField(0).schema.getField(5).alias);
                    }catch (Exception e){
                        if (msg == null){
                            msg = e.getMessage();
                        }
                    }
                }
            }

            //for llty_prfl_id
            try {
                checkCardinality(input.get(10),input.get(11),inputSchema.getField(11).alias);
            }catch (Exception e) {
                if (msg == null) {
                    msg = e.getMessage();
                }
            }
            //for e_prfl_id
            try {
                checkCardinality(input.get(14),input.get(15),inputSchema.getField(15).alias);
            }catch (Exception e) {
                if (msg == null) {
                    msg = e.getMessage();
                }
            }
            if(msg != null){
                throw new Exception(msg);
            }
        }
        catch (Exception e) {
            return e.getMessage();
        }
        return "GoodRecord:noError";
    }
}