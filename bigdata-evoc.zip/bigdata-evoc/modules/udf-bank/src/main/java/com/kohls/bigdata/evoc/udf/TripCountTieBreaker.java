package com.kohls.bigdata.evoc.udf;

import org.apache.pig.EvalFunc;
import org.apache.pig.backend.executionengine.ExecException;
import org.apache.pig.data.*;
import org.apache.pig.impl.logicalLayer.FrontendException;
import org.apache.pig.impl.logicalLayer.schema.Schema;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.kohls.bigdata.evoc.udf.utils.CustomerIdLogicUtility.getCustIdAndTag;

public class TripCountTieBreaker extends EvalFunc<Tuple> {

    List<Tuple> trip_count = null;
    @Override
    public Tuple exec(Tuple input) throws IOException {
        trip_count = new ArrayList<>();
        Schema stg_tpl_schema = getInputSchema();
        Tuple tp = processTuple(input,stg_tpl_schema);
        Tuple tags = getCustIdAndTag(trip_count);
        tp.append(tags.get(0));
        tp.append(tags.get(1));
        return tp;
    }

    private Tuple processTuple(Tuple stg_tpl,Schema stg_tpl_schema) throws IOException {
        TupleFactory tupleFactory = TupleFactory.getInstance();
        Tuple outTuple = tupleFactory.newTuple();

        int fieldNum = 0;
        int cust_id_field=0;
        int rec_pref_field=0;
        for (Object f : stg_tpl) {
            byte type = stg_tpl.getType(fieldNum);
            if (type == DataType.BAG) {
                DataBag bag = (DataBag) f;
                DataBag outBag = BagFactory.getInstance().newDefaultBag();
                Schema.FieldSchema bagField = stg_tpl_schema.getField(fieldNum);
                Schema bagTupleSchema = bagField.schema.getField(0).schema;

                for (Tuple bagTuple : bag) {
                    outBag.add(processTuple(bagTuple,bagTupleSchema));
                }
                outTuple.append(outBag);
            } else if (type == DataType.TUPLE) {
                outTuple.append(processTuple((Tuple)f,stg_tpl_schema.getField(fieldNum).schema));
            } else {
                String alias = stg_tpl_schema.getField(fieldNum).alias;
                if (alias.equals("trip_count")) {
                    if (f != null) {
                        Tuple t = tupleFactory.newTuple();
                        t.append((Integer)f);
                        t.append((Long)stg_tpl.get(cust_id_field));
                        t.append((Integer)stg_tpl.get(rec_pref_field));
                        trip_count.add(t);
                        outTuple.append(f);
                    }
                }
                else if(alias.equals("cust_id")){
                    cust_id_field = fieldNum;
                    outTuple.append(f);
                }
                else if(alias.equals("rec_pref")){
                    rec_pref_field = fieldNum;
                    outTuple.append(f);
                }
                else {
                    outTuple.append(f);
                }
            }
            fieldNum++;
        }
        return outTuple;
    }

    private String getFieldValue(Tuple tuple, Schema schema, String fieldName) throws ExecException {
        int fieldNum = 0;
        for (Schema.FieldSchema fieldSchema : schema.getFields()) {
            if (fieldSchema.alias.equals(fieldName)) {
                Object val = tuple.get(fieldNum);
                return val != null ? val.toString() : null;
            }
            fieldNum++;
        }
        return null;
    }

    @Override
    public Schema outputSchema(Schema input) {
        Schema schema = new Schema();
        for (Schema.FieldSchema fieldSchema : input.getFields()) {
            schema.add(createOutputFieldSchema(fieldSchema));
        }
        schema.add(new Schema.FieldSchema("new_cust_id",DataType.LONG));
        schema.add(new Schema.FieldSchema("tag",DataType.INTEGER));
        try {
            Schema scq =new Schema(new Schema.FieldSchema(getSchemaName(this.getClass().getName().toLowerCase(), input),
                    schema, DataType.TUPLE));
            return scq;
        } catch (FrontendException e) {
            throw new RuntimeException("Can't generate output schema", e);
        }
    }

    private Schema.FieldSchema createOutputFieldSchema(Schema.FieldSchema inputFieldSchema) {
        if (inputFieldSchema.type == DataType.BAG || inputFieldSchema.type == DataType.TUPLE) {
            Schema outTupleSchema = new Schema();
            for (Schema.FieldSchema bagField : inputFieldSchema.schema.getFields()) {
                outTupleSchema.add(createOutputFieldSchema(bagField));
            }
            try {
                return new Schema.FieldSchema(inputFieldSchema.alias, outTupleSchema, inputFieldSchema.type);
            } catch (FrontendException e) {
                throw new RuntimeException("Can't convert input field schema to output schema. Input schema: "
                        + inputFieldSchema);
            }
        } else {
            return inputFieldSchema;
        }
    }

}