package com.kohls.bigdata.evoc.udf;

import org.apache.pig.backend.executionengine.ExecException;
import org.apache.pig.data.*;
import org.apache.pig.impl.logicalLayer.FrontendException;
import org.apache.pig.impl.logicalLayer.schema.Schema;

import java.io.IOException;

/**
 * UDF to add reference value description columns to given input records
 *
 * <p/>
 * UDF accepts entire record that might have hierarchical structure.
 * Each column with suffix "_reference_code" is replaced with corresponding
 * "_description" column. This includes top level columns as well as
 * columns in nested bags and tuples.
 *
 * <p/>
 * UDF requests reference values extract to be put into Map/Reduce distributed cache
 * and then reads the extract with {@link ReferenceCodeFileReader}.
 *
 * <p/>
 * {@link ReferenceCodeFileReader} uses in-memory hashmap to find descriptions
 */
public class AddDescFilterRecords extends AbstractReferenceCodeFunc<Tuple> {

    String str = null;
    /**
     * Create UDF instance.
     *
     * @param referenceCodeExtractPath
     *          location of reference values extract in HDFS
     * @param useDistributedCache
     *          whether to get extract from M/R distributed
     *          cache or directly from the given location;
     *          should be false in case mini-cluster based
     *          tests are used to execute Pig scripts with this UDF
     */
    public AddDescFilterRecords(String referenceCodeExtractPath, String useDistributedCache) {
        super(referenceCodeExtractPath, useDistributedCache);
    }

    /**
     * Create UDF instance.
     *
     * @param referenceCodeExtractPath
     *          location of reference values extract in HDFS
     */
    public AddDescFilterRecords(String referenceCodeExtractPath) {
        super(referenceCodeExtractPath, "true");
    }

    @Override
    public Tuple exec(Tuple input) throws IOException {
        str = null;
        Tuple tp = processTuple(getInputSchema(), input);
        tp.append(str);
        return tp;
    }

    private Tuple processTuple(Schema inputSchema, Tuple input) throws IOException {
        TupleFactory tupleFactory = TupleFactory.getInstance();
        Tuple outTuple = tupleFactory.newTuple();

        int fieldNum = 0;
        for (Object f : input) {
            byte type = input.getType(fieldNum);
            if (type == DataType.BAG) {
                DataBag bag = (DataBag) f;
                DataBag outBag = BagFactory.getInstance().newDefaultBag();
                Schema.FieldSchema bagField = inputSchema.getField(fieldNum);
                Schema bagTupleSchema = bagField.schema.getField(0).schema;
                for (Tuple bagTuple : bag) {
                    outBag.add(processTuple(bagTupleSchema, bagTuple));
                }
                outTuple.append(outBag);
            } else if (type == DataType.TUPLE) {
                outTuple.append(processTuple(inputSchema.getField(fieldNum).schema, (Tuple) f));
            } else {
                String alias = inputSchema.getField(fieldNum).alias;
                if (alias.endsWith("_reference_code") && f != null) {
                    String refCode = f.toString();
                    String refValue = getFieldValue(input, inputSchema, alias.replace("_reference", ""));
                    if (refValue != null) {
                        String str1 = getUpdtDescription(refCode, refValue);
                        if(str1!= null  && str1.equals("DESCRIPTION_NOT_UPDATED")) {
                            outTuple.append("DESCRIPTION_NOT_UPDATED");
                            if(str == null)
                                str = "desc_not_updt";
                        }else if(str1 == null || !str1.equals("NotUpdt")){
                            str = "desc_updt";
                            outTuple.append(str1);
                        }
                    } else {
                        outTuple.append(null);
                        if (str == null)
                            str = "desc_not_updt";
                    }
                } else {
                    outTuple.append(f);
                }
            }
            fieldNum++;
        }
        return outTuple;
    }

    private String getFieldValue(Tuple tuple, Schema schema, String fieldName) throws ExecException {
        int fieldNum = 0;
        for (Schema.FieldSchema fieldSchema : schema.getFields()) {
            if (fieldSchema.alias.equals(fieldName)) {
                Object val = tuple.get(fieldNum);
                return val != null ? val.toString() : null;
            }
            fieldNum++;
        }
        return null;
    }

    @Override
    public Schema outputSchema(Schema input) {
        Schema schema = new Schema();
        for (Schema.FieldSchema fieldSchema : input.getFields()) {
            schema.add(createOutputFieldSchema(fieldSchema));
        }
        schema.add(new Schema.FieldSchema("status",DataType.CHARARRAY));
        try {
            return new Schema(new Schema.FieldSchema(getSchemaName(this.getClass().getName().toLowerCase(), input),
                    schema, DataType.TUPLE));
        } catch (FrontendException e) {
            throw new RuntimeException("Can't generate output schema", e);
        }
    }

    private Schema.FieldSchema createOutputFieldSchema(Schema.FieldSchema inputFieldSchema) {
        if (inputFieldSchema.type == DataType.BAG || inputFieldSchema.type == DataType.TUPLE) {
            Schema outTupleSchema = new Schema();
            for (Schema.FieldSchema bagField : inputFieldSchema.schema.getFields()) {
                outTupleSchema.add(createOutputFieldSchema(bagField));
            }
            try {
                return new Schema.FieldSchema(inputFieldSchema.alias, outTupleSchema, inputFieldSchema.type);
            } catch (FrontendException e) {
                throw new RuntimeException("Can't convert input field schema to output schema. Input schema: "
                        + inputFieldSchema);
            }
        } else if (inputFieldSchema.alias.endsWith("_reference_code")) {
            Schema.FieldSchema outFieldSchema = new Schema.FieldSchema(inputFieldSchema);
            outFieldSchema.alias = outFieldSchema.alias.replace("_reference_code", "_description");
            return outFieldSchema;
        } else {
            return inputFieldSchema;
        }
    }

}
