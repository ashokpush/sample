package com.kohls.bigdata.evoc.udf.utils;

import org.joda.time.IllegalFieldValueException;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;

/**
 * Created by tkmahxg on 5/22/17.
 * This class is a utility class for SalesTransactionExceptionHandling
 */
public class SalesTransactionUtility {

    /**
     * @param obj
     * @param colName
     * @throws Exception
     */
    public static void notNull(Object obj, String colName) throws Exception {
        if (obj != null) {
            if (obj instanceof String) {
                String str = (String) obj;
                if (str.trim().equals(""))
                    throw new Exception("Error:Empty/White space values in a not null field " + colName);
                else if (str.trim().equalsIgnoreCase("NULL")) {
                    throw new Exception("Error:Nulls values in a not null field " + colName);
                } else
                    return;
            }

        } else
            throw new Exception("Error:Nulls values in a not null field " + colName);

    }

    /**
     * @param obj
     * @param colName
     * @throws Exception
     */
    public static void checkValidDate(Object obj, String colName) throws Exception {
        try {
            String dateRec = (String) obj;
            DateTimeFormatter daterecfrmt = DateTimeFormat.forPattern("yyyy-MM-dd");
            daterecfrmt.parseDateTime(dateRec);
        } catch (IllegalFieldValueException e) {
            throw new Exception("Error:Invalid Date format " + colName);
        } catch (IllegalArgumentException e) {
            throw new Exception("Error:Invalid Date format " + colName);
        }
    }

    /**
     * @param obj
     * @param colName
     * @throws Exception
     */
    public static void checkNumericViolation(Object obj, String colName) throws Exception {
        try {
            if (obj instanceof String) {
                String recStr = (String) obj;
                Long.parseLong(recStr);
            }
        } catch (NumberFormatException e) {
            throw new Exception("Error:Numeric value violation " + colName);
        }
    }

    /**
     * This function checks if value of the object passed is in ISO Format
     * @param obj
     *        object of column which is to be checked
     * @param colname
     *        name of the column
     * @throws Exception
     *          throws new exception with "Error:Invalid timestamp format " + colname" message as the Message
     */
    public static void checkTimeStampFormat(Object obj, String colname) throws Exception {
        String recStrTmstp = (String) obj;
        try {
            DateTimeFormatter daterecfrmt = ISODateTimeFormat.timeParser();
            daterecfrmt.parseDateTime(recStrTmstp);
        } catch (IllegalFieldValueException e) {
            throw new Exception("Error:Invalid timestamp format " + colname);
        } catch (IllegalArgumentException e) {
            throw new Exception("Error:Invalid timestamp format " + colname);
        }
    }

    /**
     *
     * @param obj1
     * @param obj2
     * @param colname
     * @throws Exception
     */
    public static void checkCardinality(Object obj1, Object obj2, String colname) throws Exception {

        try {
            notNull(obj1, colname);
        } catch (Exception e) {
            return;
        }
        try {
            notNull(obj2, colname);
        } catch (Exception e) {
            throw new Exception("Warning:Profile not found in DDH " + colname);
        }
    }

    /**
     *
     * @param ob1
     * @param ob2
     * @param ob3
     * @param colName
     * @throws Exception
     */
    public static void checkCardinalityForCrdDtl(Object ob1, Object ob2, Object ob3, String colName) throws Exception {
        String tndrTypCde = null;
        if (ob1 instanceof String)
            tndrTypCde = (String) ob1;
        String crdNbr = null;
        if (ob2 instanceof String)
            crdNbr = (String) ob2;
        if (crdNbr != null) {
            if (!crdNbr.equalsIgnoreCase("NULL") &&
                    !crdNbr.trim().equalsIgnoreCase("")
                    ) {
                if ((tndrTypCde != null) && (tndrTypCde.trim().equals("04") || tndrTypCde.trim().equals("05") ||
                        tndrTypCde.trim().equals("06") || tndrTypCde.trim().equals("07") ||
                        tndrTypCde.trim().equals("08") || tndrTypCde.trim().equals("19"))) {
                    try {
                        notNull(ob3, colName);
                    } catch (Exception e) {
                        throw new Exception("Warning:Profile not found in DDH " + colName);
                    }
                }
            }
        }
    }
}
