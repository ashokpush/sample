Hive-XML-SerDe
==============

XML Serializer/Deserializer for Apache Hive

For more information and samples of usage see https://github.com/dvasilen/Hive-XML-SerDe/wiki/XML-data-sources

See also https://github.com/dvasilen/Hive-XML-SerDe-VTD for VTD-XML based processor. When used with Hive XML SerDe it can provide significant performance  gains.
