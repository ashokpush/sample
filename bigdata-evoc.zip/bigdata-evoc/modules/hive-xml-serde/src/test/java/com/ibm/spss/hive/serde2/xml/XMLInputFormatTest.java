package com.ibm.spss.hive.serde2.xml;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.serde2.SerDeException;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileSplit;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.RecordReader;
import org.apache.hadoop.mapred.Reporter;
import org.mockito.Mockito;

import java.io.File;
import java.io.IOException;

/**
 *
 */
public class XMLInputFormatTest extends TestCase {

    public XMLInputFormatTest(String testName) {
        super(testName);
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite() {
        return new TestSuite(XMLInputFormatTest.class);
    }

    private void testXML(String xml, String tag, String[] expectedOutput) throws IOException {
        File xmlFile = new File(xml);
        XmlInputFormat format = new XmlInputFormat();
        FileSplit fileSplit = Mockito.mock(FileSplit.class);
        Mockito.when(fileSplit.getLength()).thenReturn(xmlFile.length());
        Mockito.when(fileSplit.getPath()).thenReturn(new Path(xmlFile.getAbsolutePath()));
        Reporter reporter = Mockito.mock(Reporter.class);
        JobConf jobConf = new JobConf();
        jobConf.set(XmlInputFormat.START_TAG_KEY, "<"+tag+" ");
        jobConf.set(XmlInputFormat.END_TAG_KEY, "</"+tag+">");
        jobConf.set("fs.defaultFS", "file:///");
        RecordReader<LongWritable, Text> recordReader = format.getRecordReader(fileSplit, jobConf, reporter);
        LongWritable key = new LongWritable(1);
        Text value = new Text();
        int index = 0;
        while (recordReader.next(key, value)) {
            assertEquals(tag + " record does not match", expectedOutput[index++], value.toString());
        }
        assertEquals(tag + " Record count does not match", expectedOutput.length, index);
    }

    public void testCustomerExplicitXMLInputFormat() throws SerDeException, IOException {
        String[] expectedOutput = new String[]{
                "<Customer LastUpdateTimestamp=\"2016-08-22T00:42:36.000-05:00\" CustomerIdentifier=\"999\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"999\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"999\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"999\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"999\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"999\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"999\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"999\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"999\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"999\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"999\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"999\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"999\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-22T00:42:36.000-05:00\" CustomerIdentifier=\"999\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-24T16:16:30.000-05:00\" CustomerIdentifier=\"999\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-24T16:18:20.000-05:00\" CustomerIdentifier=\"999\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-24T16:18:20.000-05:00\" CustomerIdentifier=\"999\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-24T16:18:20.000-05:00\" CustomerIdentifier=\"999\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-26T03:59:15.000-05:00\" CustomerIdentifier=\"999\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-26T03:59:15.000-05:00\" CustomerIdentifier=\"999\"></Customer>"
        };
        testXML("src/test/resources/xmls/customer/customer_explicit.xml", "Customer", expectedOutput);
    }

    public void testCustomerMix1XMLInputFormat() throws SerDeException, IOException {
        String[] expectedOutput = new String[]{
                "<Customer LastUpdateTimestamp=\"2016-08-22T00:42:36.000-05:00\" CustomerIdentifier=\"777\"/>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"777\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"777\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"777\"/>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"777\"/>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"777\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"777\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"777\"/>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"777\"/>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"777\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"777\"/>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"777\"/>",
                "<Customer LastUpdateTimestamp=\"2016-08-18T13:47:09.000-05:00\" CustomerIdentifier=\"777\"/>",
                "<Customer LastUpdateTimestamp=\"2016-08-22T00:42:36.000-05:00\" CustomerIdentifier=\"777\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-24T16:16:30.000-05:00\" CustomerIdentifier=\"777\"/>",
                "<Customer LastUpdateTimestamp=\"2016-08-24T16:18:20.000-05:00\" CustomerIdentifier=\"777\"/>",
                "<Customer LastUpdateTimestamp=\"2016-08-24T16:18:20.000-05:00\" CustomerIdentifier=\"777\"></Customer>",
                "<Customer LastUpdateTimestamp=\"2016-08-24T16:18:20.000-05:00\" CustomerIdentifier=\"777\"/>",
                "<Customer LastUpdateTimestamp=\"2016-08-26T03:59:15.000-05:00\" CustomerIdentifier=\"777\"/>",
                "<Customer LastUpdateTimestamp=\"2016-08-26T03:59:15.000-05:00\" CustomerIdentifier=\"777\"/>"
        };

        testXML("src/test/resources/xmls/customer/customer_mix1.xml", "Customer", expectedOutput);

    }


}