package com.ibm.spss.hive.serde2.xml.objectinspector;

import com.ibm.spss.hive.serde2.xml.XmlInputFormat;
import com.ibm.spss.hive.serde2.xml.XmlSerDe;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.apache.commons.io.FileUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.serde2.SerDeException;
import org.apache.hadoop.hive.serde2.objectinspector.StructField;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileSplit;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.RecordReader;
import org.apache.hadoop.mapred.Reporter;
import org.mockito.Mockito;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

/**
 *
 */
public class CmdmXmlsTest extends TestCase {

    private static final String LIST_COLUMNS = "columns";
    private static final String LIST_COLUMN_TYPES = "columns.types";


    public CmdmXmlsTest(String testName) {
        super(testName);
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite() {
        return new TestSuite(CmdmXmlsTest.class);
    }

    public void testCustomerExplicitXml() throws SerDeException, IOException {
        XmlSerDe xmlSerDe = new XmlSerDe();
        Configuration configuration = new Configuration();
        Properties properties = new Properties();
        properties.put(LIST_COLUMNS, "CustomerIdentifier,AssociateIdentifier,LastUpdateTimestamp");
        properties.put(LIST_COLUMN_TYPES, "int,string,string");
        properties.setProperty("column.xpath.AssociateIdentifier", "/Customer/@AssociateIdentifier");
        properties.setProperty("column.xpath.CustomerIdentifier", "/Customer/@CustomerIdentifier");
        properties.setProperty("column.xpath.LastUpdateTimestamp", "/Customer/@LastUpdateTimestamp");
        xmlSerDe.initialize(configuration, properties);
        Text text = new Text();
        text.set("<Customer AssociateIdentifier=\"3434\" LastUpdateTimestamp=\"2016-08-26T03:59:15.000-05:00\" CustomerIdentifier=\"999\"></Customer>");
        Object o = xmlSerDe.deserialize(text);
        XmlStructObjectInspector structInspector = ((XmlStructObjectInspector) xmlSerDe.getObjectInspector());

        StructField associateIdentifierStructFieldRef = structInspector.getStructFieldRef("AssociateIdentifier");
        Object associateIdentifierFieldData = structInspector.getStructFieldData(o, associateIdentifierStructFieldRef);
        assertEquals("AssociateIdentifier value does not match", "3434", associateIdentifierFieldData);

        StructField lastUpdateTimestampStructFieldRef = structInspector.getStructFieldRef("LastUpdateTimestamp");
        Object lastUpdateTimestampFieldData = structInspector.getStructFieldData(o, lastUpdateTimestampStructFieldRef);
        assertEquals("LastUpdateTimestamp value does not match", "2016-08-26T03:59:15.000-05:00", lastUpdateTimestampFieldData);

        StructField customerIdentifierStructFieldRef = structInspector.getStructFieldRef("CustomerIdentifier");
        Object customerIdentifierFieldData = structInspector.getStructFieldData(o, customerIdentifierStructFieldRef);
        assertEquals("CustomerIdentifier value does not match", 999, customerIdentifierFieldData);

    }

    public void testCustomerMixXml() throws SerDeException, IOException {
        XmlSerDe xmlSerDe = new XmlSerDe();
        Configuration configuration = new Configuration();
        Properties properties = new Properties();
        properties.put(LIST_COLUMNS, "CustomerIdentifier,AssociateIdentifier,LastUpdateTimestamp");
        properties.put(LIST_COLUMN_TYPES, "int,string,string");
        properties.setProperty("column.xpath.AssociateIdentifier", "/Customer/@AssociateIdentifier");
        properties.setProperty("column.xpath.CustomerIdentifier", "/Customer/@CustomerIdentifier");
        properties.setProperty("column.xpath.LastUpdateTimestamp", "/Customer/@LastUpdateTimestamp");
        xmlSerDe.initialize(configuration, properties);
        Text text = new Text();
        text.set("<Customer LastUpdateTimestamp=\"2016-08-22T00:42:36.000-05:00\" CustomerIdentifier=\"777\"/>");
        Object o = xmlSerDe.deserialize(text);
        XmlStructObjectInspector structInspector = ((XmlStructObjectInspector) xmlSerDe.getObjectInspector());

        StructField associateIdentifierStructFieldRef = structInspector.getStructFieldRef("AssociateIdentifier");
        Object associateIdentifierFieldData = structInspector.getStructFieldData(o, associateIdentifierStructFieldRef);
        assertEquals("AssociateIdentifier value does not match", null, associateIdentifierFieldData);

        StructField lastUpdateTimestampStructFieldRef = structInspector.getStructFieldRef("LastUpdateTimestamp");
        Object lastUpdateTimestampFieldData = structInspector.getStructFieldData(o, lastUpdateTimestampStructFieldRef);
        assertEquals("LastUpdateTimestamp value does not match", "2016-08-22T00:42:36.000-05:00", lastUpdateTimestampFieldData);

        StructField customerIdentifierStructFieldRef = structInspector.getStructFieldRef("CustomerIdentifier");
        Object customerIdentifierFieldData = structInspector.getStructFieldData(o, customerIdentifierStructFieldRef);
        assertEquals("CustomerIdentifier value does not match", 777, customerIdentifierFieldData);

    }


    public void testProfileExplicitXml() throws SerDeException, IOException {
        XmlSerDe xmlSerDe = new XmlSerDe();
        Configuration configuration = new Configuration();
        Properties properties = new Properties();
        properties.put(LIST_COLUMNS, "ProfileIdentifier,ProfileCategoryTypeCode,ProfileCategoryTypeReferenceCode,CustomerIdentifier,SourceSystemIdentifier,SourceSystemCode,SourceSystemReferenceCode,CreateSystemCode,CreateSystemReferenceCode,CreateTimestamp,LastUpdateTimestamp,PreferredProfileIndicator,CustomerAttributeList,CustomerMailingAddressList,CustomerEmailList,CustomerTelephoneList,CustomerCardList,ProfileToProfileLinkList,SupplementalAttributes");
        properties.put(LIST_COLUMN_TYPES, "int,string,string,string,string,string,string,string,string,string,string,string,array<struct<customerattributeidentifier:int,datastatecode:string,datastatereferencecode:string,firstname:string,middlename:string,lastname:string,nameprefixtext:string,namesuffixtext:string,birthdate:date,username:string,customerstartdate:date,createsystemcode:string,createsystemreferencecode:string,createtimestamp:string,lastupdatetimestamp:string,gendercode:string,genderreferencecode:string,socialsecuritynumber:int,deceasedindicator:string,namecheckscorenbr:string,namecheck1code:string,namecheck2code:string,namecheck3code:string,namecheckreferencecode:string>>,array<struct<customermailingaddressidentifier:int,datastatecode:string,datastatereferencecode:string,mailingcontacttypecode:string,mailingcontacttypereferencecode:string,addressline1text:string,addressline2text:string,addressline3text:string,cityname:string,stateprovincecode:string,stateprovincereferencecode:string,postalcode:string,postalextensioncode:string,countycode:string,countyreferencecode:string,countrycode:string,countryreferencecode:string,createsystemcode:string,createsystemreferencecode:string,createtimestamp:string,lastupdatetimestamp:string,deliverabilitycode:string,deliverabilityreferencecode:string,prisonaddressindicator:string,primarycontactindicator:string>>,array<struct<customeremailidentifier:int,datastatecode:string,datastatereferencecode:string,emailaddress:string,emailcontactusagecode:string,emailcontactusagereferencecode:string,primarycontactindicator:string,createsystemcode:string,createsystemreferencecode:string,createtimestamp:string,lastupdatetimestamp:string,emailformatvalidindicator:string,emailusabilitycode:string,emailusabilityreferencecode:string>>,array<struct<customertelephoneidentifier:int,datastatecode:string,datastatereferencecode:string,telephonenumber:string,telephonecontactusagecode:string,telephonecontactusagereferencecode:string,telephonenumbercontactstatuscode:string,telephonenumbercontactstatusreferencecode:string,createsystemcode:string,createsystemreferencecode:string,createtimestamp:string,lastupdatetimestamp:string,telephonevalidindicator:string,primarycontactindicator:string>>,array<struct<customercardidentifier:int,cardnumber:string,cardtypecode:string,cardtypereferencecode:string,cardholdername:string,cardexpirationdate:date,accountnumber:string,createsystemcode:string,createsystemreferencecode:string,createtimestamp:string,lastupdatetimestamp:string,storenumber:int,longcardnumber:string>>,array<struct<linkedprofileidentifier:int,profileexplicitlinkindicator:string,profilelinkreasoncode:string,profilelinkreasonreferencecode:string,profilelinksourcecode:string,profilelinksourcereferencecode:string,lastupdatetimestamp:string>>,struct<profilelinkmatchcode:string,addresslinkmatchcode:string,linkmatchreferencecode:string,appendmatchverifycode:string,appendmatchverifyreferencecode:string,appendmatchconfidencelevelcode:string,appendmatchconfidencelevelreferencecode:string,createsystemcode:string,createsystemreferencecode:string,createtimestamp:string,lastupdatetimestamp:string>");
        properties.setProperty("column.xpath.CreateSystemCode","/Profile/@CreateSystemCode");
        properties.setProperty("column.xpath.CreateSystemReferenceCode","/Profile/@CreateSystemReferenceCode");
        properties.setProperty("column.xpath.CreateTimestamp","/Profile/@CreateTimestamp");
        properties.setProperty("column.xpath.CustomerIdentifier","/Profile/@CustomerIdentifier");
        properties.setProperty("column.xpath.LastUpdateTimestamp","/Profile/@LastUpdateTimestamp");
        properties.setProperty("column.xpath.PreferredProfileIndicator","/Profile/@PreferredProfileIndicator");
        properties.setProperty("column.xpath.ProfileCategoryTypeCode","/Profile/@ProfileCategoryTypeCode");
        properties.setProperty("column.xpath.ProfileCategoryTypeReferenceCode","/Profile/@ProfileCategoryTypeReferenceCode");
        properties.setProperty("column.xpath.ProfileIdentifier","/Profile/@ProfileIdentifier");
        properties.setProperty("column.xpath.SourceSystemCode","/Profile/@SourceSystemCode");
        properties.setProperty("column.xpath.SourceSystemReferenceCode","/Profile/@SourceSystemReferenceCode");
        properties.setProperty("column.xpath.SourceSystemIdentifier","/Profile/@SourceSystemIdentifier");
        properties.setProperty("column.xpath.CustomerAttributeList","/Profile/CustomerAttributeList/CustomerAttribute");
        properties.setProperty("column.xpath.CustomerCardList","/Profile/CustomerCardList/CustomerCard");
        properties.setProperty("column.xpath.CustomerEmailList","/Profile/CustomerEmailList/CustomerEmailList");
        properties.setProperty("column.xpath.CustomerTelephoneList","/Profile/CustomerTelephoneList/CustomerTelephone");
        properties.setProperty("column.xpath.CustomerMailingAddressList","/Profile/CustomerMailingAddressList/CustomerMailingAddress");
        properties.setProperty("column.xpath.ProfileToProfileLinkList","/Profile/ProfileToProfileLinkList/ProfileToProfileLink");
        properties.setProperty("column.xpath.SupplementalAttributes","/Profile/SupplementalAttributes");
        xmlSerDe.initialize(configuration, properties);
        Text text = new Text();
        text.set("<Profile SourceSystemIdentifier=\"C12346652055783099831426\" SourceSystemReferenceCode=\"SRC\" SourceSystemCode=\"KC\" ProfileIdentifier=\"907\" ProfileCategoryTypeReferenceCode=\"PRFLC\" ProfileCategoryTypeCode=\"KCC\" PreferredProfileIndicator=\"Y\" LastUpdateTimestamp=\"2016-08-21T02:14:24.000-05:00\" CreateTimestamp=\"2016-08-21T02:14:17.223-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"FD\"><CustomerAttributeList><CustomerAttribute NameCheckScoreNbr=\"0\" LastUpdateTimestamp=\"2016-08-25T02:13:19.000-05:00\" LastName=\"CARROLL\" GenderReferenceCode=\"GNDR\" GenderCode=\"M\" FirstName=\"MICHAEL\" DataStateReferenceCode=\"DATST\" DataStateCode=\"MOD\" CustomerAttributeIdentifier=\"1258\" CreateTimestamp=\"2016-08-24T23:24:34.267-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T13:33:26.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1107\" CreateTimestamp=\"2016-08-24T13:33:26.557-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T13:44:24.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1108\" CreateTimestamp=\"2016-08-24T13:44:23.745-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T13:50:57.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1114\" CreateTimestamp=\"2016-08-24T13:50:56.496-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T14:00:56.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1115\" CreateTimestamp=\"2016-08-24T14:00:55.659-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T14:08:22.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1121\" CreateTimestamp=\"2016-08-24T14:08:22.426-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T14:15:19.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1122\" CreateTimestamp=\"2016-08-24T14:15:18.781-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T14:27:02.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1127\" CreateTimestamp=\"2016-08-24T14:27:01.876-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T14:31:28.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1128\" CreateTimestamp=\"2016-08-24T14:31:28.402-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T15:54:13.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1180\" CreateTimestamp=\"2016-08-24T15:54:12.095-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T16:03:46.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1181\" CreateTimestamp=\"2016-08-24T16:03:45.066-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T16:12:13.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1224\" CreateTimestamp=\"2016-08-24T16:12:12.713-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T16:29:21.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1240\" CreateTimestamp=\"2016-08-24T16:29:21.183-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T16:36:09.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1242\" CreateTimestamp=\"2016-08-24T16:36:08.613-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T16:42:04.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1243\" CreateTimestamp=\"2016-08-24T16:42:04.197-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T16:50:32.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1247\" CreateTimestamp=\"2016-08-24T16:50:31.699-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T17:02:15.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1249\" CreateTimestamp=\"2016-08-24T17:02:14.394-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T17:17:35.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1251\" CreateTimestamp=\"2016-08-24T17:17:33.648-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T17:30:24.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1252\" CreateTimestamp=\"2016-08-24T17:30:24.007-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T17:35:59.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1253\" CreateTimestamp=\"2016-08-24T17:35:59.272-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T17:53:52.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1254\" CreateTimestamp=\"2016-08-24T17:53:52.094-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T18:12:40.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1255\" CreateTimestamp=\"2016-08-24T18:12:39.618-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute><CustomerAttribute LastUpdateTimestamp=\"2016-08-24T23:24:31.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerAttributeIdentifier=\"1258\" CreateTimestamp=\"2016-08-24T23:24:29.819-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerAttribute></CustomerAttributeList><CustomerCardList><CustomerCard LongCardNumber=\"134660900005300702\" LastUpdateTimestamp=\"2016-08-24T11:27:29.000-05:00\" CreateTimestamp=\"2016-08-21T02:14:17.229-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"FD\" CardTypeReferenceCode=\"CRD\" CardTypeCode=\"KC\" CardExpirationDate=\"Mon Dec 31 00:00:00 CST 2035\" AccountNumber=\"4619532007\" CardNumber=\"610206510702\"></CustomerCard></CustomerCardList><CustomerEmailList><CustomerEmail LastUpdateTimestamp=\"2016-08-21T02:14:30.000-05:00\" EmailContactUsageReferenceCode=\"EMUSG\" EmailContactUsageCode=\"HME\" EmailAddress=\"EMAIL_11@KOHLS.COM\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerEmailIdentifier=\"941\" CreateTimestamp=\"2016-08-21T02:14:17.226-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"FD\"></CustomerEmail></CustomerEmailList><CustomerTelephoneList><CustomerTelephone TelephoneValidIndicator=\"Y\" TelephoneNumberContactStatusReferenceCode=\"TELCN\" TelephoneNumberContactStatusCode=\"MAN\" TelephoneNumber=\"5025175737\" TelephoneContactUsageReferenceCode=\"TLUSG\" TelephoneContactUsageCode=\"WRK\" LastUpdateTimestamp=\"2016-08-25T02:07:40.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"MOD\" CustomerTelephoneIdentifier=\"977\" CreateTimestamp=\"2016-08-24T23:24:34.267-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerTelephone><CustomerTelephone TelephoneNumberContactStatusReferenceCode=\"TELCN\" TelephoneNumberContactStatusCode=\"MAN\" TelephoneNumber=\"5025175737\" TelephoneContactUsageReferenceCode=\"TLUSG\" TelephoneContactUsageCode=\"WRK\" LastUpdateTimestamp=\"2016-08-21T02:14:49.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerTelephoneIdentifier=\"977\" CreateTimestamp=\"2016-08-21T02:14:17.228-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"FD\"></CustomerTelephone></CustomerTelephoneList><CustomerMailingAddressList><CustomerMailingAddress StateProvinceReferenceCode=\"STPRO\" StateProvinceCode=\"WI\" PostalExtensionCode=\"1234\" PostalCode=\"53005\" LastUpdateTimestamp=\"2016-08-25T02:08:29.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"MOD\" CustomerMailingAddressIdentifier=\"1170\" CreateTimestamp=\"2016-08-24T23:24:34.267-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\" CityName=\"BROOKFIELD\" AddressLine1Text=\"123 N MAIN ST\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T13:33:27.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1023\" CreateTimestamp=\"2016-08-24T13:33:26.982-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T13:44:24.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1024\" CreateTimestamp=\"2016-08-24T13:44:24.279-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T13:50:57.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1030\" CreateTimestamp=\"2016-08-24T13:50:57.571-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T14:00:56.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1031\" CreateTimestamp=\"2016-08-24T14:00:56.461-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T14:08:23.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1037\" CreateTimestamp=\"2016-08-24T14:08:23.004-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T14:15:19.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1038\" CreateTimestamp=\"2016-08-24T14:15:19.239-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T14:27:02.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1039\" CreateTimestamp=\"2016-08-24T14:27:02.036-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T14:31:29.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1040\" CreateTimestamp=\"2016-08-24T14:31:28.809-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T15:54:13.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1092\" CreateTimestamp=\"2016-08-24T15:54:13.632-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T16:03:46.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1093\" CreateTimestamp=\"2016-08-24T16:03:46.338-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T16:12:13.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1136\" CreateTimestamp=\"2016-08-24T16:12:13.322-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T16:29:21.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1152\" CreateTimestamp=\"2016-08-24T16:29:21.573-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T16:36:09.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1154\" CreateTimestamp=\"2016-08-24T16:36:09.297-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T16:42:05.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1155\" CreateTimestamp=\"2016-08-24T16:42:04.788-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T16:50:32.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1159\" CreateTimestamp=\"2016-08-24T16:50:32.356-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T17:02:17.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1161\" CreateTimestamp=\"2016-08-24T17:02:16.234-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T17:17:38.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1163\" CreateTimestamp=\"2016-08-24T17:17:37.049-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T17:30:25.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1164\" CreateTimestamp=\"2016-08-24T17:30:24.649-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T17:36:00.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1165\" CreateTimestamp=\"2016-08-24T17:35:59.892-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T17:53:53.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1166\" CreateTimestamp=\"2016-08-24T17:53:52.675-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T18:12:40.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1167\" CreateTimestamp=\"2016-08-24T18:12:40.181-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress><CustomerMailingAddress LastUpdateTimestamp=\"2016-08-24T23:24:33.000-05:00\" DataStateReferenceCode=\"DATST\" DataStateCode=\"SRC\" CustomerMailingAddressIdentifier=\"1170\" CreateTimestamp=\"2016-08-24T23:24:31.991-05:00\" CreateSystemReferenceCode=\"CUSRC\" CreateSystemCode=\"ACX\"></CustomerMailingAddress></CustomerMailingAddressList></Profile>");
        Object o = xmlSerDe.deserialize(text);
        XmlStructObjectInspector structInspector = ((XmlStructObjectInspector) xmlSerDe.getObjectInspector());

        StructField associateIdentifierStructFieldRef = structInspector.getStructFieldRef("CreateSystemCode");
        Object associateIdentifierFieldData = structInspector.getStructFieldData(o, associateIdentifierStructFieldRef);
        assertEquals("CreateSystemCode value does not match", "FD", associateIdentifierFieldData);

        StructField customerAttributeListStructFieldRef = structInspector.getStructFieldRef("CustomerAttributeList");


        Object structFieldData = structInspector.getStructFieldData(o, customerAttributeListStructFieldRef);
        System.out.println(structFieldData);

    }

}