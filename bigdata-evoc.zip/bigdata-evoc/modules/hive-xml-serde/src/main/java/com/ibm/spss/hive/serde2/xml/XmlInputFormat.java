/**
 * (c) Copyright IBM Corp. 2013. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
*/

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.ibm.spss.hive.serde2.xml;

import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DataOutputBuffer;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.*;

import java.io.IOException;


/**
 * Reads records that are delimited by a specific begin/end tag.
 */
public class XmlInputFormat extends TextInputFormat {

    public static final String START_TAG_KEY = "xmlinput.start";
    public static final String END_TAG_KEY = "xmlinput.end";

    @Override
    public RecordReader<LongWritable, Text> getRecordReader(InputSplit inputSplit, JobConf jobConf, Reporter reporter) throws IOException {
        return new XmlRecordReader((FileSplit) inputSplit, jobConf);
    }

    /**
     * XMLRecordReader class to read through a given XML document to output XML blocks as records as specified by the start tag and end tag
     * 
     */
    public static class XmlRecordReader implements RecordReader<LongWritable, Text> {
        private final byte[] startTag;
        private final byte[] endTag;
        private final byte[] endTagDefault = ("/>").getBytes("utf-8");
        private final long start;
        private final long end;
        private final FSDataInputStream fsin;
        private final DataOutputBuffer buffer = new DataOutputBuffer();

        public XmlRecordReader(FileSplit split, JobConf jobConf) throws IOException {

            startTag = jobConf.get(START_TAG_KEY).getBytes("utf-8");
            endTag = jobConf.get(END_TAG_KEY).getBytes("utf-8");

            // open the file and seek to the start of the split
            start = split.getStart();
            end = start + split.getLength();
            Path file = split.getPath();
            FileSystem fs = file.getFileSystem(jobConf);
            fsin = fs.open(split.getPath());
            fsin.seek(start);
        }

        @Override
        public boolean next(LongWritable key, Text value) throws IOException {
            if (fsin.getPos() < end) {
                if (findOpeningTag(startTag, false)) {
                    try {
                        buffer.write(startTag);
                        if (findClosingTag(endTag, true)) {
                            key.set(fsin.getPos());
                            value.set(buffer.getData(), 0, buffer.getLength());
                            return true;
                        }
                    } finally {
                        buffer.reset();
                    }
                }
            }
            return false;
        }

        @Override
        public LongWritable createKey() {
            return new LongWritable();
        }

        @Override
        public Text createValue() {
            return new Text();
        }

        @Override
        public long getPos() throws IOException {
            return fsin.getPos();
        }

        @Override
        public void close() throws IOException {
            fsin.close();
        }

        @Override
        public float getProgress() throws IOException {
            return (fsin.getPos() - start) / (float) (end - start);
        }


        private boolean findOpeningTag(byte[] tag, boolean withinBlock) throws IOException {
            int i = 0;
            boolean  match = false;
            while (true) {
                int b = fsin.read();
                // end of file:
                if (b == -1) {
                    return false;
                }
                // save to buffer:
                if (withinBlock) {
                    buffer.write(b);
                }

                // check if we're taging:
                if (b == tag[i]) {
                    i++;
                    if (i >= tag.length) {
                        match = true;
                    }
                } else {
                    i = 0;
                }

                if( match == true && ((char)b == ' ' || (char)b == '>' )){
                    return true;
                }
                // see if we've passed the stop point:
                if (!withinBlock && i == 0 && fsin.getPos() >= end) {
                    return false;
                }
            }
        }

        private boolean readUntilMatch(byte[] match, boolean withinBlock) throws IOException {
            int i = 0;
            while (true) {
                int b = fsin.read();
                // end of file:
                if (b == -1) {
                    return false;
                }
                // save to buffer:
                if (withinBlock) {
                    buffer.write(b);
                }

                // check if we're matching:
                if (b == match[i]) {
                    i++;
                    if (i >= match.length) {
                        return true;
                    }
                } else {
                    i = 0;
                }
                // see if we've passed the stop point:
                if (!withinBlock && i == 0 && fsin.getPos() >= end) {
                    return false;
                }
            }
        }

        private boolean findClosingTag(byte[] tag, boolean withinBlock) throws IOException {

            int i = 0;      // endTag match length
            int j = 0;      // endTahDefault match length

            int counter = 0;    // openBracket counter

            while (true){
                int b = fsin.read();

                if(b == -1){
                    return false;
                }

                if(withinBlock){
                    buffer.write(b);
                }

                // check if we're matching:
                if (b == tag[i]) {
                    i++;
                    if (i >= tag.length) {
                        return true;
                    }
                } else {
                    i = 0;
                }

                if ((char)b == '<' ){
                    counter++;
                }

                // check if we're matching:
                if (b == endTagDefault[j]) {
                    j++;
                    if (j >= endTagDefault.length && counter == 0) {
                        return true;
                    }
                } else {
                    j = 0;
                }

                // see if we've passed the stop point:
                if (!withinBlock && i == 0 && j == 0 && fsin.getPos() >= end) {
                    return false;
                }

            }
        }

    }
}