package com.kohls.bigdata.evoc.service;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.kohls.bigdata.evoc.misc.PGPContainer;
import com.kohls.bigdata.evoc.misc.PGPDecrypt;

/**
 * Created by tkmac5h on 10/14/16.
 */
public class AcxiomDemographicService {
    private PGPContainer pgpContainer = new PGPContainer();
    private FileNotFoundException fnException = new FileNotFoundException();

    /**
     * Method to process Acxiom file
     * @param pgpContainer {@link PGPContainer}
     */
    public void Demographic(PGPContainer pgpContainer) {
        this.pgpContainer = pgpContainer;
        try {
            if (process()) {
                applyPGP();
            } else {
                throw fnException;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Provide input file check & generate output
     * @return {@link Boolean}
     * @throws IOException {@link IOException}
     */
    private Boolean process() throws IOException {
        if (pgpContainer.getInfile().exists()) {
            pgpContainer.setOutfile(new File(pgpContainer.getInfile().getAbsoluteFile().toString()
                    .substring(0, pgpContainer.getInfile().getAbsoluteFile().toString().indexOf('.'))
                    + ".txt"));
            if (pgpContainer.getOutfile().exists()) {
                pgpContainer.getOutfile().delete();
            }
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

    /**
     * PGP file decryption
     * @throws IOException {@link IOException}
     */
    public void applyPGP() throws IOException {
        PGPDecrypt pgpDecrypt = new PGPDecrypt();
        boolean status = pgpDecrypt.applyPGPOnDelimitedFile(pgpContainer);
        if (status) {
            System.out.println("process complete.");
        } else {
            System.err.println("failed to process Acxiom file " + pgpContainer.getInfile());
        }
    }
}
