package com.kohls.bigdata.evoc.commons;

/**
 * Created by tkmac5h on 10/14/16.
 */
public class ProtegrityElementValidator {

    /**
     * Standard custom reader class
     *
     * @author tkmaclr
     */
    private static final String ALPHANUM_PATTERN = "[^a-zA-Z0-9]";
    private static final String NUM_PATTERN = "[^0-9]";

    /**
     * Method to validate minimum number of alphanumeric characters in input array.
     * @param value					String array to be validated.
     * @param valuelength			Minimum number of alphanumeric characters to be checked.
     * @return						{@link String[]} array with validated tokens.
     */

    public static String[] alphanumericToken(String[] value, int valuelength) {
        for (int i = 0; i < value.length; i++) {
            if (value[i].replaceAll(ALPHANUM_PATTERN, "").length() < valuelength) {
                value[i] = "";
            }
        }
        return value;
    }

    /**
     * Method to validate minimum number of numeric characters in input array.
     * @param value				String array to be validated.
     * @param valuelength 		Minimum number of numeric characters to be checked.
     * @return 					{@link String[]} array with validated tokens.
     */
    public static String[] numericToken(String[] value, int valuelength) {
        for (int i = 0; i < value.length; i++) {
            if (value[i].replaceAll(NUM_PATTERN,"").length() < valuelength) {
                value[i]="";
            }
        }
        return value;
    }

    /**
     * Method to validate minimum number of alphanumeric characters in a given string.
     * @param value					String value to be validated.
     * @param valuelength 			Minimum number of alphanumeric characters to be checked.
     * @return						{@link Boolean} validation status of alphanumeric tokens.
     */
    public static Boolean alphanumericToken(String value, int valuelength) {
        if (value.replaceAll(ALPHANUM_PATTERN,"").length() < valuelength) {
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    /**
     * Method to validate minimum number of numeric characters in a given string.
     * @param value				String value to be validated.
     * @param valuelength 		Minimum number of numeric characters to be checked.
     * @return 					{@link Boolean} validation status of numeric tokens.
     */
    public static Boolean numericToken(String value, int valuelength) {
        if (value.replaceAll(NUM_PATTERN,"").length() < valuelength) {
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }
}
