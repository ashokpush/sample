package com.kohls.bigdata.evoc.misc;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import com.kohls.bigdata.evoc.commons.ProtegrityElementValidator;
import com.kohls.bigdata.evoc.commons.DataWriter;
import com.kohls.bigdata.evoc.commons.EDLConstants.TOKENS;
import com.kohls.bigdata.evoc.utils.TextFormater;



/**
 * Created by tkmac5h on 10/14/16.
 */
public class DataTokenize {
    private ArrayList<String> tokeniseData = null;
    private static String user = null;
    private static int invalidTokens = 0;

    private static int tranformcount = 0;
    private static HashMap<Integer, Enum<?>> map = null;


    public void transformList(ArrayList<String> rawdata, PGPContainer pgpContainer) {
        DataTokenize.user = pgpContainer.getNodeuser();
        map = pgpContainer.getMap();

        tokeniseData = new ArrayList<String>();
        for (int counter = 0; counter < rawdata.size(); counter++) {
            tokeniseData.add(DataTokenize.splitRow(rawdata.get(counter), pgpContainer.getDelimiter()));
        }

        writeTokenizeData(pgpContainer.getOutfile());
        System.out.println("total invalid tokens found " + DataTokenize.invalidTokens);
        System.out.println("transform progress " + DataTokenize.tranformcount);
    }


    private void writeTokenizeData(File file) {
        try {
            DataWriter.writetofile(tokeniseData, file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to call ProtegrityElementValidator to validate token values
     *
     * @param tokens Token type name as described in EDLConstants.TOKENS.
     * @param value Token value to be validated.
     * @return	{@link Boolean} validation status of tokens.
     */
    private static Boolean validate(TOKENS tokens, String value) {
        switch (tokens) {
            case TKN_NAME  	: return ProtegrityElementValidator.alphanumericToken(value,1);
            case TKN_EMAIL 	:
            case TKN_GOVTID :
            case TKN_MICR  	:
            case TKN_POSTAL : return ProtegrityElementValidator.alphanumericToken(value,3);
            case TKN_DATE   : return ProtegrityElementValidator.numericToken(value,3);
            case TKN_INCOME : return ProtegrityElementValidator.numericToken(value,1);
            default 		: System.out.println("new token type found"); break;
        }
        return Boolean.FALSE;
    }

    /**
     * Tokenize tokens
     *
     * @param row line of raw data
     * @param delimiter delimiter character
     * @return row of data with specific columns tokenized with protegrity
     */
    private static final String splitRow(String row, char delimiter) {
        ArrayList<String> list = (ArrayList<String>) TextFormater.formatEmptyTokens(row, delimiter);
        DataTokenize.tranformcount++;
        String line="";
        for (int tokencount = 0; tokencount < list.size(); tokencount++) {
            if (DataTokenize.map.containsKey((Integer)tokencount)) {
                if (validate((TOKENS)DataTokenize.map.get(tokencount), list.get(tokencount))) {
                    line += applyProtegrity(DataTokenize.map.get(tokencount).toString(), list.get(tokencount)) + delimiter;
                } else {
                    DataTokenize.invalidTokens++;
                    line += delimiter;
                }
            } else {
                line += list.get(tokencount) + delimiter;
            }
        }
        return line.substring(0, line.length() - 1);
    }

    /**
     * Application of protegrity on tokens
     *
     * @param token standard tokens
     * @param data value to be tokenize
     * @return encrypted string
     */
    private static String applyProtegrity(String token, String data) {
        NullPointerException npe = new NullPointerException();
        String[] dataArray = { data };

        String[] encryptedToken = ProtegrityCheck.tokenize(DataTokenize.user, token, dataArray);
        if (encryptedToken == null) {
            throw npe;
        }

        return encryptedToken[0];
    }


    public static void main(String[] args){
        PGPContainer pgpContainer = new PGPContainer();
        pgpContainer.setOutfile(new File("/tmp/output_file.txt"));
        ArrayList<String> raw_data= new ArrayList<String>();
        DataTokenize dt=new DataTokenize();
        pgpContainer.setMap(dt.buildMap());
        System.out.println("Test Code for Checking the Protegrity Function");
        try {
            BufferedReader br = new BufferedReader(new FileReader("/tmp/sample_file.txt"));
            String line;
            while((line=br.readLine())!=null){
            System.out.println("File Contents are" + line);
                raw_data.add(line);

            }
            System.out.println("Raw Data Contents in the List is"+raw_data.toString());
            System.out.println("Appling Protegrity Function to raw data");
            dt.transformList(raw_data,pgpContainer);
        }
        catch(Exception ex){
            ex.printStackTrace();
        }

    }
    private HashMap<Integer, Enum<?>> buildMap() {
        HashMap<Integer, Enum<?>> map = new HashMap<>();
        map.put(0, TOKENS.TKN_NAME);
        //map.put(4, TOKENS.TKN_NAME);
        //map.put(5, TOKENS.TKN_NAME);
        //map.put(202, TOKENS.TKN_NAME);
        //map.put(205, TOKENS.TKN_NAME);
        //map.put(10, TOKENS.TKN_POSTAL);
        //map.put(282, TOKENS.TKN_DATE);

        return map;
    }

}
