package com.kohls.bigdata.evoc.utils;
import java.util.ArrayList;
import java.util.List;
/**
 * Created by tkmac5h on 10/14/16.
 */
public class TextFormater {
    /**
     * Method to provide tokenize list of String
     * @param row line of record
     * @param delimiter value for differentiate columns
     * @return {@link List} list of String tokens
     */
    public static List<String> formatEmptyTokens(String row, char delimiter) {
        String[] tokens = row.split(String.valueOf(delimiter));
        List<String> list = new ArrayList<String>();

        if (tokens.length > 0) {
            StringBuilder build = new StringBuilder();
            for (int token = 0; token < tokens.length; token++) {
                if (tokens[token].contains(String.valueOf(delimiter))) {
                    list.add(build.toString());
                    build.delete(0, build.length());
                } else {
                    build.append(tokens[token]);
                }
            }
            list.add(build.toString());
            build = null;
            return list;
        }
        return null;
    }
}
