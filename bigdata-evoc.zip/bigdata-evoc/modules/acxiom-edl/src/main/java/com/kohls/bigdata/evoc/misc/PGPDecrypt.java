package com.kohls.bigdata.evoc.misc;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.NoSuchProviderException;
import java.security.Security;
import java.util.ArrayList;
import java.util.Iterator;

import com.kohls.bigdata.evoc.commons.DataReader;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPCompressedData;
import org.bouncycastle.openpgp.PGPEncryptedDataList;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPLiteralData;
import org.bouncycastle.openpgp.PGPOnePassSignatureList;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKeyEncryptedData;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRingCollection;
import org.bouncycastle.openpgp.PGPUtil;
import org.bouncycastle.openpgp.jcajce.JcaPGPObjectFactory;
import org.bouncycastle.openpgp.operator.jcajce.JcaKeyFingerprintCalculator;
import org.bouncycastle.openpgp.operator.jcajce.JcePBESecretKeyDecryptorBuilder;
import org.bouncycastle.openpgp.operator.jcajce.JcePublicKeyDataDecryptorFactoryBuilder;

import com.kohls.bigdata.evoc.commons.EDLConstants;


/**
 * Created by tkmac5h on 10/14/16.
 */
public class PGPDecrypt {
    private PGPContainer pgpContainer = null;

    private PGPPrivateKey sKey = null;
    private PGPPublicKeyEncryptedData pbe = null;

    private InputStream infile = null;
    private InputStream pkey = null;

    /**
     * Method to invoke security provider service on BC only for
     * delimited files irrespective of delimiter like comma, pipe etc.
     *
     * @param pgpContainer {@link PGPContainer}
     * @throws IOException {@link IOException}
     */
    public Boolean applyPGPOnDelimitedFile(PGPContainer pgpContainer) throws IOException {
        System.out.println("implementing security provider for BC");
        Security.addProvider(new BouncyCastleProvider());

        this.pgpContainer = pgpContainer;
        if (this.pgpContainer != null) {
            return streamerOnPGP(decrypt());
        }
        return Boolean.FALSE;
    }

    /**
     * Decryption process. Also provides stream reading for file tokenizing.
     */


    /**
     * Decryption process. Also provides stream reading for file tokenizing.
     */
    private Object decrypt() {
        Object message = null;
        try {
            System.out.println("PGP decryption in progress");
            infile = PGPUtil.getDecoderStream(new BufferedInputStream(new FileInputStream(pgpContainer.getInfile())));
            pkey = new FileInputStream(pgpContainer.getPrivatekey());

            JcaPGPObjectFactory jcaPGPObjectFactory = new JcaPGPObjectFactory(infile);
            PGPEncryptedDataList enc;
            Object o = jcaPGPObjectFactory.nextObject();

            // the first object might be a PGP marker packet.
            if (o instanceof PGPEncryptedDataList) {
                enc = (PGPEncryptedDataList) o;
            } else {
                enc = (PGPEncryptedDataList) jcaPGPObjectFactory.nextObject();
            }

            // find the secret key
            @SuppressWarnings("unchecked")
            Iterator<PGPPublicKeyEncryptedData> it = enc.getEncryptedDataObjects();

            PGPSecretKeyRingCollection pgpSec = new PGPSecretKeyRingCollection(PGPUtil.getDecoderStream(new BufferedInputStream(pkey)), new JcaKeyFingerprintCalculator());

            while (sKey == null && it.hasNext()) {
                pbe = (PGPPublicKeyEncryptedData) it.next();
                sKey = findSecretKey(pgpSec, pbe.getKeyID(), pgpContainer.getPassPhrase().toCharArray());
            }

            if (sKey == null) {
                throw new IllegalArgumentException("secret key for message not found.");
            }

            JcaPGPObjectFactory plainFact = new JcaPGPObjectFactory(
                    pbe.getDataStream(new JcePublicKeyDataDecryptorFactoryBuilder()
                            .setProvider("BC").build(sKey)));
            message = plainFact.nextObject();

            if (message instanceof PGPCompressedData) {
                PGPCompressedData cData = (PGPCompressedData) message;
                JcaPGPObjectFactory pgpFact = new JcaPGPObjectFactory(
                        cData.getDataStream());

                message = pgpFact.nextObject();
                if(message instanceof PGPOnePassSignatureList){
                    message = pgpFact.nextObject();
                }
            }
        } catch (IOException ioc) {
            ioc.printStackTrace();
        } catch (PGPException e) {
            if (e.getUnderlyingException() != null) {
                e.getUnderlyingException().printStackTrace();
            }
        } catch (NoSuchProviderException e) {
            e.printStackTrace();
        }

        return message;
    }


    /**
     * Method to stream of file data.
     *
     * @param message message object vailable post decryption
     * @return {@link Boolean} completion status
     */
    private Boolean streamerOnPGP(Object message) {
        try {
            if (message != null) {

                if (message instanceof PGPLiteralData) {
                    System.out.println("file open for data streaming");
                    readfile(((PGPLiteralData) message).getInputStream());
                    System.out.println("protegrity on streaming data done");
                } else if (message instanceof PGPOnePassSignatureList) {
                    throw new PGPException(
                            "encrypted message contains a signed message - not literal data.");
                } else {
                    throw new PGPException(
                            "message is not a simple encrypted file - type unknown.");
                }

                if (pbe.isIntegrityProtected()) {
                    if (!pbe.verify()) {
                        System.err.println("message failed integrity check");
                    } else {
                        System.err.println("message integrity check passed");
                    }
                } else {
                    System.err.println("no message integrity check");
                }
                return Boolean.TRUE;
            } else {
                System.out.println("message object is null. Either the file is not decrypted or key/pass-phrase does not match");
            }
        } catch (IOException ioc) {
            ioc.printStackTrace();
        } catch (PGPException e) {
            if (e.getUnderlyingException() != null) {
                e.getUnderlyingException().printStackTrace();
            }
        } finally {
            try {
                if (infile != null) {
                    System.out.println("closing file stream/s");
                    infile.close();
                    pkey.close();
                }
            } catch (IOException e2) {
                e2.printStackTrace();
            }
        }

        return Boolean.FALSE;
    }

    /**
     * Search a secret key ring collection for a secret key corresponding to
     * keyID if it exists.
     *
     * @param pgpSec a secret key ring collection.
     * @param keyID keyID we want.
     * @param pass passphrase to decrypt secret key with.
     * @return the private key.
     * @throws PGPException
     * @throws NoSuchProviderException
     */
    private PGPPrivateKey findSecretKey(PGPSecretKeyRingCollection pgpSec,
                                        long keyID, char[] pass) throws PGPException,
            NoSuchProviderException {
        PGPSecretKey pgpSecKey = pgpSec.getSecretKey(keyID);

        if (pgpSecKey == null) {
            return null;
        }

        return pgpSecKey
                .extractPrivateKey(new JcePBESecretKeyDecryptorBuilder()
                        .setProvider("BC").build(pass));
    }

    /**
     * Method for creating List of raw data using IO streaming
     * @param unc {@link InputStream} input file stream
     * @throws IOException
     */
    private void readfile(InputStream unc) throws IOException {
        try {
            System.out.println("protegrity application");
            BufferedReader bufferRead = DataReader.bufferReaderBlock(unc);

            ArrayList<String> rawdata = new ArrayList<String>();
            DataTokenize dataTokenize = new DataTokenize();

            int batchsize = (pgpContainer.getBatchsize() > 0) ? pgpContainer.getBatchsize() : EDLConstants.PGP_BATCH;
            System.out.println("using batch size of " + batchsize);

            String line;
            boolean header = true;
            while ((line = bufferRead.readLine()) != null) {
                    rawdata.add(line);
                    if (rawdata.size() >= batchsize) {
                        dataTokenize.transformList(rawdata, pgpContainer);
                        rawdata.clear();
                    }
            }

            if (rawdata.size() > 0 && header) {
                dataTokenize.transformList(rawdata, pgpContainer);
            }

            System.out.println("protegrity on streaming data done");
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (infile != null) {
                    System.out.println("closing file stream/s");
                    infile.close();
                    pkey.close();
                }
            } catch (IOException e2) {
                e2.printStackTrace();
            }
        }
    }
}
