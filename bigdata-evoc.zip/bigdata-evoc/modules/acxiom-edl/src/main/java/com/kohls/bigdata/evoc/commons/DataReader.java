package com.kohls.bigdata.evoc.commons;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Created by tkmac5h on 10/14/16.
 */
public class DataReader {
    static BufferedReader reader;

    /**
     * Method to provide ISO code set type standard reader object
     *
     * @param file {@link File}
     * @return {@linkplain BufferedReader}
     * @throws IOException
     */
    public static BufferedReader bufferReaderBlock(File file) throws IOException {
        return Files.newBufferedReader(Paths.get(file.toString()), StandardCharsets.ISO_8859_1);
    }

    /**
     * Method to provide specific code set type reader object
     *
     * @param file {@link File}
     * @param type String standard character set based on user input
     * @return {@linkplain BufferedReader}
     * @throws IOException
     */
    public static BufferedReader bufferReaderBlock(File file, String type) throws IOException {
        return Files.newBufferedReader(Paths.get(file.toString()), standardCharset(type));
    }

    /**
     * Method to provide ISO code set type standard reader object
     *
     * @param inputStream {@link InputStream}
     * @return {@linkplain BufferedReader}
     * @throws IOException
     */
    public static BufferedReader bufferReaderBlock(InputStream inputStream) throws IOException {
        return new BufferedReader(new InputStreamReader(inputStream));
    }


    /**
     * Method to select standard character set
     *
     * @param type String standard character set
     * @return {@link StandardCharsets}
     */
    private static Charset standardCharset(String type) {
        if (type.equals("ISO")) {
            return StandardCharsets.ISO_8859_1;
        } else {
            return Charset.defaultCharset();
        }
    }

}
