package com.kohls.bigdata.evoc.misc;
//import org.apache.hadoop.fs.Path;

import com.protegrity.ap.java.Protector;
import com.protegrity.ap.java.SessionObject;

/**
 * Created by tkmac5h on 10/14/16.
 */
public class ProtegrityCheck {

    /**
     * Method to invoke the process
     * @param args String[] username, token and sample value
     */
    public static void main(String[] args) {
        if (args.length == 3)
            protokenize(args[0], args[1], args[2]);
        else
            throw new ArrayIndexOutOfBoundsException();
    }

    /**
     * Method to validate protegrity
     * @param user
     * @param token
     * @param data
     *
     * N.D encryption CUST_INFO token TKN_NAME TKN_DATE TKN_POSTAL TKN_EMAIL TKN_GOVTID TKN_MICR TKN_INCOME
     */
    public static void protokenize(String user, String token, String data) {
        String[] inputStringArray = new String[1];
        String[] outputStringArray = null;

        inputStringArray[0] = data;
        outputStringArray = tokenize(user, token, inputStringArray);
        outputStringArray = detokenize(user, token, outputStringArray);
        System.out.println(outputStringArray[0]);
    }

    /**
     * Method to apply tokenization on sample value
     * @param user String unix user
     * @param token String token created in EDL
     * @param data String sample value to apply protegrity
     * @return
     */
    public static String[] tokenize(String user, String token, String[] data) {
        String[] ProtectStringArray = new String[data.length];
        try {
			/* Instantiate the protector */
            Protector protector = Protector.getProtector();
			/* Set input parameters and create session */
            SessionObject session = protector.createSession(user);
			/* Test protect method */
            if (!(protector.protect(session, token, data,
                    ProtectStringArray))) {
                System.out.println("ERROR tokenization failed - "+ protector.getLastError(session));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ProtectStringArray;
    }

    /**
     * Method to apply detokenization on sample value
     * @param user String unix user
     * @param token String token created in EDL
     * @param data String sample value to apply protegrity
     * @return
     */
    public static String[] detokenize(String user, String token, String[] data) {
        String[] unProtectStringArray = new String[data.length];
        try {
			/* Instantiate the protector */
            Protector protector = Protector.getProtector();
			/* Set input parameters and create session */
            SessionObject session = protector.createSession(user);
			/* Test unprotect method */
            if (!(protector.unprotect(session, token, data,
                    unProtectStringArray))) {
                System.out.println("ERROR detokenization failed - "+ protector.getLastError(session));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return unProtectStringArray;
    }

    /**
     * Method to apply detokenization on sample value
     * @param user String unix user
     * @param token String token created in EDL
     * @param data {@link Byte} sample value to apply protegrity
     * @return {@link Byte} array detokenized
     */
    public static byte[][] detokenize(String user, String token, byte[][] data) {
        byte[][] unProtectStringArray = new byte[data.length][];
        try {
			/* Instantiate the protector */
            Protector protector = Protector.getProtector();
			/* Set input parameters and create session */
            SessionObject session = protector.createSession(user);
			/* Test unprotect method */
            if (!(protector.unprotect(session, token, data,
                    unProtectStringArray))) {
                System.out.println("ERROR detokenization failed - "+ protector.getLastError(session));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return unProtectStringArray;
    }

   /* *//**
     * Method to apply detokenization on sample value
     * @param user String unix user
     * @param token String token created in EDL
     * @param data {@link Byte} sample value to apply protegrity
     * @return {@link Byte} array detokenized
     *//*
    public static byte[][] detokenizeHDFS(String user, String token, byte[][] data, Path filePath) {
        byte[][] unProtectStringArray = new byte[data.length][];
        try {
			*//* Instantiate the protector *//*
            Protector protector = Protector.getProtector();
			*//* Set input parameters and create session *//*
            SessionObject session = protector.createSession(user);
			*//* Test unprotect method *//*
            if (!(protector.unprotect(session, token, data,
                    unProtectStringArray))) {
                System.out.println("INFO: "+filePath+" file having one or more elements problem with encrypted-encoded value");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return unProtectStringArray;
    }*/
}
