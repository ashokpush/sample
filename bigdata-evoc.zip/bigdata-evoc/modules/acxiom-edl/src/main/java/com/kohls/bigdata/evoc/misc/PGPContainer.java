package com.kohls.bigdata.evoc.misc;

import java.io.File;
import java.util.HashMap;
/**
 * Created by tkmac5h on 10/14/16.
 */
public class PGPContainer {
    private File infile = null;
    private File privatekey = null;

    private File outfile = null;
    private String nodeuser = null;
    private String passPhrase = null;

    private int batchsize = 0;
    private char delimiter ='|';

    private HashMap<Integer, Enum<?>> map = null;


    /**
     * @return
     */
    public HashMap<Integer, Enum<?>> getMap() {
        return map;
    }

    /**
     * @param map
     */
    public void setMap(HashMap<Integer, Enum<?>> map) {
        this.map = map;
    }

    /**
     * @return
     */
    public File getInfile() {
        return infile;
    }

    /**
     * @param infile
     */
    public void setInfile(File infile) {
        this.infile = infile;
    }

    /**
     * @return
     */
    public File getOutfile() {
        return outfile;
    }

    /**
     * @param outfile
     */
    public void setOutfile(File outfile) {
        this.outfile = outfile;
    }

    /**
     * @return
     */
    public File getPrivatekey() {
        return privatekey;
    }

    /**
     * @param privatekey
     */
    public void setPrivatekey(File privatekey) {
        this.privatekey = privatekey;
    }

    /**
     * @return
     */
    public String getNodeuser() {
        return nodeuser;
    }

    /**
     * @param nodeuser
     */
    public void setNodeuser(String nodeuser) {
        this.nodeuser = nodeuser;
    }

    /**
     * @return
     */
    public String getPassPhrase() {
        return passPhrase;
    }

    /**
     * @param passPhrase
     */
    public void setPassPhrase(String passPhrase) {
        this.passPhrase = passPhrase;
    }

    /**
     * @return
     */
    public int getBatchsize() {
        return batchsize;
    }

    /**
     * @param batchsize
     */
    public void setBatchsize(int batchsize) {
        this.batchsize = batchsize;
    }

    /**
     * @return
     */
    public char getDelimiter() {
        return delimiter;
    }

    /**
     * @param delimiter
     */
    public void setDelimiter(char delimiter) {
        this.delimiter = delimiter;
    }
}
