package com.kohls.bigdata.evoc.commons;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
/**
 * Created by tkmac5h on 10/14/16.
 */
public class DataWriter {

    /**
     * Method to write set of data to file
     *
     * @param dataset {@link ArrayList}
     * @param file {@link File} file to write
     * @param writetype
     *            file write operation flag
     * @throws IOException
     */
    public static void writetofile(ArrayList<String> dataset, File file) throws IOException {
        Files.write(Paths.get(file.toString()), dataset, Charset.forName("UTF-8"), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }

    /**
     * Method to write set of data to file
     *
     * @param dataset {@link ArrayList}
     * @param file {@link File} file to write
     * @param writetype
     *            file write operation flag
     */
    public static void writetofile(ArrayList<String> dataset, File file, boolean write) {
        try {
            if (write) {
                Files.write(Paths.get(file.toString()), dataset, Charset.forName("UTF-8"));
            } else {
                Files.write(Paths.get(file.toString()), dataset, Charset.forName("UTF-8"), StandardOpenOption.APPEND);
            }
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    /**
     *
     * @param dataset
     * @param file
     */
    public void threadedWriter(ArrayList<String> dataset, File file) {
        System.out.println("logic not available");
    }
}
