package com.kohls.bigdata.evoc.acxiom;
import java.io.File;
import java.util.HashMap;

import com.kohls.bigdata.evoc.service.AcxiomDemographicService;
import com.kohls.bigdata.evoc.commons.EDLConstants.TOKENS;
import com.kohls.bigdata.evoc.misc.PGPContainer;

/**
 * Created by tkmac5h on 10/14/16.
 */
public class AcxiomDemographic
{

    /**
     * Acxiom Demographic file processing parent method
     * args[] input_file, private_key, node_user, pass_phrase, [batch_size]
     *
     * @param args
     */
    public static void main(String[] args) {
        try {
            if (args.length >= 4) {
                PGPContainer pgpContainer = new PGPContainer();
                pgpContainer.setInfile(new File(args[0]));
                pgpContainer.setPrivatekey(new File(args[1]));

                pgpContainer.setNodeuser(args[2]);
                pgpContainer.setPassPhrase(args[3]);

                if (args.length == 5) {
                    pgpContainer.setBatchsize(Integer.valueOf(args[4]));
                }

                AcxiomDemographic acxiomDemographic = new AcxiomDemographic();
                pgpContainer.setMap(acxiomDemographic.buildMap());

                AcxiomDemographicService acxiomDemographicService = new AcxiomDemographicService();
                System.out.println("transformation for PGP file " + pgpContainer.getInfile().getName());
                acxiomDemographicService.Demographic(pgpContainer);
            } else {
                System.out.println("ERROR arguments incomplete");
                System.out.println("USAGE com.kohls.edl.acxiom.AcxiomDemogrphic <input_file> <pgp_private_key> <node_user> <pass_phrase> [batchsize]");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Map of column to be tokenize. The count of column is considered starting
     * from zero. Eg. 0|1|2|3...
     *
     * @return {@link HashMap} map of columns & token type
     */
    private HashMap<Integer, Enum<?>> buildMap() {
        HashMap<Integer, Enum<?>> map = new HashMap<>();
        map.put(203, TOKENS.TKN_NAME);
        map.put(204, TOKENS.TKN_NAME);
        map.put(205, TOKENS.TKN_NAME);
        map.put(206, TOKENS.TKN_NAME);
        map.put(207, TOKENS.TKN_NAME);
        map.put(208, TOKENS.TKN_NAME);
        map.put(283, TOKENS.TKN_MICR);
        return map;
    }

}
