#!/bin/bash

LOCAL_DIR=${mvn.evoc.dev.local.data.dir}
