#!/bin/bash
###############################################################################
#                               Documentation                                 #
###############################################################################
#                                                                             #
# Description                                                                 #
#     :                                                                       #
#                                                                             #
#                                                                             #
#                                                                             #
###############################################################################
#                           Setup Local Directories                           #
###############################################################################

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-eit-cr-crd-payt-trn-ingest"
fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-eit-cr-crd-payt-trn-merge"

#bash ${COORDINATOR_HOME}/bin/create_flow.sh FLOW_ID="cmdm-raw-eit-cr-crd-payt-trn-flow" FLOW_NAME="cmdm-raw-eit-cr-crd-payt-trn-flow" FLOW_DESC="External\Data\Ingestion\Flow"
#
#bash ${COORDINATOR_HOME}/bin/add_job.sh JOB_ID="cmdm-eit-cr-crd-payt-trn-ingest" JOB_NAME="cmdm-eit-cr-crd-payt-trn-ingest" JOB_DESC="External\Customer\Ingestion\Job" JOB_TYPE="shell" FLOW_ID="cmdm-raw-eit-cr-crd-payt-trn-flow"
#
#bash ${COORDINATOR_HOME}/bin/add_job.sh JOB_ID="cmdm-eit-cr-crd-payt-trn-merge" JOB_NAME="cmdm-eit-cr-crd-payt-trn-merge" JOB_DESC="External\Customer\Ingestion\Job" JOB_TYPE="shell" FLOW_ID="cmdm-raw-eit-cr-crd-payt-trn-flow"
#
#bash ${COORDINATOR_HOME}/bin/create_flow.sh FLOW_ID="cmdm-daily-sls-xref-flow" FLOW_NAME="cmdm-daily-sls-xref-flow" FLOW_DESC="External\SlsXref\Daily\Creation\Flow"
################################################################################
#                                     End                                      #
################################################################################

