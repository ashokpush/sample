#!/bin/bash
###############################################################################
#                               Documentation                                 #
###############################################################################
#                                                                             #
# Description                                                                 #
#     :                                                                       #
#                                                                             #
#                                                                             #
#                                                                             #
###############################################################################
#                                                                             #
###############################################################################

#Gold Current Table Creation
fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-cust-gold-current/etc/schema/cmdm-cust-gold-current.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-cust-gp-gold-current/etc/schema/cmdm-cust-gp-gold-current.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-acct-gold-current/etc/schema/cmdm-acct-gold-current.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-prfl-gold-current/etc/schema/cmdm-prfl-gold-current.hql"

################################################################################
#                                     End                                      #
################################################################################
