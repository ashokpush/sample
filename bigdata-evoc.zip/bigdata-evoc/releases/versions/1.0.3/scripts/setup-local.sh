#!/bin/bash
###############################################################################
#                               Documentation                                 #
###############################################################################
#                                                                             #
# Description                                                                 #
#     :                                                                       #
#                                                                             #
#                                                                             #
#                                                                             #
###############################################################################
#                           Setup Local Directories                           #
###############################################################################
bash ${COORDINATOR_HOME}/bin/create_flow.sh FLOW_ID="cmdm-acxiom-flow" FLOW_NAME="cmdm-acxiom-flow" FLOW_DESC="External\AcxiomData\Ingestion\Flow"

bash ${COORDINATOR_HOME}/bin/add_job.sh JOB_ID="cmdm-acxiom-merge" JOB_NAME="cmdm-acxiom-merge" JOB_DESC="External\Acxiom\Ingestion\Job" JOB_TYPE="shell" FLOW_ID="cmdm-acxiom-flow"

bash ${COORDINATOR_HOME}/bin/create_flow.sh FLOW_ID="cmdm-raw-ei-e-ord-trn-ingestion-flow" FLOW_NAME="cmdm-raw-ei-e-ord-trn-ingestion-flow" FLOW_DESC="External\Raw-Ei-E-Ord-Trn\Ingestion\Flow"

bash ${COORDINATOR_HOME}/bin/create_flow.sh FLOW_ID="cmdm-sls-xref-flow" FLOW_NAME="cmdm-sls-xref-flow" FLOW_DESC="External\SlsXref\Creation\Flow"

bash ${COORDINATOR_HOME}/bin/create_flow.sh FLOW_ID="cmdm-daily-error-processing-flow" FLOW_NAME="cmdm-daily-error-processing-flow" FLOW_DESC="External\DailyError\Creation\Flow"

bash ${COORDINATOR_HOME}/bin/create_flow.sh FLOW_ID="cmdm-weekly-error-processing-flow" FLOW_NAME="cmdm-weekly-error-processing-flow" FLOW_DESC="External\WeeklyError\Creation\Flow"

bash ${COORDINATOR_HOME}/bin/create_flow.sh FLOW_ID="cmdm-raw-tera-ingestion-flow" FLOW_NAME="cmdm-raw-tera-ingestion-flow" FLOW_DESC="External\Raw-Tera\Ingestion\Flow"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-acxiom-setup"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-acxiom-ingest"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-acxiom-validation"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-acxiom-merge"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-acxiom-gold-current"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-acxiom-cleanup"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-acct-error-processing"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-cust-error-processing"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-cust-gp-error-processing"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-prfl-error-processing"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-daily-acct-error-processing"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-daily-cust-error-processing"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-daily-cust-gp-error-processing"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-daily-prfl-error-processing"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-error-setup"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-acxiom-edl"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-acxiom-edl-transfer"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-ei-e-ord-trn-ingest"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-ei-e-ord-trn-merge"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-ei-e-ord-trn-setup"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-ei-e-ord-trn-cleanup"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-acct-delete"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-acct-delete-error"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-cust-delete"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-cust-delete-error"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-cust-gp-delete"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-cust-gp-delete-error"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-prfl-delete"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-prfl-delete-error"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-delete-ingest"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-delete-merge"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-delete-parse"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-delete-validation"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-trn-cust-prfl-xref"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-sls-xref-setup"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-raw-ei-e-ord-trn-ingest"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-raw-ei-e-ord-trn-merge"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-raw-eit-trn-pt-ingest"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-raw-eit-trn-pt-merge"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-raw-eiv-pos-payt-trn-ingest"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-raw-eiv-pos-payt-trn-merge"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-raw-eiv-pos-trn-ingest"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-raw-eiv-pos-trn-merge"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-tera-cleanup"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-tera-import-setup"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-raw-eit-e-ord-ingest"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-raw-eit-e-ord-merge"

################################################################################
#                                     End                                      #
################################################################################