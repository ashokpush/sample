#!/bin/bash
###############################################################################
#                               Documentation                                 #
###############################################################################
#                                                                             #
# Description                                                                 #
#     :                                                                       #
#                                                                             #
#                                                                             #
#                                                                             #
###############################################################################
#                           Setup Hive Directories                            #
###############################################################################
fn_create_hdfs_directory "${CMDM_RAW_DIR}/acxiom"

fn_create_hdfs_directory "${CMDM_RAW_DIR}/acxiomdemog"

fn_create_hdfs_directory "${CMDM_RAW_DIR}/acxiom_control_file"

fn_create_hdfs_directory "${TRANSFER_PATH}"

fn_create_hdfs_directory "${CMDM_RAW_DIR}/ei_e_ord_trn"

################################################################################
#                                     End                                      #
################################################################################

