#!/bin/bash
###############################################################################
#                               Documentation                                 #
###############################################################################
#                                                                             #
# Description                                                                 #
#     :                                                                       #
#                                                                             #
#                                                                             #
#                                                                             #
###############################################################################
#                                                                             #
###############################################################################

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-acxiom-merge/etc/schema/raw_extl_acxiom_customer_demographic.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-acxiom-gold-current/etc/schema/cmdm-acxiom-gold-current.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-ei-e-ord-trn-merge/etc/schema/raw-ei-e-ord-trn.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-acxiom-gold-current/etc/schema/raw_extl_acxiom_customer_demographic_error.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-delete-parse/etc/schema/stage-delete.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-trn-cust-prfl-xref-daily/etc/schema/raw_hct_trn_cust_prfl_error.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-trn-cust-prfl-xref-daily/etc/schema/gold_hct_trn_cust_prfl.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-acct-error-processing/etc/schema/raw_uc_record_processed_code.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-raw-ei-e-ord-trn-merge/etc/schema/raw-ei-e-ord-trn.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-raw-eit-e-ord-merge/etc/schema/raw-eit-e-ord.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-raw-eit-trn-pt-merge/etc/schema/raw-eit-trn-pt.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-raw-eiv-pos-payt-trn-merge/etc/schema/raw_eiv_pos_payt_trn_cdh.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-raw-eiv-pos-trn-merge/etc/schema/raw-eiv-pos-trn.hql"


fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-raw-eit-cr-crd-tndr-trn-merge/etc/schema/raw_eit_cr_crd_tndr_trn_cdh.hql"


################################################################################
#                                     End                                      #
################################################################################
