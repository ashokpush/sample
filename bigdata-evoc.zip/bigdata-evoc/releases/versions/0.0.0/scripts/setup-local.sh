#!/bin/bash
###############################################################################
#                               Documentation                                 #
###############################################################################
#                                                                             #
# Description                                                                 #
#     :                                                                       #
#                                                                             #
#                                                                             #
#                                                                             #
###############################################################################
#                        Setup HDFS Layer Directories                         #
###############################################################################


fn_create_local_directory  "${AZKABAN_TMP_DIR}"

fn_create_local_directory  "${LOCAL_DATA_DIR}"

fn_create_local_directory  "${LOCAL_DATA_DIR}/azkaban/flows"


bash ${COORDINATOR_HOME}/bin/create_flow.sh FLOW_ID="cmdm-propensity-flow" FLOW_NAME="cmdm-propensity-flow" FLOW_DESC="External\PropensityData\Ingestion\Flow"

bash ${COORDINATOR_HOME}/bin/create_flow.sh FLOW_ID="cmdm-evoc-flow" FLOW_NAME="cmdm-evoc-flow" FLOW_DESC="External\Data\Ingestion\Flow"

#Register job

bash ${COORDINATOR_HOME}/bin/add_job.sh JOB_ID="cmdm-cust-merge" JOB_NAME="cmdm-cust-merge" JOB_DESC="External\Customer\Ingestion\Job" JOB_TYPE="shell" FLOW_ID="cmdm-evoc-flow"

bash ${COORDINATOR_HOME}/bin/add_job.sh JOB_ID="cmdm-cust-gp-merge" JOB_NAME="cmdm-cust-gp-merge" JOB_DESC="External\CustomerGroup\Ingestion\Job" JOB_TYPE="shell" FLOW_ID="cmdm-evoc-flow"

bash ${COORDINATOR_HOME}/bin/add_job.sh JOB_ID="cmdm-acct-merge" JOB_NAME="cmdm-acct-merge" JOB_DESC="External\Account\Ingestion\Job" JOB_TYPE="shell" FLOW_ID="cmdm-evoc-flow"

bash ${COORDINATOR_HOME}/bin/add_job.sh JOB_ID="cmdm-prfl-merge" JOB_NAME="cmdm-prfl-merge" JOB_DESC="External\Profile\Ingestion\Job" JOB_TYPE="shell" FLOW_ID="cmdm-evoc-flow"

bash ${COORDINATOR_HOME}/bin/add_job.sh JOB_ID="cmdm-cust-gold-hist" JOB_NAME="cmdm-cust-gold-hist" JOB_DESC="External\Customer\Ingestion\Job" JOB_TYPE="shell" FLOW_ID="cmdm-evoc-flow"

bash ${COORDINATOR_HOME}/bin/add_job.sh JOB_ID="cmdm-cust-gp-gold-hist" JOB_NAME="cmdm-cust-gp-gold-hist" JOB_DESC="External\CustomerGroup\Ingestion\Job" JOB_TYPE="shell" FLOW_ID="cmdm-evoc-flow"

bash ${COORDINATOR_HOME}/bin/add_job.sh JOB_ID="cmdm-acct-gold-hist" JOB_NAME="cmdm-acct-gold-hist" JOB_DESC="External\Account\Ingestion\Job" JOB_TYPE="shell" FLOW_ID="cmdm-evoc-flow"

bash ${COORDINATOR_HOME}/bin/add_job.sh JOB_ID="cmdm-prfl-gold-hist" JOB_NAME="cmdm-prfl-gold-hist" JOB_DESC="External\Profile\Ingestion\Job" JOB_TYPE="shell" FLOW_ID="cmdm-evoc-flow"

bash ${COORDINATOR_HOME}/bin/add_job.sh JOB_ID="cmdm-acct-gold-current" JOB_NAME="cmdm-acct-gold-current" JOB_DESC="External\Account\Ingestion\Job" JOB_TYPE="shell" FLOW_ID="cmdm-evoc-flow"

bash ${COORDINATOR_HOME}/bin/add_job.sh JOB_ID="cmdm-prfl-gold-current" JOB_NAME="cmdm-prfl-gold-current" JOB_DESC="External\Profile\Ingestion\Job" JOB_TYPE="shell" FLOW_ID="cmdm-evoc-flow"

bash ${COORDINATOR_HOME}/bin/add_job.sh JOB_ID="cmdm-cust-gold-current" JOB_NAME="cmdm-cust-gold-current" JOB_DESC="External\Customer\Ingestion\Job" JOB_TYPE="shell" FLOW_ID="cmdm-evoc-flow"

bash ${COORDINATOR_HOME}/bin/add_job.sh JOB_ID="cmdm-cust-gp-gold-current" JOB_NAME="cmdm-cust-gp-gold-current" JOB_DESC="External\Customer_group\Ingestion\Job" JOB_TYPE="shell" FLOW_ID="cmdm-evoc-flow"

bash ${COORDINATOR_HOME}/bin/add_job.sh JOB_ID="cmdm-propensity-parse" JOB_NAME="cmdm-propensity-parse" JOB_DESC="External\Propensity\Ingestion\Job" JOB_TYPE="shell" FLOW_ID="cmdm-propensity-flow"


################################################################################
#                                     End                                      #
################################################################################

