#!/bin/bash
###############################################################################
#                               Documentation                                 #
###############################################################################
#                                                                             #
# Description                                                                 #
#     :                                                                       #
#                                                                             #
#                                                                             #
#                                                                             #
###############################################################################
#                                                                             #
###############################################################################

#Stage Table creation
fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
    "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
    "${PROJECT_HOME_DIRECTORY}/cmdm-cust-parse/etc/schema/stage-cust.hql"


fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
    "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
    "${PROJECT_HOME_DIRECTORY}/cmdm-cust-gp-parse/etc/schema/stage-cust-gp.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
    "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
    "${PROJECT_HOME_DIRECTORY}/cmdm-acct-parse/etc/schema/stage-acct.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
    "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
    "${PROJECT_HOME_DIRECTORY}/cmdm-prfl-parse/etc/schema/stage-prfl.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
    "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
    "${PROJECT_HOME_DIRECTORY}/cmdm-ref-val-parse/etc/schema/stage-ref-val.hql"

#Gold History Table creation
fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
    "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
    "${PROJECT_HOME_DIRECTORY}/cmdm-acct-gold-hist/etc/schema/gold_hcth_acct.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-cust-gold-hist/etc/schema/gold_hcth_cust.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-cust-gp-gold-hist/etc/schema/gold_hcth_cust_gp.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-prfl-gold-hist/etc/schema/gold_hcth_prfl.hql"

#Gold Current Table Creation
fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-cust-gold-current/etc/schema/cmdm-cust-gold-current.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-cust-gp-gold-current/etc/schema/cmdm-cust-gp-gold-current.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-acct-gold-current/etc/schema/cmdm-acct-gold-current.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-prfl-gold-current/etc/schema/cmdm-prfl-gold-current.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-propensity-parse/etc/schema/gold-propensity.hql"

#Error Table Creation
fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-cust-gold-hist/etc/schema/stage_hcth_cust_err.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-cust-gp-gold-hist/etc/schema/stage_hcth_cust_gp_err.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-acct-gold-hist/etc/schema/stage_hcth_acct_err.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-prfl-gold-hist/etc/schema/stage_hcth_prfl_error.hql"

fn_run_hive "${PROJECT_HOME_DIRECTORY}" \
  "${RELEASE_HOME_DIRECTORY}/etc/hive.properties" \
  "${PROJECT_HOME_DIRECTORY}/cmdm-propensity-parse/etc/schema/stage-propensity.hql"

hive -e " USE ${DB_STAGE} ;
LOAD DATA LOCAL INPATH '${PROJECT_HOME_DIRECTORY}/cmdm-propensity-parse/etc/data/stage_data.txt' OVERWRITE INTO TABLE raw_hc_propensity_level
PARTITION(batchid = 20160228090501)"

################################################################################
#                                     End                                      #
################################################################################
