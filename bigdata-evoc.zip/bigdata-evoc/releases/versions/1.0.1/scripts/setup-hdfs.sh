#!/bin/bash
###############################################################################
#                               Documentation                                 #
###############################################################################
#                                                                             #
# Description                                                                 #
#     :                                                                       #
#                                                                             #
#                                                                             #
#                                                                             #
###############################################################################
#                           Setup Hive Directories                            #
###############################################################################


fn_create_hdfs_directory "${CMDM_RAW_DIR}/cust_gp"
fn_create_hdfs_directory "${DB_STAGE_DIR}/raw_uc_customer_group"

fn_create_hdfs_directory "${CMDM_RAW_DIR}/cust"
fn_create_hdfs_directory "${DB_STAGE_DIR}/raw_uc_customer"

fn_create_hdfs_directory "${CMDM_RAW_DIR}/ref_val"
fn_create_hdfs_directory "${DB_STAGE_DIR}/raw_uc_reference_value"

fn_create_hdfs_directory "${CMDM_RAW_DIR}/prfl"
fn_create_hdfs_directory "${DB_STAGE_DIR}/raw_uc_profile"

fn_create_hdfs_directory "${CMDM_RAW_DIR}/acct"
fn_create_hdfs_directory "${DB_STAGE_DIR}/raw_uc_account"


################################################################################
#                                     End                                      #
################################################################################

