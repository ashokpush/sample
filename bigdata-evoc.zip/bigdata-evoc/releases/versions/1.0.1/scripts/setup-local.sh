#!/bin/bash
###############################################################################
#                               Documentation                                 #
###############################################################################
#                                                                             #
# Description                                                                 #
#     :                                                                       #
#                                                                             #
#                                                                             #
#                                                                             #
###############################################################################
#                           Setup Local Directories                           #
###############################################################################

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-setup"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-cust-ingest"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-cust-parse"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-cust-merge"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-cust-validation"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-cust-gp-ingest"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-cust-gp-parse"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-cust-gp-merge"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-cust-gp-validation"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-ref-val-ingest"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-ref-val-parse"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-ref-val-merge"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-ref-val-validation"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-prfl-ingest"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-prfl-parse"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-prfl-merge"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-prfl-validation"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-acct-ingest"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-acct-parse"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-acct-merge"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-acct-validation"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-cleanup"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-validation"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-acct-gold-hist"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-cust-gold-hist"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-cust-gp-gold-hist"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-prfl-gold-hist"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-acct-gold-current"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-cust-gold-current"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-cust-gp-gold-current"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-prfl-gold-current"

fn_create_local_directory  "${AZKABAN_TMP_DIR}/cmdm-propensity-parse"

################################################################################
#                                     End                                      #
################################################################################

